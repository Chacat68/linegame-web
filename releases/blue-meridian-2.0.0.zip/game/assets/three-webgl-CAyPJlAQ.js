import{V as Fe,C as Qe,M as Ie,a as _t,m as ht,b as yi,c as zt,B as jn,S as ei,d as St,e as Pi,f as Xt,g as $e,h as qe,P as ea,F as ti,i as ta,I as ia,w as Ge,H as Ot,U as bt,j as It,R as Nt,k as Fa,W as Pt,l as na,N as jt,L as Wt,n as Et,o as Oa,p as Ki,E as gi,q as vi,r as Li,s as ui,t as Ba,u as Ga,v as Ha,x as Ze,D as aa,y as mt,z as ii,A as ra,G as qi,J as Va,O as Wa,K as Lt,Q as oa,T as sa,X as ca,Y as la,Z as fa,_ as da,$ as ua,a0 as ka,a1 as Fi,a2 as Oi,a3 as za,a4 as Zi,a5 as Qt,a6 as li,a7 as Xa,a8 as Ya,a9 as Ka,aa as pa,ab as qa,ac as Ct,ad as fi,ae as $i,af as Za,ag as $a,ah as Yt,ai as wi,aj as Ui,ak as Qa,al as Ja,am as ja,an as er,ao as Kt,ap as Ft,aq as tr,ar as Bt,as as ha,at as Qi,au as ir,av as nr,aw as Zt,ax as ar,ay as rr,az as or,aA as sr,aB as cr,aC as lr,aD as fr,aE as dr,aF as ur,aG as pr,aH as hr,aI as mr,aJ as _r,aK as gr,aL as vr,aM as Sr,aN as Er,aO as xr,aP as Mr,aQ as Tr,aR as Ar,aS as Rr,aT as br,aU as Ji,aV as Cr,aW as Pr,aX as ji,aY as en,aZ as tn,a_ as Lr,a$ as wr,b0 as Ur,b1 as Dr,b2 as Di,b3 as Ir,b4 as Si,b5 as oi,b6 as Nr,b7 as yr,b8 as Fr,b9 as Or,ba as Br,bb as Gr,bc as Hr,bd as Vt,be as kt,bf as nn,bg as Vr,bh as ni,bi as pi,bj as Wr,bk as ma,bl as _a,bm as kr,bn as zr,bo as Xr,bp as Yr,bq as Kr,br as qr,bs as Zr,bt as ga,bu as va,bv as Sa,bw as Ei,bx as xi,by as Mi,bz as Ti,bA as an,bB as rn,bC as on,bD as sn,bE as cn,bF as ln,bG as fn,bH as dn,bI as un,bJ as pn,bK as hn,bL as mn,bM as _n,bN as gn,bO as vn,bP as Sn,bQ as En,bR as xn,bS as Mn,bT as Tn,bU as An,bV as Rn,bW as bn,bX as Cn,bY as Pn,bZ as Ln,b_ as wn,b$ as Un,c0 as Dn,c1 as In,c2 as Ea,c3 as $r,c4 as Ai,c5 as Qr,c6 as Ri,c7 as Jr,c8 as jr,c9 as eo,ca as to,cb as io,cc as Nn,cd as yn,ce as no}from"./three-core-DgPk7s-8.js";function xa(){let e=null,i=!1,t=null,n=null;function f(c,u){t(c,u),n=e.requestAnimationFrame(f)}return{start:function(){i!==!0&&t!==null&&e!==null&&(n=e.requestAnimationFrame(f),i=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(n),i=!1},setAnimationLoop:function(c){t=c},setContext:function(c){e=c}}}function ao(e){const i=new WeakMap;function t(g,H){const T=g.array,q=g.usage,G=T.byteLength,p=e.createBuffer();e.bindBuffer(H,p),e.bufferData(H,T,q),g.onUploadCallback();let x;if(T instanceof Float32Array)x=e.FLOAT;else if(typeof Float16Array<"u"&&T instanceof Float16Array)x=e.HALF_FLOAT;else if(T instanceof Uint16Array)g.isFloat16BufferAttribute?x=e.HALF_FLOAT:x=e.UNSIGNED_SHORT;else if(T instanceof Int16Array)x=e.SHORT;else if(T instanceof Uint32Array)x=e.UNSIGNED_INT;else if(T instanceof Int32Array)x=e.INT;else if(T instanceof Int8Array)x=e.BYTE;else if(T instanceof Uint8Array)x=e.UNSIGNED_BYTE;else if(T instanceof Uint8ClampedArray)x=e.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+T);return{buffer:p,type:x,bytesPerElement:T.BYTES_PER_ELEMENT,version:g.version,size:G}}function n(g,H,T){const q=H.array,G=H.updateRanges;if(e.bindBuffer(T,g),G.length===0)e.bufferSubData(T,0,q);else{G.sort((x,U)=>x.start-U.start);let p=0;for(let x=1;x<G.length;x++){const U=G[p],Y=G[x];Y.start<=U.start+U.count+1?U.count=Math.max(U.count,Y.start+Y.count-U.start):(++p,G[p]=Y)}G.length=p+1;for(let x=0,U=G.length;x<U;x++){const Y=G[x];e.bufferSubData(T,Y.start*q.BYTES_PER_ELEMENT,q,Y.start,Y.count)}H.clearUpdateRanges()}H.onUploadCallback()}function f(g){return g.isInterleavedBufferAttribute&&(g=g.data),i.get(g)}function c(g){g.isInterleavedBufferAttribute&&(g=g.data);const H=i.get(g);H&&(e.deleteBuffer(H.buffer),i.delete(g))}function u(g,H){if(g.isInterleavedBufferAttribute&&(g=g.data),g.isGLBufferAttribute){const q=i.get(g);(!q||q.version<g.version)&&i.set(g,{buffer:g.buffer,type:g.type,bytesPerElement:g.elementSize,version:g.version});return}const T=i.get(g);if(T===void 0)i.set(g,t(g,H));else if(T.version<g.version){if(T.size!==g.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(T.buffer,g,H),T.version=g.version}}return{get:f,remove:c,update:u}}const ro=`
#ifdef USE_ALPHAHASH

	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;

#endif
`,oo=`
#ifdef USE_ALPHAHASH

	/**
	 * See: https://casual-effects.com/research/Wyman2017Hashed/index.html
	 */

	const float ALPHA_HASH_SCALE = 0.05; // Derived from trials only, and may be changed.

	float hash2D( vec2 value ) {

		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );

	}

	float hash3D( vec3 value ) {

		return hash2D( vec2( hash2D( value.xy ), value.z ) );

	}

	float getAlphaHashThreshold( vec3 position ) {

		// Find the discretized derivatives of our coordinates
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );

		// Find two nearest log-discretized noise scales
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);

		// Compute alpha thresholds at our two noise scales
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);

		// Factor to interpolate lerp with
		float lerpFactor = fract( log2( pixScale ) );

		// Interpolate alpha threshold from noise at two scales
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;

		// Pass into CDF to compute uniformly distrib threshold
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);

		// Find our final, uniformly distributed alpha threshold (ατ)
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;

		// Avoids ατ == 0. Could also do ατ =1-ατ
		return clamp( threshold , 1.0e-6, 1.0 );

	}

#endif
`,so=`
#ifdef USE_ALPHAMAP

	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;

#endif
`,co=`
#ifdef USE_ALPHAMAP

	uniform sampler2D alphaMap;

#endif
`,lo=`
#ifdef USE_ALPHATEST

	#ifdef ALPHA_TO_COVERAGE

	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;

	#else

	if ( diffuseColor.a < alphaTest ) discard;

	#endif

#endif
`,fo=`
#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif
`,uo=`
#ifdef USE_AOMAP

	// reads channel R, compatible with a combined OcclusionRoughnessMetallic (RGB) texture
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;

	reflectedLight.indirectDiffuse *= ambientOcclusion;

	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif

	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif

	#if defined( USE_ENVMAP ) && defined( STANDARD )

		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );

		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );

	#endif

#endif
`,po=`
#ifdef USE_AOMAP

	uniform sampler2D aoMap;
	uniform float aoMapIntensity;

#endif
`,ho=`
#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif

	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {

		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );

	}

	float getIndirectIndex( const in int i ) {

		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );

	}

#endif

#ifdef USE_BATCHING_COLOR

	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {

		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );

	}

#endif
`,mo=`
#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif
`,_o=`
vec3 transformed = vec3( position );

#ifdef USE_ALPHAHASH

	vPosition = vec3( position );

#endif
`,go=`
vec3 objectNormal = vec3( normal );

#ifdef USE_TANGENT

	vec3 objectTangent = vec3( tangent.xyz );

#endif
`,vo=`

float G_BlinnPhong_Implicit( /* const in float dotNL, const in float dotNV */ ) {

	// geometry term is (n dot l)(n dot v) / 4(n dot l)(n dot v)
	return 0.25;

}

float D_BlinnPhong( const in float shininess, const in float dotNH ) {

	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );

}

vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {

	vec3 halfDir = normalize( lightDir + viewDir );

	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );

	vec3 F = F_Schlick( specularColor, 1.0, dotVH );

	float G = G_BlinnPhong_Implicit( /* dotNL, dotNV */ );

	float D = D_BlinnPhong( shininess, dotNH );

	return F * ( G * D );

} // validated

`,So=`

#ifdef USE_IRIDESCENCE

	// XYZ to linear-sRGB color space
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);

	// Assume air interface for top
	// Note: We don't handle the case fresnel0 == 1
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {

		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );

	}

	// Conversion FO/IOR
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {

		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );

	}

	// ior is a value between 1.0 and 3.0. 1.0 is air interface
	float IorToFresnel0( float transmittedIor, float incidentIor ) {

		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));

	}

	// Fresnel equations for dielectric/dielectric interfaces.
	// Ref: https://belcour.github.io/blog/research/2017/05/01/brdf-thin-film.html
	// Evaluation XYZ sensitivity curves in Fourier space
	vec3 evalSensitivity( float OPD, vec3 shift ) {

		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );

		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;

		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;

	}

	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {

		vec3 I;

		// Force iridescenceIOR -> outsideIOR when thinFilmThickness -> 0.0
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		// Evaluate the cosTheta on the base layer (Snell law)
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );

		// Handle TIR:
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {

			return vec3( 1.0 );

		}

		float cosTheta2 = sqrt( cosTheta2Sq );

		// First interface
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;

		// Second interface
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) ); // guard against 1.0
		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;

		// Phase shift
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;

		// Compound terms
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );

		// Reflectance term for m = 0 (DC term amplitude)
		vec3 C0 = R12 + Rs;
		I = C0;

		// Reflectance term for m > 0 (pairs of diracs)
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {

			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;

		}

		// Since out of gamut colors might be produced, negative color values are clamped to 0.
		return max( I, vec3( 0.0 ) );

	}

#endif

`,Eo=`
#ifdef USE_BUMPMAP

	uniform sampler2D bumpMap;
	uniform float bumpScale;

	// Bump Mapping Unparametrized Surfaces on the GPU by Morten S. Mikkelsen
	// https://mmikk.github.io/papers3d/mm_sfgrad_bump.pdf

	// Evaluate the derivative of the height w.r.t. screen-space using forward differencing (listing 2)

	vec2 dHdxy_fwd() {

		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );

		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;

		return vec2( dBx, dBy );

	}

	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {

		// normalize is done to ensure that the bump map looks the same regardless of the texture's scale
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm; // normalized

		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );

		float fDet = dot( vSigmaX, R1 ) * faceDirection;

		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );

	}

#endif
`,xo=`
#if NUM_CLIPPING_PLANES > 0

	vec4 plane;

	#ifdef ALPHA_TO_COVERAGE

		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;

		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {

			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );

			if ( clipOpacity == 0.0 ) discard;

		}
		#pragma unroll_loop_end

		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES

			float unionClipOpacity = 1.0;

			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {

				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );

			}
			#pragma unroll_loop_end

			clipOpacity *= 1.0 - unionClipOpacity;

		#endif

		diffuseColor.a *= clipOpacity;

		if ( diffuseColor.a == 0.0 ) discard;

	#else

		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {

			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;

		}
		#pragma unroll_loop_end

		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES

			bool clipped = true;

			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {

				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;

			}
			#pragma unroll_loop_end

			if ( clipped ) discard;

		#endif

	#endif

#endif
`,Mo=`
#if NUM_CLIPPING_PLANES > 0

	varying vec3 vClipPosition;

	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];

#endif
`,To=`
#if NUM_CLIPPING_PLANES > 0

	varying vec3 vClipPosition;

#endif
`,Ao=`
#if NUM_CLIPPING_PLANES > 0

	vClipPosition = - mvPosition.xyz;

#endif
`,Ro=`
#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )

	diffuseColor *= vColor;

#endif
`,bo=`
#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )

	varying vec4 vColor;

#endif
`,Co=`
#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )

	varying vec4 vColor;

#endif
`,Po=`
#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )

	vColor = vec4( 1.0 );

#endif

#ifdef USE_COLOR_ALPHA

	vColor *= color;

#elif defined( USE_COLOR )

	vColor.rgb *= color;

#endif

#ifdef USE_INSTANCING_COLOR

	vColor.rgb *= instanceColor.rgb;

#endif

#ifdef USE_BATCHING_COLOR

	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );

#endif
`,Lo=`
#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6

#ifndef saturate
// <tonemapping_pars_fragment> may have defined saturate() already
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )

float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }

// expects values in the range of [0,1]x[0,1], returns values in the [0,1] range.
// do not collapse into a single function per: http://byteblacksmith.com/improvements-to-the-canonical-one-liner-glsl-rand-for-opengl-es-2-0/
highp float rand( const in vec2 uv ) {

	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );

	return fract( sin( sn ) * c );

}

#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif

struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};

struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};

#ifdef USE_ALPHAHASH

	varying vec3 vPosition;

#endif

vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

}

#define inverseTransformDirection transformDirectionByInverseViewMatrix // @deprecated r185

vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {

	// upper-left 3x3 of view matrix is assumed to be orthogonal

	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );

}

vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {

	// upper-left 3x3 of view matrix is assumed to be orthogonal

	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );

}

bool isPerspectiveMatrix( mat4 m ) {

	return m[ 2 ][ 3 ] == - 1.0;

}

vec2 equirectUv( in vec3 dir ) {

	// dir is assumed to be unit length

	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;

	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;

	return vec2( u, v );

}

vec3 BRDF_Lambert( const in vec3 diffuseColor ) {

	return RECIPROCAL_PI * diffuseColor;

} // validated

vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {

	// Original approximation by Christophe Schlick '94
	// float fresnel = pow( 1.0 - dotVH, 5.0 );

	// Optimized variant (presented by Epic at SIGGRAPH '13)
	// https://cdn2.unrealengine.com/Resources/files/2013SiggraphPresentationsNotes-26915738.pdf
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );

	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );

} // validated

float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {

	// Original approximation by Christophe Schlick '94
	// float fresnel = pow( 1.0 - dotVH, 5.0 );

	// Optimized variant (presented by Epic at SIGGRAPH '13)
	// https://cdn2.unrealengine.com/Resources/files/2013SiggraphPresentationsNotes-26915738.pdf
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );

	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );

} // validated
`,wo=`
#ifdef ENVMAP_TYPE_CUBE_UV

	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0

	// These shader functions convert between the UV coordinates of a single face of
	// a cubemap, the 0-5 integer index of a cube face, and the direction vector for
	// sampling a textureCube (not generally normalized ).

	float getFace( vec3 direction ) {

		vec3 absDirection = abs( direction );

		float face = - 1.0;

		if ( absDirection.x > absDirection.z ) {

			if ( absDirection.x > absDirection.y )

				face = direction.x > 0.0 ? 0.0 : 3.0;

			else

				face = direction.y > 0.0 ? 1.0 : 4.0;

		} else {

			if ( absDirection.z > absDirection.y )

				face = direction.z > 0.0 ? 2.0 : 5.0;

			else

				face = direction.y > 0.0 ? 1.0 : 4.0;

		}

		return face;

	}

	// RH coordinate system; PMREM face-indexing convention
	vec2 getUV( vec3 direction, float face ) {

		vec2 uv;

		if ( face == 0.0 ) {

			uv = vec2( direction.z, direction.y ) / abs( direction.x ); // pos x

		} else if ( face == 1.0 ) {

			uv = vec2( - direction.x, - direction.z ) / abs( direction.y ); // pos y

		} else if ( face == 2.0 ) {

			uv = vec2( - direction.x, direction.y ) / abs( direction.z ); // pos z

		} else if ( face == 3.0 ) {

			uv = vec2( - direction.z, direction.y ) / abs( direction.x ); // neg x

		} else if ( face == 4.0 ) {

			uv = vec2( - direction.x, direction.z ) / abs( direction.y ); // neg y

		} else {

			uv = vec2( direction.x, direction.y ) / abs( direction.z ); // neg z

		}

		return 0.5 * ( uv + 1.0 );

	}

	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {

		float face = getFace( direction );

		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );

		mipInt = max( mipInt, cubeUV_minMipLevel );

		float faceSize = exp2( mipInt );

		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0; // #25071

		if ( face > 2.0 ) {

			uv.y += faceSize;

			face -= 3.0;

		}

		uv.x += face * faceSize;

		uv.x += filterInt * 3.0 * cubeUV_minTileSize;

		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );

		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;

		#ifdef texture2DGradEXT

			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb; // disable anisotropic filtering

		#else

			return texture2D( envMap, uv ).rgb;

		#endif

	}

	// These defines must match with PMREMGenerator

	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0

	float roughnessToMip( float roughness ) {

		float mip = 0.0;

		if ( roughness >= cubeUV_r1 ) {

			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;

		} else if ( roughness >= cubeUV_r4 ) {

			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;

		} else if ( roughness >= cubeUV_r5 ) {

			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;

		} else if ( roughness >= cubeUV_r6 ) {

			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;

		} else {

			mip = - 2.0 * log2( 1.16 * roughness ); // 1.16 = 1.79^0.25
		}

		return mip;

	}

	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {

		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );

		float mipF = fract( mip );

		float mipInt = floor( mip );

		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );

		if ( mipF == 0.0 ) {

			return vec4( color0, 1.0 );

		} else {

			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );

			return vec4( mix( color0, color1, mipF ), 1.0 );

		}

	}

#endif
`,Uo=`

vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT

	vec3 transformedTangent = objectTangent;

#endif

#ifdef USE_BATCHING

	// this is in lieu of a per-instance normal-matrix
	// shear transforms in the instance matrix are not supported

	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;

	#ifdef USE_TANGENT

		transformedTangent = bm * transformedTangent;

	#endif

#endif

#ifdef USE_INSTANCING

	// this is in lieu of a per-instance normal-matrix
	// shear transforms in the instance matrix are not supported

	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;

	#ifdef USE_TANGENT

		transformedTangent = im * transformedTangent;

	#endif

#endif

transformedNormal = normalMatrix * transformedNormal;

#ifdef FLIP_SIDED

	transformedNormal = - transformedNormal;

#endif

#ifdef USE_TANGENT

	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;

#endif
`,Do=`
#ifdef USE_DISPLACEMENTMAP

	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;

#endif
`,Io=`
#ifdef USE_DISPLACEMENTMAP

	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );

#endif
`,No=`
#ifdef USE_EMISSIVEMAP

	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );

	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE

		// use inline sRGB decode until browsers properly support SRGB8_ALPHA8 with video textures (#26516)

		emissiveColor = sRGBTransferEOTF( emissiveColor );

	#endif

	totalEmissiveRadiance *= emissiveColor.rgb;

#endif
`,yo=`
#ifdef USE_EMISSIVEMAP

	uniform sampler2D emissiveMap;

#endif
`,Fo=`
gl_FragColor = linearToOutputTexel( gl_FragColor );
`,Oo=`

vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}

vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}

vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}

`,Bo=`
#ifdef USE_ENVMAP

	#ifdef ENV_WORLDPOS

		vec3 cameraToFrag;

		if ( isOrthographic ) {

			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );

		} else {

			cameraToFrag = normalize( vWorldPosition - cameraPosition );

		}

		// Transforming Normal Vectors with the Inverse Transformation
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );

		#ifdef ENVMAP_MODE_REFLECTION

			vec3 reflectVec = reflect( cameraToFrag, worldNormal );

		#else

			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );

		#endif

	#else

		vec3 reflectVec = vReflect;

	#endif

	#ifdef ENVMAP_TYPE_CUBE

		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );

		#ifdef ENVMAP_BLENDING_MULTIPLY

			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );

		#elif defined( ENVMAP_BLENDING_MIX )

			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );

		#elif defined( ENVMAP_BLENDING_ADD )

			outgoingLight += envColor.xyz * specularStrength * reflectivity;

		#endif

	#endif

#endif
`,Go=`
#ifdef USE_ENVMAP

	uniform float envMapIntensity;
	uniform mat3 envMapRotation;

	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif

#endif
`,Ho=`
#ifdef USE_ENVMAP

	uniform float reflectivity;

	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )

		#define ENV_WORLDPOS

	#endif

	#ifdef ENV_WORLDPOS

		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif

#endif
`,Vo=`
#ifdef USE_ENVMAP

	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )

		#define ENV_WORLDPOS

	#endif

	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;

	#else

		varying vec3 vReflect;
		uniform float refractionRatio;

	#endif

#endif
`,Wo=`
#ifdef USE_ENVMAP

	#ifdef ENV_WORLDPOS

		vWorldPosition = worldPosition.xyz;

	#else

		vec3 cameraToVertex;

		if ( isOrthographic ) {

			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );

		} else {

			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );

		}

		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );

		#ifdef ENVMAP_MODE_REFLECTION

			vReflect = reflect( cameraToVertex, worldNormal );

		#else

			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );

		#endif

	#endif

#endif
`,ko=`
#ifdef USE_FOG

	vFogDepth = - mvPosition.z;

#endif
`,zo=`
#ifdef USE_FOG

	varying float vFogDepth;

#endif
`,Xo=`
#ifdef USE_FOG

	#ifdef FOG_EXP2

		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );

	#else

		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );

	#endif

	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );

#endif
`,Yo=`
#ifdef USE_FOG

	uniform vec3 fogColor;
	varying float vFogDepth;

	#ifdef FOG_EXP2

		uniform float fogDensity;

	#else

		uniform float fogNear;
		uniform float fogFar;

	#endif

#endif
`,Ko=`

#ifdef USE_GRADIENTMAP

	uniform sampler2D gradientMap;

#endif

vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {

	// dotNL will be from -1.0 to 1.0
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );

	#ifdef USE_GRADIENTMAP

		return vec3( texture2D( gradientMap, coord ).r );

	#else

		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );

	#endif

}
`,qo=`
#ifdef USE_LIGHTMAP

	uniform sampler2D lightMap;
	uniform float lightMapIntensity;

#endif
`,Zo=`
LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;
`,$o=`
varying vec3 vViewPosition;

struct LambertMaterial {

	vec3 diffuseColor;
	float specularStrength;

};

void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {

	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;

	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

}

void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {

	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

}

#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert
`,Qo=`
uniform bool receiveShadow;
uniform vec3 ambientLightColor;

#if defined( USE_LIGHT_PROBES )

	uniform vec3 lightProbe[ 9 ];

#endif

// get the irradiance (radiance convolved with cosine lobe) at the point 'normal' on the unit sphere
// source: https://graphics.stanford.edu/papers/envmap/envmap.pdf
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {

	// normal is assumed to have unit length

	float x = normal.x, y = normal.y, z = normal.z;

	// band 0
	vec3 result = shCoefficients[ 0 ] * 0.886227;

	// band 1
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;

	// band 2
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );

	return result;

}

vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {

	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );

	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );

	return irradiance;

}

vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {

	vec3 irradiance = ambientLightColor;

	return irradiance;

}

float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {

	// based upon Frostbite 3 Moving to Physically-based Rendering
	// page 32, equation 26: E[window1]
	// https://seblagarde.files.wordpress.com/2015/07/course_notes_moving_frostbite_to_pbr_v32.pdf
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );

	if ( cutoffDistance > 0.0 ) {

		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );

	}

	return distanceFalloff;

}

float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {

	return smoothstep( coneCosine, penumbraCosine, angleCosine );

}

#if NUM_DIR_LIGHTS > 0

	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};

	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];

	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {

		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;

	}

#endif


#if NUM_POINT_LIGHTS > 0

	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};

	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];

	// light is an out parameter as having it as a return value caused compiler errors on some devices
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {

		vec3 lVector = pointLight.position - geometryPosition;

		light.direction = normalize( lVector );

		float lightDistance = length( lVector );

		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );

	}

#endif


#if NUM_SPOT_LIGHTS > 0

	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};

	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];

	// light is an out parameter as having it as a return value caused compiler errors on some devices
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {

		vec3 lVector = spotLight.position - geometryPosition;

		light.direction = normalize( lVector );

		float angleCos = dot( light.direction, spotLight.direction );

		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );

		if ( spotAttenuation > 0.0 ) {

			float lightDistance = length( lVector );

			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );

		} else {

			light.color = vec3( 0.0 );
			light.visible = false;

		}

	}

#endif


#if NUM_RECT_AREA_LIGHTS > 0

	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};

	// Pre-computed values of LinearTransformedCosine approximation of BRDF
	// BRDF approximation Texture is 64x64
	uniform sampler2D ltc_1; // RGBA Float
	uniform sampler2D ltc_2; // RGBA Float

	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];

#endif


#if NUM_HEMI_LIGHTS > 0

	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};

	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];

	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {

		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;

		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );

		return irradiance;

	}

#endif

#include <lightprobes_pars_fragment>
`,Jo=`
#ifdef USE_ENVMAP

	vec3 getIBLIrradiance( const in vec3 normal ) {

		#ifdef ENVMAP_TYPE_CUBE_UV

			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );

			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );

			return PI * envMapColor.rgb * envMapIntensity;

		#else

			return vec3( 0.0 );

		#endif

	}

	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {

		#ifdef ENVMAP_TYPE_CUBE_UV

			vec3 reflectVec = reflect( - viewDir, normal );

			// Mixing the reflection with the normal is more accurate and keeps rough objects from gathering light from behind their tangent plane.
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );

			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );

			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );

			return envMapColor.rgb * envMapIntensity;

		#else

			return vec3( 0.0 );

		#endif

	}

	#ifdef USE_ANISOTROPY

		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {

			#ifdef ENVMAP_TYPE_CUBE_UV

			  // https://google.github.io/filament/Filament.md.html#lighting/imagebasedlights/anisotropy
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );

				return getIBLRadiance( viewDir, bentNormal, roughness );

			#else

				return vec3( 0.0 );

			#endif

		}

	#endif

#endif
`,jo=`
ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;
`,es=`
varying vec3 vViewPosition;

struct ToonMaterial {

	vec3 diffuseColor;

};

void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {

	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;

	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

}

void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {

	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

}

#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon
`,ts=`
BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;
`,is=`
varying vec3 vViewPosition;

struct BlinnPhongMaterial {

	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;

};

void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {

	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;

	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;

}

void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {

	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );

}

#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong
`,ns=`
PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;

vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );

material.roughness = max( roughnessFactor, 0.0525 );// 0.0525 corresponds to the base mip of a 256 cubemap.
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );

#ifdef IOR

	material.ior = ior;

	#ifdef USE_SPECULAR

		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;

		#ifdef USE_SPECULAR_COLORMAP

			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;

		#endif

		#ifdef USE_SPECULAR_INTENSITYMAP

			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;

		#endif

		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );

	#else

		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;

	#endif

	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );

#else

	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;

#endif

#ifdef USE_CLEARCOAT

	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;

	#ifdef USE_CLEARCOATMAP

		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;

	#endif

	#ifdef USE_CLEARCOAT_ROUGHNESSMAP

		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;

	#endif

	material.clearcoat = saturate( material.clearcoat ); // Burley clearcoat model
	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );

#endif

#ifdef USE_DISPERSION

	material.dispersion = dispersion;

#endif

#ifdef USE_IRIDESCENCE

	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;

	#ifdef USE_IRIDESCENCEMAP

		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;

	#endif

	#ifdef USE_IRIDESCENCE_THICKNESSMAP

		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;

	#else

		material.iridescenceThickness = iridescenceThicknessMaximum;

	#endif

#endif

#ifdef USE_SHEEN

	material.sheenColor = sheenColor;

	#ifdef USE_SHEEN_COLORMAP

		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;

	#endif

	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );

	#ifdef USE_SHEEN_ROUGHNESSMAP

		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;

	#endif

#endif

#ifdef USE_ANISOTROPY

	#ifdef USE_ANISOTROPYMAP

		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;

	#else

		vec2 anisotropyV = anisotropyVector;

	#endif

	material.anisotropy = length( anisotropyV );

	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}

	// Roughness along the anisotropy bitangent is the material roughness, while the tangent roughness increases with anisotropy.
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );

	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;

#endif
`,as=`

uniform sampler2D dfgLUT;

struct PhysicalMaterial {

	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;

	float roughness;
	float metalness;
	float specularF90;
	float dispersion;

	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif

	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif

	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif

	#ifdef IOR
		float ior;
	#endif

	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif

	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif

};

// temporary
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );

vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );

    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}

// Moving Frostbite to Physically Based Rendering 3.0 - page 12, listing 2
// https://seblagarde.files.wordpress.com/2015/07/course_notes_moving_frostbite_to_pbr_v32.pdf
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {

	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );

	return 0.5 / max( gv + gl, EPSILON );

}

// Microfacet Models for Refraction through Rough Surfaces - equation (33)
// http://graphicrants.blogspot.com/2013/08/specular-brdf-reference.html
// alpha is "roughness squared" in Disney’s reparameterization
float D_GGX( const in float alpha, const in float dotNH ) {

	float a2 = pow2( alpha );

	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0; // avoid alpha = 0 with dotNH = 1

	return RECIPROCAL_PI * a2 / pow2( denom );

}

// https://google.github.io/filament/Filament.md.html#materialsystem/anisotropicmodel/anisotropicspecularbrdf
#ifdef USE_ANISOTROPY

	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {

		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );

	}

	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {

		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;

		return RECIPROCAL_PI * a2 * pow2 ( w2 );

	}

#endif

#ifdef USE_CLEARCOAT

	// GGX Distribution, Schlick Fresnel, GGX_SmithCorrelated Visibility
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {

		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;

		float alpha = pow2( roughness ); // UE4's roughness

		vec3 halfDir = normalize( lightDir + viewDir );

		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );

		vec3 F = F_Schlick( f0, f90, dotVH );

		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );

		float D = D_GGX( alpha, dotNH );

		return F * ( V * D );

	}

#endif

vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {

	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;

	float alpha = pow2( roughness ); // UE4's roughness

	vec3 halfDir = normalize( lightDir + viewDir );

	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );

	vec3 F = F_Schlick( f0, f90, dotVH );

	#ifdef USE_IRIDESCENCE

		F = mix( F, material.iridescenceFresnel, material.iridescence );

	#endif

	#ifdef USE_ANISOTROPY

		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );

		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );

		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );

	#else

		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );

		float D = D_GGX( alpha, dotNH );

	#endif

	return F * ( V * D );

}

// Rect Area Light

// Real-Time Polygonal-Light Shading with Linearly Transformed Cosines
// by Eric Heitz, Jonathan Dupuy, Stephen Hill and David Neubelt
// code: https://github.com/selfshadow/ltc_code/

vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {

	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;

	float dotNV = saturate( dot( N, V ) );

	// texture parameterized by sqrt( GGX alpha ) and sqrt( 1 - cos( theta ) )
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );

	uv = uv * LUT_SCALE + LUT_BIAS;

	return uv;

}

float LTC_ClippedSphereFormFactor( const in vec3 f ) {

	// Real-Time Area Lighting: a Journey from Research to Production (p.102)
	// An approximation of the form factor of a horizon-clipped rectangle.

	float l = length( f );

	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );

}

vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {

	float x = dot( v1, v2 );

	float y = abs( x );

	// rational polynomial approximation to theta / sin( theta ) / 2PI
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;

	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;

	return cross( v1, v2 ) * theta_sintheta;

}

vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {

	// bail if point is on back side of plane of light
	// assumes ccw winding order of light vertices
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );

	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );

	// construct orthonormal basis around N
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 ); // negated from paper; possibly due to a different handedness of world coordinate system

	// compute transform
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );

	// transform rect
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );

	// project rect onto sphere
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );

	// calculate vector form factor
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );

	// adjust for horizon clipping
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );

/*
	// alternate method of adjusting for horizon clipping (see reference)
	// refactoring required
	float len = length( vectorFormFactor );
	float z = vectorFormFactor.z / len;

	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;

	// tabulated horizon-clipped sphere, apparently...
	vec2 uv = vec2( z * 0.5 + 0.5, len );
	uv = uv * LUT_SCALE + LUT_BIAS;

	float scale = texture2D( ltc_2, uv ).w;

	float result = len * scale;
*/

	return vec3( result );

}

// End Rect Area Light

#if defined( USE_SHEEN )

// https://github.com/google/filament/blob/master/shaders/src/brdf.fs
float D_Charlie( float roughness, float dotNH ) {

	float alpha = pow2( roughness );

	// Estevez and Kulla 2017, "Production Friendly Microfacet Sheen BRDF"
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 ); // 2^(-14/2), so sin2h^2 > 0 in fp16

	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );

}

// https://github.com/google/filament/blob/master/shaders/src/brdf.fs
float V_Neubelt( float dotNV, float dotNL ) {

	// Neubelt and Pettineo 2013, "Crafting a Next-gen Material Pipeline for The Order: 1886"
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );

}

vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {

	vec3 halfDir = normalize( lightDir + viewDir );

	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );

	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );

	return sheenColor * ( D * V );

}

#endif

// This is a curve-fit approximation to the "Charlie sheen" BRDF integrated over the hemisphere from
// Estevez and Kulla 2017, "Production Friendly Microfacet Sheen BRDF".
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {

	float dotNV = saturate( dot( normal, viewDir ) );

	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );

	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;

	float DG = exp( a * dotNV + b );

	return saturate( DG );

}

vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {

	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;

	return specularColor * fab.x + specularF90 * fab.y;

}

// Fdez-Agüera's "Multiple-Scattering Microfacet Model for Real-Time Image Based Lighting"
// Approximates multiscattering in order to preserve energy.
// http://www.jcgt.org/published/0008/01/03/
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif

	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;

	#ifdef USE_IRIDESCENCE

		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );

	#else

		vec3 Fr = specularColor;

	#endif

	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;

	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;

	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619; // 1/21
	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );

	singleScatter += FssEss;
	multiScatter += Fms * Ems;

}

// GGX BRDF with multi-scattering energy compensation for direct lighting
// Based on "Practical Multiple Scattering Compensation for Microfacet Models"
// https://blog.selfshadow.com/publications/turquin/ms_comp_final.pdf
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {

	// Single-scattering BRDF (standard GGX)
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );

	// Multi-scattering compensation
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );

	// Precomputed DFG values for view and light directions
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;

	// Single-scattering energy for view and light
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;

	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;

	// Energy lost to multiple scattering
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;

	// Average Fresnel reflectance
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619; // 1/21

	// Multiple scattering contribution
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );

	// Energy compensation factor
	float compensationFactor = Ems_V * Ems_L;

	vec3 multiScatter = Fms * compensationFactor;

	return singleScatter + multiScatter;

}

#if NUM_RECT_AREA_LIGHTS > 0

	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {

		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;

		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight; // counterclockwise; light shines in local neg z direction
		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;

		vec2 uv = LTC_Uv( normal, viewDir, roughness );

		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );

		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);

		// LTC Fresnel Approximation by Stephen Hill
		// http://blog.selfshadow.com/publications/s2016-advances/s2016_ltc_fresnel.pdf
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );

		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );

		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );

		#ifdef USE_CLEARCOAT

			vec3 Ncc = geometryClearcoatNormal;

			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );

			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );

			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);

			// LTC Fresnel Approximation for clearcoat
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;

			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );

		#endif

	}

#endif

void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {

	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );

	vec3 irradiance = dotNL * directLight.color;

	#ifdef USE_CLEARCOAT

		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );

		vec3 ccIrradiance = dotNLcc * directLight.color;

		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );

	#endif

	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif

	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );

	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}

void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {

	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );

	#ifdef USE_SHEEN

		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );

		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;

		diffuse *= sheenEnergyComp;

	#endif

	reflectedLight.indirectDiffuse += diffuse;

}

void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {

	#ifdef USE_CLEARCOAT

		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );

	#endif

	#ifdef USE_SHEEN

		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;

 	#endif

	// Both indirect specular and indirect diffuse light accumulate here
	// Compute multiscattering separately for dielectric and metallic, then mix

	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );

	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );

	#ifdef USE_IRIDESCENCE

		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );

	#else

		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );

	#endif

	// Mix based on metalness
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );

	// Diffuse energy conservation uses dielectric path
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );

	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;

	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;

	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;

	#ifdef USE_SHEEN

		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );

		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;

		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;

	#endif

	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;

}

#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical

// ref: https://seblagarde.files.wordpress.com/2015/07/course_notes_moving_frostbite_to_pbr_v32.pdf
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {

	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );

}
`,rs=`
/**
 * This is a template that can be used to light a material, it uses pluggable
 * RenderEquations (RE)for specific lighting scenarios.
 *
 * Instructions for use:
 * - Ensure that both RE_Direct, RE_IndirectDiffuse and RE_IndirectSpecular are defined
 * - Create a material parameter that is to be passed as the third parameter to your lighting functions.
 *
 * TODO:
 * - Add area light support.
 * - Add sphere light support.
 * - Add diffuse light probe (irradiance cubemap) support.
 */

vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );

vec3 geometryClearcoatNormal = vec3( 0.0 );

#ifdef USE_CLEARCOAT

	geometryClearcoatNormal = clearcoatNormal;

#endif

#ifdef USE_IRIDESCENCE

	float dotNVi = saturate( dot( normal, geometryViewDir ) );

	if ( material.iridescenceThickness == 0.0 ) {

		material.iridescence = 0.0;

	} else {

		material.iridescence = saturate( material.iridescence );

	}

	if ( material.iridescence > 0.0 ) {

		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );

		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );

		// Iridescence F0 approximation
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );

	}

#endif

IncidentLight directLight;

#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )

	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {

		pointLight = pointLights[ i ];

		getPointLightInfo( pointLight, geometryPosition, directLight );

		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif

		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );

	}
	#pragma unroll_loop_end

#endif

#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )

	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;

	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {

		spotLight = spotLights[ i ];

		getSpotLightInfo( spotLight, geometryPosition, directLight );

		// spot lights are ordered [shadows with maps, shadows without maps, maps without shadows, none]
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif

		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif

		#undef SPOT_LIGHT_MAP_INDEX

		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif

		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );

	}
	#pragma unroll_loop_end

#endif

#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )

	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {

		directionalLight = directionalLights[ i ];

		getDirectionalLightInfo( directionalLight, directLight );

		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif

		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );

	}
	#pragma unroll_loop_end

#endif

#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )

	RectAreaLight rectAreaLight;

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {

		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );

	}
	#pragma unroll_loop_end

#endif

#if defined( RE_IndirectDiffuse )

	vec3 iblIrradiance = vec3( 0.0 );

	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );

	#if defined( USE_LIGHT_PROBES )

		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );

	#endif

	#if ( NUM_HEMI_LIGHTS > 0 )

		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {

			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );

		}
		#pragma unroll_loop_end

	#endif

	#ifdef USE_LIGHT_PROBES_GRID

		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );

	#endif

#endif

#if defined( RE_IndirectSpecular )

	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );

#endif
`,os=`
#if defined( RE_IndirectDiffuse )

	#ifdef USE_LIGHTMAP

		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;

		irradiance += lightMapIrradiance;

	#endif

	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )

		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )

			iblIrradiance += getIBLIrradiance( geometryNormal );

		#endif

	#endif

#endif

#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )

	#ifdef USE_ANISOTROPY

		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );

	#else

		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );

	#endif

	#ifdef USE_CLEARCOAT

		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );

	#endif

#endif
`,ss=`
#if defined( RE_IndirectDiffuse )

	#if defined( LAMBERT ) || defined( PHONG )

		irradiance += iblIrradiance;

	#endif

	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );

#endif

#if defined( RE_IndirectSpecular )

	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );

#endif
`,cs=`
#ifdef USE_LIGHT_PROBES_GRID

// Single atlas 3D texture that stores all 7 SH sub-volumes stacked along Z.
// Atlas depth = 7 * ( nz + 2 ) where nz = probesResolution.z.
// Each sub-volume occupies ( nz + 2 ) slices: 1 padding + nz data + 1 padding.
// Padding is a copy of the first / last data slice and prevents color bleeding
// when the hardware linear filter reads across a sub-volume boundary.
uniform highp sampler3D probesSH;

uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;

vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {

	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;

	// Offset sample position along normal by half a probe spacing
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );

	// Remap to texel centers of the probe grid (XY and Z)
	uvw = uvw * resMinusOne / res + 0.5 / res;

	// Atlas UV mapping along Z:
	//   paddedSlices = nz + 2  (1 padding texel at each end of every sub-volume)
	//   atlasDepth   = 7 * paddedSlices
	//   For sub-volume t the first DATA texel sits at atlas slice t*paddedSlices + 1.
	//   Given probe-grid texel-centre UVZ = ( iz + 0.5 ) / nz the atlas UV is:
	//     atlasUvZ = ( uvw.z * nz + t * paddedSlices + 1 ) / atlasDepth
	//
	// uvZBase encodes the nz-scaled Z plus the intra-volume offset (+ 1 for padding),
	// so adding t*paddedSlices steps to each successive sub-volume.
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;

	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );

	// Unpack 9 vec3 SH L2 coefficients
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;

	// Evaluate L2 irradiance
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;

	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );

	return max( result, vec3( 0.0 ) );

}

#endif
`,ls=`
#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )

	// Doing a strict comparison with == 1.0 can cause noise artifacts
	// on some platforms. See issue #17623.
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;

#endif
`,fs=`
#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )

	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;

#endif
`,ds=`
#ifdef USE_LOGARITHMIC_DEPTH_BUFFER

	varying float vFragDepth;
	varying float vIsPerspective;

#endif
`,us=`
#ifdef USE_LOGARITHMIC_DEPTH_BUFFER

	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );

#endif
`,ps=`
#ifdef USE_MAP

	vec4 sampledDiffuseColor = texture2D( map, vMapUv );

	#ifdef DECODE_VIDEO_TEXTURE

		// use inline sRGB decode until browsers properly support SRGB8_ALPHA8 with video textures (#26516)

		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );

	#endif

	diffuseColor *= sampledDiffuseColor;

#endif
`,hs=`
#ifdef USE_MAP

	uniform sampler2D map;

#endif
`,ms=`
#if defined( USE_MAP ) || defined( USE_ALPHAMAP )

	#if defined( USE_POINTS_UV )

		vec2 uv = vUv;

	#else

		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;

	#endif

#endif

#ifdef USE_MAP

	diffuseColor *= texture2D( map, uv );

#endif

#ifdef USE_ALPHAMAP

	diffuseColor.a *= texture2D( alphaMap, uv ).g;

#endif
`,_s=`
#if defined( USE_POINTS_UV )

	varying vec2 vUv;

#else

	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )

		uniform mat3 uvTransform;

	#endif

#endif

#ifdef USE_MAP

	uniform sampler2D map;

#endif

#ifdef USE_ALPHAMAP

	uniform sampler2D alphaMap;

#endif
`,gs=`
float metalnessFactor = metalness;

#ifdef USE_METALNESSMAP

	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );

	// reads channel B, compatible with a combined OcclusionRoughnessMetallic (RGB) texture
	metalnessFactor *= texelMetalness.b;

#endif
`,vs=`
#ifdef USE_METALNESSMAP

	uniform sampler2D metalnessMap;

#endif
`,Ss=`
#ifdef USE_INSTANCING_MORPH

	float morphTargetInfluences[ MORPHTARGETS_COUNT ];

	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;

	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {

		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;

	}
#endif
`,Es=`
#if defined( USE_MORPHCOLORS )

	// morphTargetBaseInfluence is set based on BufferGeometry.morphTargetsRelative value:
	// When morphTargetsRelative is false, this is set to 1 - sum(influences); this results in normal = sum((target - base) * influence)
	// When morphTargetsRelative is true, this is set to 1; as a result, all morph targets are simply added to the base after weighting
	vColor *= morphTargetBaseInfluence;

	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {

		#if defined( USE_COLOR_ALPHA )

			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];

		#elif defined( USE_COLOR )

			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];

		#endif

	}

#endif
`,xs=`
#ifdef USE_MORPHNORMALS

	// morphTargetBaseInfluence is set based on BufferGeometry.morphTargetsRelative value:
	// When morphTargetsRelative is false, this is set to 1 - sum(influences); this results in normal = sum((target - base) * influence)
	// When morphTargetsRelative is true, this is set to 1; as a result, all morph targets are simply added to the base after weighting
	objectNormal *= morphTargetBaseInfluence;

	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {

		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];

	}

#endif
`,Ms=`
#ifdef USE_MORPHTARGETS

	#ifndef USE_INSTANCING_MORPH

		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];

	#endif

	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;

	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {

		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;

		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );

	}

#endif
`,Ts=`
#ifdef USE_MORPHTARGETS

	// morphTargetBaseInfluence is set based on BufferGeometry.morphTargetsRelative value:
	// When morphTargetsRelative is false, this is set to 1 - sum(influences); this results in position = sum((target - base) * influence)
	// When morphTargetsRelative is true, this is set to 1; as a result, all morph targets are simply added to the base after weighting
	transformed *= morphTargetBaseInfluence;

	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {

		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];

	}

#endif
`,As=`
float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;

#ifdef FLAT_SHADED

	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );

#else

	vec3 normal = normalize( vNormal );

	#ifdef DOUBLE_SIDED

		normal *= faceDirection;

	#endif

#endif

#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )

	#ifdef USE_TANGENT

		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );

	#else

		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);

	#endif

	#ifdef DOUBLE_SIDED

		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;

	#endif

#endif

#ifdef USE_CLEARCOAT_NORMALMAP

	#ifdef USE_TANGENT

		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );

	#else

		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );

	#endif

	#ifdef DOUBLE_SIDED

		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;

	#endif

#endif

// non perturbed normal for clearcoat among others

vec3 nonPerturbedNormal = normal;

`,Rs=`

#ifdef USE_NORMALMAP_OBJECTSPACE

	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0; // overrides both flatShading and attribute normals

	#ifdef FLIP_SIDED

		normal = - normal;

	#endif

	#ifdef DOUBLE_SIDED

		normal = normal * faceDirection;

	#endif

	normal = normalize( normalMatrix * normal );

#elif defined( USE_NORMALMAP_TANGENTSPACE )

	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;

	#if defined( USE_PACKED_NORMALMAP )

		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );

	#endif

	mapN.xy *= normalScale;

	normal = normalize( tbn * mapN );

#elif defined( USE_BUMPMAP )

	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );

#endif
`,bs=`
#ifndef FLAT_SHADED

	varying vec3 vNormal;

	#ifdef USE_TANGENT

		varying vec3 vTangent;
		varying vec3 vBitangent;

	#endif

#endif
`,Cs=`
#ifndef FLAT_SHADED

	varying vec3 vNormal;

	#ifdef USE_TANGENT

		varying vec3 vTangent;
		varying vec3 vBitangent;

	#endif

#endif
`,Ps=`
#ifndef FLAT_SHADED // normal is computed with derivatives when FLAT_SHADED

	vNormal = normalize( transformedNormal );

	#ifdef USE_TANGENT

		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );

		#ifdef FLIP_SIDED

			vBitangent = - vBitangent;

		#endif

	#endif

#endif
`,Ls=`
#ifdef USE_NORMALMAP

	uniform sampler2D normalMap;
	uniform vec2 normalScale;

#endif

#ifdef USE_NORMALMAP_OBJECTSPACE

	uniform mat3 normalMatrix;

#endif

#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )

	// Normal Mapping Without Precomputed Tangents
	// http://www.thetenthplanet.de/archives/1180

	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {

		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );

		vec3 N = surf_norm; // normalized

		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );

		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;

		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );

		return mat3( T * scale, B * scale, N );

	}

#endif
`,ws=`
#ifdef USE_CLEARCOAT

	vec3 clearcoatNormal = nonPerturbedNormal;

#endif
`,Us=`
#ifdef USE_CLEARCOAT_NORMALMAP

	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;

	clearcoatNormal = normalize( tbn2 * clearcoatMapN );

#endif
`,Ds=`

#ifdef USE_CLEARCOATMAP

	uniform sampler2D clearcoatMap;

#endif

#ifdef USE_CLEARCOAT_NORMALMAP

	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;

#endif

#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	uniform sampler2D clearcoatRoughnessMap;

#endif
`,Is=`

#ifdef USE_IRIDESCENCEMAP

	uniform sampler2D iridescenceMap;

#endif

#ifdef USE_IRIDESCENCE_THICKNESSMAP

	uniform sampler2D iridescenceThicknessMap;

#endif
`,Ns=`
#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif

#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif

gl_FragColor = vec4( outgoingLight, diffuseColor.a );
`,ys=`
vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}

vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}

const float PackUpscale = 256. / 255.; // fraction -> 0..1 (including 1)
const float UnpackDownscale = 255. / 256.; // 0..1 -> fraction (excluding 1)
const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;

const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );

const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );

vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}

vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	// the 0.9999 tweak is unimportant, very tiny empirical improvement
	// return vec3( vuf * Inv255, gf * PackUpscale, bf * 0.9999 );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}

vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}

float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}

float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}

float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}

vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}

vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}

// NOTE: viewZ, the z-coordinate in camera space, is negative for points in front of the camera

float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	// -near maps to 0; -far maps to 1
	return ( viewZ + near ) / ( near - far );
}

float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {

	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;

	#else

		return depth * ( near - far ) - near;

	#endif
}

// NOTE: https://twitter.com/gonnavis/status/1377183786949959682

float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	// -near maps to 0; -far maps to 1
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}

float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER

		return ( near * far ) / ( ( near - far ) * depth - near );

	#else

		return ( near * far ) / ( ( far - near ) * depth - far );

	#endif
}
`,Fs=`
#ifdef PREMULTIPLIED_ALPHA

	gl_FragColor.rgb *= gl_FragColor.a;

#endif
`,Os=`
vec4 mvPosition = vec4( transformed, 1.0 );

#ifdef USE_BATCHING

	mvPosition = batchingMatrix * mvPosition;

#endif

#ifdef USE_INSTANCING

	mvPosition = instanceMatrix * mvPosition;

#endif

mvPosition = modelViewMatrix * mvPosition;

gl_Position = projectionMatrix * mvPosition;
`,Bs=`
#ifdef DITHERING

	gl_FragColor.rgb = dithering( gl_FragColor.rgb );

#endif
`,Gs=`
#ifdef DITHERING

	// based on https://www.shadertoy.com/view/MslGR8
	vec3 dithering( vec3 color ) {
		//Calculate grid position
		float grid_position = rand( gl_FragCoord.xy );

		//Shift the individual colors differently, thus making it even harder to see the dithering pattern
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );

		//modify shift according to grid position.
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );

		//shift the color by dither_shift
		return color + dither_shift_RGB;
	}

#endif
`,Hs=`
float roughnessFactor = roughness;

#ifdef USE_ROUGHNESSMAP

	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );

	// reads channel G, compatible with a combined OcclusionRoughnessMetallic (RGB) texture
	roughnessFactor *= texelRoughness.g;

#endif
`,Vs=`
#ifdef USE_ROUGHNESSMAP

	uniform sampler2D roughnessMap;

#endif
`,Ws=`
#if NUM_SPOT_LIGHT_COORDS > 0

	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];

#endif

#if NUM_SPOT_LIGHT_MAPS > 0

	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];

#endif

#ifdef USE_SHADOWMAP

	#if NUM_DIR_LIGHT_SHADOWS > 0

		#if defined( SHADOWMAP_TYPE_PCF )

			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];

		#else

			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];

		#endif

		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];

		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};

		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];

	#endif

	#if NUM_SPOT_LIGHT_SHADOWS > 0

		#if defined( SHADOWMAP_TYPE_PCF )

			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];

		#else

			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];

		#endif

		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};

		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];

	#endif

	#if NUM_POINT_LIGHT_SHADOWS > 0

		#if defined( SHADOWMAP_TYPE_PCF )

			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];

		#elif defined( SHADOWMAP_TYPE_BASIC )

			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];

		#endif

		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];

		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};

		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];

	#endif

	#if defined( SHADOWMAP_TYPE_PCF )

		// Interleaved Gradient Noise for randomizing sampling patterns
		float interleavedGradientNoise( vec2 position ) {

			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );

		}

		// Vogel disk sampling for uniform circular distribution
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {

			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;

		}

	#endif

	#if defined( SHADOWMAP_TYPE_PCF )

		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {

			float shadow = 1.0;

			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;

			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;

			if ( frustumTest ) {

				// Hardware PCF with LinearFilter gives us 4-tap filtering per sample
				// 5 samples using Vogel disk + IGN = effectively 20 filtered taps with better distribution
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;

				// Use IGN to rotate sampling pattern per pixel
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;

				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;

			}

			return mix( 1.0, shadow, shadowIntensity );

		}

	#elif defined( SHADOWMAP_TYPE_VSM )

		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {

			float shadow = 1.0;

			shadowCoord.xyz /= shadowCoord.w;

			#ifdef USE_REVERSED_DEPTH_BUFFER

				shadowCoord.z -= shadowBias;

			#else

				shadowCoord.z += shadowBias;

			#endif

			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;

			if ( frustumTest ) {

				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;

				float mean = distribution.x;
				float variance = distribution.y * distribution.y;

				#ifdef USE_REVERSED_DEPTH_BUFFER

					float hard_shadow = step( mean, shadowCoord.z );

				#else

					float hard_shadow = step( shadowCoord.z, mean );

				#endif
				
				// Early return if fully lit
				if ( hard_shadow == 1.0 ) {

					shadow = 1.0;

				} else {

					// Variance must be non-zero to avoid division by zero
					variance = max( variance, 0.0000001 );

					// Distance from mean
					float d = shadowCoord.z - mean;

					// Chebyshev's inequality for upper bound on probability
					float p_max = variance / ( variance + d * d );

					// Reduce light bleeding by remapping [amount, 1] to [0, 1]
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );

					shadow = max( hard_shadow, p_max );

				}

			}

			return mix( 1.0, shadow, shadowIntensity );

		}

	#else // SHADOWMAP_TYPE_BASIC

		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {

			float shadow = 1.0;

			shadowCoord.xyz /= shadowCoord.w;

			#ifdef USE_REVERSED_DEPTH_BUFFER

				shadowCoord.z -= shadowBias;

			#else

				shadowCoord.z += shadowBias;

			#endif

			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;

			if ( frustumTest ) {

				float depth = texture2D( shadowMap, shadowCoord.xy ).r;

				#ifdef USE_REVERSED_DEPTH_BUFFER

					shadow = step( depth, shadowCoord.z );

				#else

					shadow = step( shadowCoord.z, depth );

				#endif

			}

			return mix( 1.0, shadow, shadowIntensity );

		}

	#endif

	#if NUM_POINT_LIGHT_SHADOWS > 0

	#if defined( SHADOWMAP_TYPE_PCF )

	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {

		float shadow = 1.0;

		// for point lights, the uniform @vShadowCoord is re-purposed to hold
		// the vector from the light to the world-space position of the fragment.
		vec3 lightToPosition = shadowCoord.xyz;

		// Direction from light to fragment
		vec3 bd3D = normalize( lightToPosition );

		// For cube shadow maps, depth is stored as distance along each face's view axis, not radial distance
		// The view-space depth is the maximum component of the direction vector (which face is sampled)
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );

		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {

			// viewZ to perspective depth

			#ifdef USE_REVERSED_DEPTH_BUFFER

				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;

			#else

				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;

			#endif

			// Hardware PCF with LinearFilter gives us 4-tap filtering per sample
			// Use Vogel disk + IGN sampling for better quality
			float texelSize = shadowRadius / shadowMapSize.x;

			// Build a tangent-space coordinate system for applying offsets
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );

			// Use IGN to rotate sampling pattern per pixel
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;

			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );

			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;

		}

		return mix( 1.0, shadow, shadowIntensity );

	}

	#elif defined( SHADOWMAP_TYPE_BASIC )

	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {

		float shadow = 1.0;

		// for point lights, the uniform @vShadowCoord is re-purposed to hold
		// the vector from the light to the world-space position of the fragment.
		vec3 lightToPosition = shadowCoord.xyz;

		// For cube shadow maps, depth is stored as distance along each face's view axis, not radial distance
		// The view-space depth is the maximum component of the direction vector (which face is sampled)
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );

		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {

			// viewZ to perspective depth

			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;

			// Direction from light to fragment
			vec3 bd3D = normalize( lightToPosition );

			float depth = textureCube( shadowMap, bd3D ).r;

			#ifdef USE_REVERSED_DEPTH_BUFFER

				depth = 1.0 - depth;

			#endif

			shadow = step( dp, depth );

		}

		return mix( 1.0, shadow, shadowIntensity );

	}

	#endif

	#endif

#endif
`,ks=`

#if NUM_SPOT_LIGHT_COORDS > 0

	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];

#endif

#ifdef USE_SHADOWMAP

	#if NUM_DIR_LIGHT_SHADOWS > 0

		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];

		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};

		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];

	#endif

	#if NUM_SPOT_LIGHT_SHADOWS > 0

		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};

		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];

	#endif

	#if NUM_POINT_LIGHT_SHADOWS > 0

		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];

		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};

		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];

	#endif

	/*
	#if NUM_RECT_AREA_LIGHTS > 0

		// TODO (abelnation): uniforms for area light shadows

	#endif
	*/

#endif
`,zs=`

#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )

	#ifdef HAS_NORMAL

		// Offsetting the position used for querying occlusion along the world normal can be used to reduce shadow acne.

		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );

	#else

		vec3 shadowWorldNormal = vec3( 0.0 ); // fallback, see #21483

	#endif

	vec4 shadowWorldPosition;

#endif

#if defined( USE_SHADOWMAP )

	#if NUM_DIR_LIGHT_SHADOWS > 0

		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {

			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;

		}
		#pragma unroll_loop_end

	#endif

	#if NUM_POINT_LIGHT_SHADOWS > 0

		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {

			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;

		}
		#pragma unroll_loop_end

	#endif

	/*
	#if NUM_RECT_AREA_LIGHTS > 0

		// TODO (abelnation): update vAreaShadowCoord with area light info

	#endif
	*/

#endif

// spot lights can be evaluated without active shadow mapping (when SpotLight.map is used)

#if NUM_SPOT_LIGHT_COORDS > 0

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {

		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;

	}
	#pragma unroll_loop_end

#endif


`,Xs=`
float getShadowMask() {

	float shadow = 1.0;

	#ifdef USE_SHADOWMAP

	#if NUM_DIR_LIGHT_SHADOWS > 0

	DirectionalLightShadow directionalLight;

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {

		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;

	}
	#pragma unroll_loop_end

	#endif

	#if NUM_SPOT_LIGHT_SHADOWS > 0

	SpotLightShadow spotLight;

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {

		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;

	}
	#pragma unroll_loop_end

	#endif

	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )

	PointLightShadow pointLight;

	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {

		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;

	}
	#pragma unroll_loop_end

	#endif

	/*
	#if NUM_RECT_AREA_LIGHTS > 0

		// TODO (abelnation): update shadow for Area light

	#endif
	*/

	#endif

	return shadow;

}
`,Ys=`
#ifdef USE_SKINNING

	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );

#endif
`,Ks=`
#ifdef USE_SKINNING

	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;

	uniform highp sampler2D boneTexture;

	mat4 getBoneMatrix( const in float i ) {

		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );

		return mat4( v1, v2, v3, v4 );

	}

#endif
`,qs=`
#ifdef USE_SKINNING

	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );

	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;

	transformed = ( bindMatrixInverse * skinned ).xyz;

#endif
`,Zs=`
#ifdef USE_SKINNING

	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;

	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;

	#ifdef USE_TANGENT

		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;

	#endif

#endif
`,$s=`
float specularStrength;

#ifdef USE_SPECULARMAP

	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;

#else

	specularStrength = 1.0;

#endif
`,Qs=`
#ifdef USE_SPECULARMAP

	uniform sampler2D specularMap;

#endif
`,Js=`
#if defined( TONE_MAPPING )

	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );

#endif
`,js=`
#ifndef saturate
// <common> may have defined saturate() already
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif

uniform float toneMappingExposure;

// exposure only
vec3 LinearToneMapping( vec3 color ) {

	return saturate( toneMappingExposure * color );

}

// source: https://www.cs.utah.edu/docs/techreports/2002/pdf/UUCS-02-001.pdf
vec3 ReinhardToneMapping( vec3 color ) {

	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );

}

// source: http://filmicworlds.com/blog/filmic-tonemapping-operators/
vec3 CineonToneMapping( vec3 color ) {

	// filmic operator by Jim Hejl and Richard Burgess-Dawson
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );

}

// source: https://github.com/selfshadow/ltc_code/blob/master/webgl/shaders/ltc/ltc_blit.fs
vec3 RRTAndODTFit( vec3 v ) {

	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;

}

// this implementation of ACES is modified to accommodate a brighter viewing environment.
// the scale factor of 1/0.6 is subjective. see discussion in #19621.

vec3 ACESFilmicToneMapping( vec3 color ) {

	// sRGB => XYZ => D65_2_D60 => AP1 => RRT_SAT
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ), // transposed from source
		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);

	// ODT_SAT => XYZ => D60_2_D65 => sRGB
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ), // transposed from source
		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);

	color *= toneMappingExposure / 0.6;

	color = ACESInputMat * color;

	// Apply RRT and ODT
	color = RRTAndODTFit( color );

	color = ACESOutputMat * color;

	// Clamp to [0, 1]
	return saturate( color );

}

// Matrices for rec 2020 <> rec 709 color space conversion
// matrix provided in row-major order so it has been transposed
// https://www.itu.int/pub/R-REP-BT.2407-2017
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);

const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);

// https://iolite-engine.com/blog_posts/minimal_agx_implementation
// Mean error^2: 3.6705141e-06
vec3 agxDefaultContrastApprox( vec3 x ) {

	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;

	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;

}

// AgX Tone Mapping implementation based on Filament, which in turn is based
// on Blender's implementation using rec 2020 primaries
// https://github.com/google/filament/pull/7236
// Inputs and outputs are encoded as Linear-sRGB.

vec3 AgXToneMapping( vec3 color ) {

	// AgX constants
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);

	// explicit AgXOutsetMatrix generated from Filaments AgXOutsetMatrixInv
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);

	// LOG2_MIN      = -10.0
	// LOG2_MAX      =  +6.5
	// MIDDLE_GRAY   =  0.18
	const float AgxMinEv = - 12.47393;  // log2( pow( 2, LOG2_MIN ) * MIDDLE_GRAY )
	const float AgxMaxEv = 4.026069;    // log2( pow( 2, LOG2_MAX ) * MIDDLE_GRAY )

	color *= toneMappingExposure;

	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;

	color = AgXInsetMatrix * color;

	// Log2 encoding
	color = max( color, 1e-10 ); // avoid 0 or negative numbers for log2
	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );

	color = clamp( color, 0.0, 1.0 );

	// Apply sigmoid
	color = agxDefaultContrastApprox( color );

	// Apply AgX look
	// v = agxLook(v, look);

	color = AgXOutsetMatrix * color;

	// Linearize
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );

	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;

	// Gamut mapping. Simple clamp for now.
	color = clamp( color, 0.0, 1.0 );

	return color;

}

// https://modelviewer.dev/examples/tone-mapping

vec3 NeutralToneMapping( vec3 color ) {

	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;

	color *= toneMappingExposure;

	float x = min( color.r, min( color.g, color.b ) );

	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;

	color -= offset;

	float peak = max( color.r, max( color.g, color.b ) );

	if ( peak < StartCompression ) return color;

	float d = 1. - StartCompression;

	float newPeak = 1. - d * d / ( peak + d - StartCompression );

	color *= newPeak / peak;

	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );

	return mix( color, vec3( newPeak ), g );

}

vec3 CustomToneMapping( vec3 color ) { return color; }
`,ec=`
#ifdef USE_TRANSMISSION

	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;

	#ifdef USE_TRANSMISSIONMAP

		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;

	#endif

	#ifdef USE_THICKNESSMAP

		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;

	#endif

	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );

	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );

	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );

	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );

#endif
`,tc=`
#ifdef USE_TRANSMISSION

	// Transmission code is based on glTF-Sampler-Viewer
	// https://github.com/KhronosGroup/glTF-Sample-Viewer

	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;

	#ifdef USE_TRANSMISSIONMAP

		uniform sampler2D transmissionMap;

	#endif

	#ifdef USE_THICKNESSMAP

		uniform sampler2D thicknessMap;

	#endif

	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;

	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;

	varying vec3 vWorldPosition;

	// Mipped Bicubic Texture Filtering by N8
	// https://www.shadertoy.com/view/Dl2SDW

	float w0( float a ) {

		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );

	}

	float w1( float a ) {

		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );

	}

	float w2( float a ){

		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );

	}

	float w3( float a ) {

		return ( 1.0 / 6.0 ) * ( a * a * a );

	}

	// g0 and g1 are the two amplitude functions
	float g0( float a ) {

		return w0( a ) + w1( a );

	}

	float g1( float a ) {

		return w2( a ) + w3( a );

	}

	// h0 and h1 are the two offset functions
	float h0( float a ) {

		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );

	}

	float h1( float a ) {

		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );

	}

	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {

		uv = uv * texelSize.zw + 0.5;

		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );

		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );

		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;

		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );

	}

	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {

		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );

	}

	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {

		// Direction of refracted light.
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );

		// Compute rotation-independent scaling of the model matrix.
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );

		// The thickness is specified in local space.
		return normalize( refractionVector ) * thickness * modelScale;

	}

	float applyIorToRoughness( const in float roughness, const in float ior ) {

		// Scale roughness with IOR so that an IOR of 1.0 results in no microfacet refraction and
		// an IOR of 1.5 results in the default amount of microfacet refraction.
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );

	}

	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {

		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );

	}

	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {

		if ( isinf( attenuationDistance ) ) {

			// Attenuation distance is +∞, i.e. the transmitted color is not attenuated at all.
			return vec3( 1.0 );

		} else {

			// Compute light attenuation using Beer's law.
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance ); // Beer's law
			return transmittance;

		}

	}

	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {

		vec4 transmittedLight;
		vec3 transmittance;

		#ifdef USE_DISPERSION

			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );

			for ( int i = 0; i < 3; i ++ ) {

				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;

				// Project refracted vector on the framebuffer, while mapping to normalized device coordinates.
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;

				// Sample framebuffer to get pixel the refracted ray hits.
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;

				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];

			}

			transmittedLight.a /= 3.0;

		#else

			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;

			// Project refracted vector on the framebuffer, while mapping to normalized device coordinates.
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;

			// Sample framebuffer to get pixel the refracted ray hits.
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );

		#endif

		vec3 attenuatedColor = transmittance * transmittedLight.rgb;

		// Get the specular component.
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );

		// As less light is transmitted, the opacity should be increased. This simple approximation does a decent job
		// of modulating a CSS background, and has no effect when the buffer is opaque, due to a solid object or clear color.
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;

		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );

	}
#endif
`,ic=`
#if defined( USE_UV ) || defined( USE_ANISOTROPY )

	varying vec2 vUv;

#endif
#ifdef USE_MAP

	varying vec2 vMapUv;

#endif
#ifdef USE_ALPHAMAP

	varying vec2 vAlphaMapUv;

#endif
#ifdef USE_LIGHTMAP

	varying vec2 vLightMapUv;

#endif
#ifdef USE_AOMAP

	varying vec2 vAoMapUv;

#endif
#ifdef USE_BUMPMAP

	varying vec2 vBumpMapUv;

#endif
#ifdef USE_NORMALMAP

	varying vec2 vNormalMapUv;

#endif
#ifdef USE_EMISSIVEMAP

	varying vec2 vEmissiveMapUv;

#endif
#ifdef USE_METALNESSMAP

	varying vec2 vMetalnessMapUv;

#endif
#ifdef USE_ROUGHNESSMAP

	varying vec2 vRoughnessMapUv;

#endif
#ifdef USE_ANISOTROPYMAP

	varying vec2 vAnisotropyMapUv;

#endif
#ifdef USE_CLEARCOATMAP

	varying vec2 vClearcoatMapUv;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

	varying vec2 vClearcoatNormalMapUv;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	varying vec2 vClearcoatRoughnessMapUv;

#endif
#ifdef USE_IRIDESCENCEMAP

	varying vec2 vIridescenceMapUv;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

	varying vec2 vIridescenceThicknessMapUv;

#endif
#ifdef USE_SHEEN_COLORMAP

	varying vec2 vSheenColorMapUv;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

	varying vec2 vSheenRoughnessMapUv;

#endif
#ifdef USE_SPECULARMAP

	varying vec2 vSpecularMapUv;

#endif
#ifdef USE_SPECULAR_COLORMAP

	varying vec2 vSpecularColorMapUv;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

	varying vec2 vSpecularIntensityMapUv;

#endif
#ifdef USE_TRANSMISSIONMAP

	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;

#endif
#ifdef USE_THICKNESSMAP

	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;

#endif
`,nc=`
#if defined( USE_UV ) || defined( USE_ANISOTROPY )

	varying vec2 vUv;

#endif
#ifdef USE_MAP

	uniform mat3 mapTransform;
	varying vec2 vMapUv;

#endif
#ifdef USE_ALPHAMAP

	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;

#endif
#ifdef USE_LIGHTMAP

	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;

#endif
#ifdef USE_AOMAP

	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;

#endif
#ifdef USE_BUMPMAP

	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;

#endif
#ifdef USE_NORMALMAP

	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;

#endif
#ifdef USE_DISPLACEMENTMAP

	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;

#endif
#ifdef USE_EMISSIVEMAP

	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;

#endif
#ifdef USE_METALNESSMAP

	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;

#endif
#ifdef USE_ROUGHNESSMAP

	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;

#endif
#ifdef USE_ANISOTROPYMAP

	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;

#endif
#ifdef USE_CLEARCOATMAP

	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;

#endif
#ifdef USE_SHEEN_COLORMAP

	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;

#endif
#ifdef USE_IRIDESCENCEMAP

	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;

#endif
#ifdef USE_SPECULARMAP

	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;

#endif
#ifdef USE_SPECULAR_COLORMAP

	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;

#endif
#ifdef USE_TRANSMISSIONMAP

	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;

#endif
#ifdef USE_THICKNESSMAP

	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;

#endif
`,ac=`
#if defined( USE_UV ) || defined( USE_ANISOTROPY )

	vUv = vec3( uv, 1 ).xy;

#endif
#ifdef USE_MAP

	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;

#endif
#ifdef USE_ALPHAMAP

	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_LIGHTMAP

	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_AOMAP

	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_BUMPMAP

	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_NORMALMAP

	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_DISPLACEMENTMAP

	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_EMISSIVEMAP

	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_METALNESSMAP

	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_ROUGHNESSMAP

	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_ANISOTROPYMAP

	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_CLEARCOATMAP

	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_CLEARCOAT_NORMALMAP

	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP

	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_IRIDESCENCEMAP

	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP

	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_SHEEN_COLORMAP

	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_SHEEN_ROUGHNESSMAP

	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_SPECULARMAP

	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_SPECULAR_COLORMAP

	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_SPECULAR_INTENSITYMAP

	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_TRANSMISSIONMAP

	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;

#endif
#ifdef USE_THICKNESSMAP

	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;

#endif
`,rc=`
#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0

	vec4 worldPosition = vec4( transformed, 1.0 );

	#ifdef USE_BATCHING

		worldPosition = batchingMatrix * worldPosition;

	#endif

	#ifdef USE_INSTANCING

		worldPosition = instanceMatrix * worldPosition;

	#endif

	worldPosition = modelMatrix * worldPosition;

#endif
`,oc=`
varying vec2 vUv;
uniform mat3 uvTransform;

void main() {

	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;

	gl_Position = vec4( position.xy, 1.0, 1.0 );

}
`,sc=`
uniform sampler2D t2D;
uniform float backgroundIntensity;

varying vec2 vUv;

void main() {

	vec4 texColor = texture2D( t2D, vUv );

	#ifdef DECODE_VIDEO_TEXTURE

		// use inline sRGB decode until browsers properly support SRGB8_ALPHA8 with video textures

		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );

	#endif

	texColor.rgb *= backgroundIntensity;

	gl_FragColor = texColor;

	#include <tonemapping_fragment>
	#include <colorspace_fragment>

}
`,cc=`
varying vec3 vWorldDirection;

#include <common>

void main() {

	vWorldDirection = transformDirection( position, modelMatrix );

	#include <begin_vertex>
	#include <project_vertex>

	gl_Position.z = gl_Position.w; // set z to camera.far

}
`,lc=`

#ifdef ENVMAP_TYPE_CUBE

	uniform samplerCube envMap;

#elif defined( ENVMAP_TYPE_CUBE_UV )

	uniform sampler2D envMap;

#endif

uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;

varying vec3 vWorldDirection;

#include <cube_uv_reflection_fragment>

void main() {

	#ifdef ENVMAP_TYPE_CUBE

		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );

	#elif defined( ENVMAP_TYPE_CUBE_UV )

		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );

	#else

		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );

	#endif

	texColor.rgb *= backgroundIntensity;

	gl_FragColor = texColor;

	#include <tonemapping_fragment>
	#include <colorspace_fragment>

}
`,fc=`
varying vec3 vWorldDirection;

#include <common>

void main() {

	vWorldDirection = transformDirection( position, modelMatrix );

	#include <begin_vertex>
	#include <project_vertex>

	gl_Position.z = gl_Position.w; // set z to camera.far

}
`,dc=`
uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;

varying vec3 vWorldDirection;

void main() {

	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );

	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;

	#include <tonemapping_fragment>
	#include <colorspace_fragment>

}
`,uc=`
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

// This is used for computing an equivalent of gl_FragCoord.z that is as high precision as possible.
// Some platforms compute gl_FragCoord at a lower precision which makes the manually computed value better for
// depth-based postprocessing effects. Reproduced on iPad with A10 processor / iPadOS 13.3.1.
varying vec2 vHighPrecisionZW;

void main() {

	#include <uv_vertex>

	#include <batching_vertex>
	#include <skinbase_vertex>

	#include <morphinstance_vertex>

	#ifdef USE_DISPLACEMENTMAP

		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>

	#endif

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>

	vHighPrecisionZW = gl_Position.zw;

}
`,pc=`
#if DEPTH_PACKING == 3200

	uniform float opacity;

#endif

#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

varying vec2 vHighPrecisionZW;

void main() {

	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>

	#if DEPTH_PACKING == 3200

		diffuseColor.a = opacity;

	#endif

	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>

	#include <logdepthbuf_fragment>

	// Higher precision equivalent of gl_FragCoord.z

	#ifdef USE_REVERSED_DEPTH_BUFFER

		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];

	#else

		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;

	#endif

	#if DEPTH_PACKING == 3200

		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );

	#elif DEPTH_PACKING == 3201

		// TODO Deprecate
		gl_FragColor = packDepthToRGBA( fragCoordZ );

	#elif DEPTH_PACKING == 3202

		// TODO Deprecate
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );

	#elif DEPTH_PACKING == 3203

		// TODO Deprecate
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );

	#endif

}
`,hc=`
#define DISTANCE

varying vec3 vWorldPosition;

#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>

	#include <batching_vertex>
	#include <skinbase_vertex>

	#include <morphinstance_vertex>

	#ifdef USE_DISPLACEMENTMAP

		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>

	#endif

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>

	vWorldPosition = worldPosition.xyz;

}
`,mc=`
#define DISTANCE

uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;

#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>

	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>

	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist ); // clamp to [ 0, 1 ]

	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );

}
`,_c=`
varying vec3 vWorldDirection;

#include <common>

void main() {

	vWorldDirection = transformDirection( position, modelMatrix );

	#include <begin_vertex>
	#include <project_vertex>

}
`,gc=`
uniform sampler2D tEquirect;

varying vec3 vWorldDirection;

#include <common>

void main() {

	vec3 direction = normalize( vWorldDirection );

	vec2 sampleUV = equirectUv( direction );

	gl_FragColor = texture2D( tEquirect, sampleUV );

	#include <tonemapping_fragment>
	#include <colorspace_fragment>

}
`,vc=`
uniform float scale;
attribute float lineDistance;

varying float vLineDistance;

#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	vLineDistance = scale * lineDistance;

	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>

}
`,Sc=`
uniform vec3 diffuse;
uniform float opacity;

uniform float dashSize;
uniform float totalSize;

varying float vLineDistance;

#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	if ( mod( vLineDistance, totalSize ) > dashSize ) {

		discard;

	}

	vec3 outgoingLight = vec3( 0.0 );

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>

	outgoingLight = diffuseColor.rgb; // simple shader

	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>

}
`,Ec=`
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>

	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )

		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>

	#endif

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>

	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>

}
`,xc=`
uniform vec3 diffuse;
uniform float opacity;

#ifndef FLAT_SHADED

	varying vec3 vNormal;

#endif

#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>

	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );

	// accumulation (baked indirect lighting only)
	#ifdef USE_LIGHTMAP

		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;

	#else

		reflectedLight.indirectDiffuse += vec3( 1.0 );

	#endif

	// modulation
	#include <aomap_fragment>

	reflectedLight.indirectDiffuse *= diffuseColor.rgb;

	vec3 outgoingLight = reflectedLight.indirectDiffuse;

	#include <envmap_fragment>

	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>

}
`,Mc=`
#define LAMBERT

varying vec3 vViewPosition;

#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>

	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>

	vViewPosition = - mvPosition.xyz;

	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>

}
`,Tc=`
#define LAMBERT

uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;

#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>

	// accumulation
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>

	// modulation
	#include <aomap_fragment>

	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;

	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>

}
`,Ac=`
#define MATCAP

varying vec3 vViewPosition;

#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>

#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>

	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>

	vViewPosition = - mvPosition.xyz;

}
`,Rc=`
#define MATCAP

uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;

varying vec3 vViewPosition;

#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>

	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5; // 0.495 to remove artifacts caused by undersized matcap disks

	#ifdef USE_MATCAP

		vec4 matcapColor = texture2D( matcap, uv );

	#else

		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 ); // default if matcap is missing

	#endif

	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;

	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>

}
`,bc=`
#define NORMAL

#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )

	varying vec3 vViewPosition;

#endif

#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>
	#include <batching_vertex>

	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>

#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )

	vViewPosition = - mvPosition.xyz;

#endif

}
`,Cc=`
#define NORMAL

uniform float opacity;

#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )

	varying vec3 vViewPosition;

#endif

#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );

	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>

	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );

	#ifdef OPAQUE

		gl_FragColor.a = 1.0;

	#endif

}
`,Pc=`
#define PHONG

varying vec3 vViewPosition;

#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>

	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>

	vViewPosition = - mvPosition.xyz;

	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>

}
`,Lc=`
#define PHONG

uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;

#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>

	// accumulation
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>

	// modulation
	#include <aomap_fragment>

	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;

	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>

}
`,wc=`
#define STANDARD

varying vec3 vViewPosition;

#ifdef USE_TRANSMISSION

	varying vec3 vWorldPosition;

#endif

#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>

	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>

	vViewPosition = - mvPosition.xyz;

	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>

#ifdef USE_TRANSMISSION

	vWorldPosition = worldPosition.xyz;

#endif
}
`,Uc=`
#define STANDARD

#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif

uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;

#ifdef IOR
	uniform float ior;
#endif

#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;

	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif

	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif

#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif

#ifdef USE_DISPERSION
	uniform float dispersion;
#endif

#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif

#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;

	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif

	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif

#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;

	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif

varying vec3 vViewPosition;

#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>

	// accumulation
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>

	// modulation
	#include <aomap_fragment>

	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;

	#include <transmission_fragment>

	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;

	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif

	#ifdef USE_CLEARCOAT

		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );

		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );

		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;

	#endif

	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>

}
`,Dc=`
#define TOON

varying vec3 vViewPosition;

#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>

	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>

	vViewPosition = - mvPosition.xyz;

	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>

}
`,Ic=`
#define TOON

uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;

#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>

	// accumulation
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>

	// modulation
	#include <aomap_fragment>

	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;

	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>

}
`,Nc=`
uniform float size;
uniform float scale;

#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

#ifdef USE_POINTS_UV

	varying vec2 vUv;
	uniform mat3 uvTransform;

#endif

void main() {

	#ifdef USE_POINTS_UV

		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;

	#endif

	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>

	gl_PointSize = size;

	#ifdef USE_SIZEATTENUATION

		bool isPerspective = isPerspectiveMatrix( projectionMatrix );

		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );

	#endif

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>

}
`,yc=`
uniform vec3 diffuse;
uniform float opacity;

#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	vec3 outgoingLight = vec3( 0.0 );

	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>

	outgoingLight = diffuseColor.rgb;

	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>

}
`,Fc=`
#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>

void main() {

	#include <batching_vertex>

	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>

	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>

	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>

}
`,Oc=`
uniform vec3 color;
uniform float opacity;

#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>

void main() {

	#include <logdepthbuf_fragment>

	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );

	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>

}
`,Bc=`
uniform float rotation;
uniform vec2 center;

#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>

void main() {

	#include <uv_vertex>

	vec4 mvPosition = modelViewMatrix[ 3 ];

	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );

	#ifndef USE_SIZEATTENUATION

		bool isPerspective = isPerspectiveMatrix( projectionMatrix );

		if ( isPerspective ) scale *= - mvPosition.z;

	#endif

	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;

	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;

	mvPosition.xy += rotatedPosition;

	gl_Position = projectionMatrix * mvPosition;

	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>

}
`,Gc=`
uniform vec3 diffuse;
uniform float opacity;

#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>

void main() {

	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>

	vec3 outgoingLight = vec3( 0.0 );

	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>

	outgoingLight = diffuseColor.rgb;

	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>

}
`,we={alphahash_fragment:ro,alphahash_pars_fragment:oo,alphamap_fragment:so,alphamap_pars_fragment:co,alphatest_fragment:lo,alphatest_pars_fragment:fo,aomap_fragment:uo,aomap_pars_fragment:po,batching_pars_vertex:ho,batching_vertex:mo,begin_vertex:_o,beginnormal_vertex:go,bsdfs:vo,iridescence_fragment:So,bumpmap_pars_fragment:Eo,clipping_planes_fragment:xo,clipping_planes_pars_fragment:Mo,clipping_planes_pars_vertex:To,clipping_planes_vertex:Ao,color_fragment:Ro,color_pars_fragment:bo,color_pars_vertex:Co,color_vertex:Po,common:Lo,cube_uv_reflection_fragment:wo,defaultnormal_vertex:Uo,displacementmap_pars_vertex:Do,displacementmap_vertex:Io,emissivemap_fragment:No,emissivemap_pars_fragment:yo,colorspace_fragment:Fo,colorspace_pars_fragment:Oo,envmap_fragment:Bo,envmap_common_pars_fragment:Go,envmap_pars_fragment:Ho,envmap_pars_vertex:Vo,envmap_physical_pars_fragment:Jo,envmap_vertex:Wo,fog_vertex:ko,fog_pars_vertex:zo,fog_fragment:Xo,fog_pars_fragment:Yo,gradientmap_pars_fragment:Ko,lightmap_pars_fragment:qo,lights_lambert_fragment:Zo,lights_lambert_pars_fragment:$o,lights_pars_begin:Qo,lights_toon_fragment:jo,lights_toon_pars_fragment:es,lights_phong_fragment:ts,lights_phong_pars_fragment:is,lights_physical_fragment:ns,lights_physical_pars_fragment:as,lights_fragment_begin:rs,lights_fragment_maps:os,lights_fragment_end:ss,lightprobes_pars_fragment:cs,logdepthbuf_fragment:ls,logdepthbuf_pars_fragment:fs,logdepthbuf_pars_vertex:ds,logdepthbuf_vertex:us,map_fragment:ps,map_pars_fragment:hs,map_particle_fragment:ms,map_particle_pars_fragment:_s,metalnessmap_fragment:gs,metalnessmap_pars_fragment:vs,morphinstance_vertex:Ss,morphcolor_vertex:Es,morphnormal_vertex:xs,morphtarget_pars_vertex:Ms,morphtarget_vertex:Ts,normal_fragment_begin:As,normal_fragment_maps:Rs,normal_pars_fragment:bs,normal_pars_vertex:Cs,normal_vertex:Ps,normalmap_pars_fragment:Ls,clearcoat_normal_fragment_begin:ws,clearcoat_normal_fragment_maps:Us,clearcoat_pars_fragment:Ds,iridescence_pars_fragment:Is,opaque_fragment:Ns,packing:ys,premultiplied_alpha_fragment:Fs,project_vertex:Os,dithering_fragment:Bs,dithering_pars_fragment:Gs,roughnessmap_fragment:Hs,roughnessmap_pars_fragment:Vs,shadowmap_pars_fragment:Ws,shadowmap_pars_vertex:ks,shadowmap_vertex:zs,shadowmask_pars_fragment:Xs,skinbase_vertex:Ys,skinning_pars_vertex:Ks,skinning_vertex:qs,skinnormal_vertex:Zs,specularmap_fragment:$s,specularmap_pars_fragment:Qs,tonemapping_fragment:Js,tonemapping_pars_fragment:js,transmission_fragment:ec,transmission_pars_fragment:tc,uv_pars_fragment:ic,uv_pars_vertex:nc,uv_vertex:ac,worldpos_vertex:rc,background_vert:oc,background_frag:sc,backgroundCube_vert:cc,backgroundCube_frag:lc,cube_vert:fc,cube_frag:dc,depth_vert:uc,depth_frag:pc,distance_vert:hc,distance_frag:mc,equirect_vert:_c,equirect_frag:gc,linedashed_vert:vc,linedashed_frag:Sc,meshbasic_vert:Ec,meshbasic_frag:xc,meshlambert_vert:Mc,meshlambert_frag:Tc,meshmatcap_vert:Ac,meshmatcap_frag:Rc,meshnormal_vert:bc,meshnormal_frag:Cc,meshphong_vert:Pc,meshphong_frag:Lc,meshphysical_vert:wc,meshphysical_frag:Uc,meshtoon_vert:Dc,meshtoon_frag:Ic,points_vert:Nc,points_frag:yc,shadow_vert:Fc,shadow_frag:Oc,sprite_vert:Bc,sprite_frag:Gc},se={common:{diffuse:{value:new Qe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ie}},envmap:{envMap:{value:null},envMapRotation:{value:new Ie},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ie}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ie}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ie},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ie},normalScale:{value:new _t(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ie},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ie}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ie}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ie}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Qe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new Fe},probesMax:{value:new Fe},probesResolution:{value:new Fe}},points:{diffuse:{value:new Qe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0},uvTransform:{value:new Ie}},sprite:{diffuse:{value:new Qe(16777215)},opacity:{value:1},center:{value:new _t(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}}},Rt={basic:{uniforms:ht([se.common,se.specularmap,se.envmap,se.aomap,se.lightmap,se.fog]),vertexShader:we.meshbasic_vert,fragmentShader:we.meshbasic_frag},lambert:{uniforms:ht([se.common,se.specularmap,se.envmap,se.aomap,se.lightmap,se.emissivemap,se.bumpmap,se.normalmap,se.displacementmap,se.fog,se.lights,{emissive:{value:new Qe(0)},envMapIntensity:{value:1}}]),vertexShader:we.meshlambert_vert,fragmentShader:we.meshlambert_frag},phong:{uniforms:ht([se.common,se.specularmap,se.envmap,se.aomap,se.lightmap,se.emissivemap,se.bumpmap,se.normalmap,se.displacementmap,se.fog,se.lights,{emissive:{value:new Qe(0)},specular:{value:new Qe(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:we.meshphong_vert,fragmentShader:we.meshphong_frag},standard:{uniforms:ht([se.common,se.envmap,se.aomap,se.lightmap,se.emissivemap,se.bumpmap,se.normalmap,se.displacementmap,se.roughnessmap,se.metalnessmap,se.fog,se.lights,{emissive:{value:new Qe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:we.meshphysical_vert,fragmentShader:we.meshphysical_frag},toon:{uniforms:ht([se.common,se.aomap,se.lightmap,se.emissivemap,se.bumpmap,se.normalmap,se.displacementmap,se.gradientmap,se.fog,se.lights,{emissive:{value:new Qe(0)}}]),vertexShader:we.meshtoon_vert,fragmentShader:we.meshtoon_frag},matcap:{uniforms:ht([se.common,se.bumpmap,se.normalmap,se.displacementmap,se.fog,{matcap:{value:null}}]),vertexShader:we.meshmatcap_vert,fragmentShader:we.meshmatcap_frag},points:{uniforms:ht([se.points,se.fog]),vertexShader:we.points_vert,fragmentShader:we.points_frag},dashed:{uniforms:ht([se.common,se.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:we.linedashed_vert,fragmentShader:we.linedashed_frag},depth:{uniforms:ht([se.common,se.displacementmap]),vertexShader:we.depth_vert,fragmentShader:we.depth_frag},normal:{uniforms:ht([se.common,se.bumpmap,se.normalmap,se.displacementmap,{opacity:{value:1}}]),vertexShader:we.meshnormal_vert,fragmentShader:we.meshnormal_frag},sprite:{uniforms:ht([se.sprite,se.fog]),vertexShader:we.sprite_vert,fragmentShader:we.sprite_frag},background:{uniforms:{uvTransform:{value:new Ie},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:we.background_vert,fragmentShader:we.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ie}},vertexShader:we.backgroundCube_vert,fragmentShader:we.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:we.cube_vert,fragmentShader:we.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:we.equirect_vert,fragmentShader:we.equirect_frag},distance:{uniforms:ht([se.common,se.displacementmap,{referencePosition:{value:new Fe},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:we.distance_vert,fragmentShader:we.distance_frag},shadow:{uniforms:ht([se.lights,se.fog,{color:{value:new Qe(0)},opacity:{value:1}}]),vertexShader:we.shadow_vert,fragmentShader:we.shadow_frag}};Rt.physical={uniforms:ht([Rt.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ie},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ie},clearcoatNormalScale:{value:new _t(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ie},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ie},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ie},sheen:{value:0},sheenColor:{value:new Qe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ie},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ie},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ie},transmissionSamplerSize:{value:new _t},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ie},attenuationDistance:{value:0},attenuationColor:{value:new Qe(0)},specularColor:{value:new Qe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ie},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ie},anisotropyVector:{value:new _t},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ie}}]),vertexShader:we.meshphysical_vert,fragmentShader:we.meshphysical_frag};const si={r:0,b:0,g:0},Hc=new Xt,Ma=new Ie;Ma.set(-1,0,0,0,1,0,0,0,1);function Vc(e,i,t,n,f,c){const u=new Qe(0);let g=f===!0?0:1,H,T,q=null,G=0,p=null;function x(N){let O=N.isScene===!0?N.background:null;if(O&&O.isTexture){const m=N.backgroundBlurriness>0;O=i.get(O,m)}return O}function U(N){let O=!1;const m=x(N);m===null?l(u,g):m&&m.isColor&&(l(m,1),O=!0);const b=e.xr.getEnvironmentBlendMode();b==="additive"?t.buffers.color.setClear(0,0,0,1,c):b==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,c),(e.autoClear||O)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function Y(N,O){const m=x(O);m&&(m.isCubeTexture||m.mapping===yi)?(T===void 0&&(T=new zt(new jn(1,1,1),new ei({name:"BackgroundCubeMaterial",uniforms:Pi(Rt.backgroundCube.uniforms),vertexShader:Rt.backgroundCube.vertexShader,fragmentShader:Rt.backgroundCube.fragmentShader,side:St,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),T.geometry.deleteAttribute("normal"),T.geometry.deleteAttribute("uv"),T.onBeforeRender=function(b,v,D){this.matrixWorld.copyPosition(D.matrixWorld)},Object.defineProperty(T.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(T)),T.material.uniforms.envMap.value=m,T.material.uniforms.backgroundBlurriness.value=O.backgroundBlurriness,T.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,T.material.uniforms.backgroundRotation.value.setFromMatrix4(Hc.makeRotationFromEuler(O.backgroundRotation)).transpose(),m.isCubeTexture&&m.isRenderTargetTexture===!1&&T.material.uniforms.backgroundRotation.value.premultiply(Ma),T.material.toneMapped=$e.getTransfer(m.colorSpace)!==qe,(q!==m||G!==m.version||p!==e.toneMapping)&&(T.material.needsUpdate=!0,q=m,G=m.version,p=e.toneMapping),T.layers.enableAll(),N.unshift(T,T.geometry,T.material,0,0,null)):m&&m.isTexture&&(H===void 0&&(H=new zt(new ea(2,2),new ei({name:"BackgroundMaterial",uniforms:Pi(Rt.background.uniforms),vertexShader:Rt.background.vertexShader,fragmentShader:Rt.background.fragmentShader,side:ti,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),H.geometry.deleteAttribute("normal"),Object.defineProperty(H.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(H)),H.material.uniforms.t2D.value=m,H.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,H.material.toneMapped=$e.getTransfer(m.colorSpace)!==qe,m.matrixAutoUpdate===!0&&m.updateMatrix(),H.material.uniforms.uvTransform.value.copy(m.matrix),(q!==m||G!==m.version||p!==e.toneMapping)&&(H.material.needsUpdate=!0,q=m,G=m.version,p=e.toneMapping),H.layers.enableAll(),N.unshift(H,H.geometry,H.material,0,0,null))}function l(N,O){N.getRGB(si,ta(e)),t.buffers.color.setClear(si.r,si.g,si.b,O,c)}function o(){T!==void 0&&(T.geometry.dispose(),T.material.dispose(),T=void 0),H!==void 0&&(H.geometry.dispose(),H.material.dispose(),H=void 0)}return{getClearColor:function(){return u},setClearColor:function(N,O=1){u.set(N),g=O,l(u,g)},getClearAlpha:function(){return g},setClearAlpha:function(N){g=N,l(u,g)},render:U,addToRenderList:Y,dispose:o}}function Wc(e,i){const t=e.getParameter(e.MAX_VERTEX_ATTRIBS),n={},f=p(null);let c=f,u=!1;function g(A,I,Q,Z,V){let z=!1;const B=G(A,Z,Q,I);c!==B&&(c=B,T(c.object)),z=x(A,Z,Q,V),z&&U(A,Z,Q,V),V!==null&&i.update(V,e.ELEMENT_ARRAY_BUFFER),(z||u)&&(u=!1,m(A,I,Q,Z),V!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,i.get(V).buffer))}function H(){return e.createVertexArray()}function T(A){return e.bindVertexArray(A)}function q(A){return e.deleteVertexArray(A)}function G(A,I,Q,Z){const V=Z.wireframe===!0;let z=n[I.id];z===void 0&&(z={},n[I.id]=z);const B=A.isInstancedMesh===!0?A.id:0;let $=z[B];$===void 0&&($={},z[B]=$);let le=$[Q.id];le===void 0&&(le={},$[Q.id]=le);let ge=le[V];return ge===void 0&&(ge=p(H()),le[V]=ge),ge}function p(A){const I=[],Q=[],Z=[];for(let V=0;V<t;V++)I[V]=0,Q[V]=0,Z[V]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:I,enabledAttributes:Q,attributeDivisors:Z,object:A,attributes:{},index:null}}function x(A,I,Q,Z){const V=c.attributes,z=I.attributes;let B=0;const $=Q.getAttributes();for(const le in $)if($[le].location>=0){const ve=V[le];let xe=z[le];if(xe===void 0&&(le==="instanceMatrix"&&A.instanceMatrix&&(xe=A.instanceMatrix),le==="instanceColor"&&A.instanceColor&&(xe=A.instanceColor)),ve===void 0||ve.attribute!==xe||xe&&ve.data!==xe.data)return!0;B++}return c.attributesNum!==B||c.index!==Z}function U(A,I,Q,Z){const V={},z=I.attributes;let B=0;const $=Q.getAttributes();for(const le in $)if($[le].location>=0){let ve=z[le];ve===void 0&&(le==="instanceMatrix"&&A.instanceMatrix&&(ve=A.instanceMatrix),le==="instanceColor"&&A.instanceColor&&(ve=A.instanceColor));const xe={};xe.attribute=ve,ve&&ve.data&&(xe.data=ve.data),V[le]=xe,B++}c.attributes=V,c.attributesNum=B,c.index=Z}function Y(){const A=c.newAttributes;for(let I=0,Q=A.length;I<Q;I++)A[I]=0}function l(A){o(A,0)}function o(A,I){const Q=c.newAttributes,Z=c.enabledAttributes,V=c.attributeDivisors;Q[A]=1,Z[A]===0&&(e.enableVertexAttribArray(A),Z[A]=1),V[A]!==I&&(e.vertexAttribDivisor(A,I),V[A]=I)}function N(){const A=c.newAttributes,I=c.enabledAttributes;for(let Q=0,Z=I.length;Q<Z;Q++)I[Q]!==A[Q]&&(e.disableVertexAttribArray(Q),I[Q]=0)}function O(A,I,Q,Z,V,z,B){B===!0?e.vertexAttribIPointer(A,I,Q,V,z):e.vertexAttribPointer(A,I,Q,Z,V,z)}function m(A,I,Q,Z){Y();const V=Z.attributes,z=Q.getAttributes(),B=I.defaultAttributeValues;for(const $ in z){const le=z[$];if(le.location>=0){let ge=V[$];if(ge===void 0&&($==="instanceMatrix"&&A.instanceMatrix&&(ge=A.instanceMatrix),$==="instanceColor"&&A.instanceColor&&(ge=A.instanceColor)),ge!==void 0){const ve=ge.normalized,xe=ge.itemSize,Xe=i.get(ge);if(Xe===void 0)continue;const at=Xe.buffer,He=Xe.type,X=Xe.bytesPerElement,te=He===e.INT||He===e.UNSIGNED_INT||ge.gpuType===ia;if(ge.isInterleavedBufferAttribute){const J=ge.data,be=J.stride,Ce=ge.offset;if(J.isInstancedInterleavedBuffer){for(let Ae=0;Ae<le.locationSize;Ae++)o(le.location+Ae,J.meshPerAttribute);A.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=J.meshPerAttribute*J.count)}else for(let Ae=0;Ae<le.locationSize;Ae++)l(le.location+Ae);e.bindBuffer(e.ARRAY_BUFFER,at);for(let Ae=0;Ae<le.locationSize;Ae++)O(le.location+Ae,xe/le.locationSize,He,ve,be*X,(Ce+xe/le.locationSize*Ae)*X,te)}else{if(ge.isInstancedBufferAttribute){for(let J=0;J<le.locationSize;J++)o(le.location+J,ge.meshPerAttribute);A.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=ge.meshPerAttribute*ge.count)}else for(let J=0;J<le.locationSize;J++)l(le.location+J);e.bindBuffer(e.ARRAY_BUFFER,at);for(let J=0;J<le.locationSize;J++)O(le.location+J,xe/le.locationSize,He,ve,xe*X,xe/le.locationSize*J*X,te)}}else if(B!==void 0){const ve=B[$];if(ve!==void 0)switch(ve.length){case 2:e.vertexAttrib2fv(le.location,ve);break;case 3:e.vertexAttrib3fv(le.location,ve);break;case 4:e.vertexAttrib4fv(le.location,ve);break;default:e.vertexAttrib1fv(le.location,ve)}}}}N()}function b(){h();for(const A in n){const I=n[A];for(const Q in I){const Z=I[Q];for(const V in Z){const z=Z[V];for(const B in z)q(z[B].object),delete z[B];delete Z[V]}}delete n[A]}}function v(A){if(n[A.id]===void 0)return;const I=n[A.id];for(const Q in I){const Z=I[Q];for(const V in Z){const z=Z[V];for(const B in z)q(z[B].object),delete z[B];delete Z[V]}}delete n[A.id]}function D(A){for(const I in n){const Q=n[I];for(const Z in Q){const V=Q[Z];if(V[A.id]===void 0)continue;const z=V[A.id];for(const B in z)q(z[B].object),delete z[B];delete V[A.id]}}}function s(A){for(const I in n){const Q=n[I],Z=A.isInstancedMesh===!0?A.id:0,V=Q[Z];if(V!==void 0){for(const z in V){const B=V[z];for(const $ in B)q(B[$].object),delete B[$];delete V[z]}delete Q[Z],Object.keys(Q).length===0&&delete n[I]}}}function h(){L(),u=!0,c!==f&&(c=f,T(c.object))}function L(){f.geometry=null,f.program=null,f.wireframe=!1}return{setup:g,reset:h,resetDefaultState:L,dispose:b,releaseStatesOfGeometry:v,releaseStatesOfObject:s,releaseStatesOfProgram:D,initAttributes:Y,enableAttribute:l,disableUnusedAttributes:N}}function kc(e,i,t){let n;function f(H){n=H}function c(H,T){e.drawArrays(n,H,T),t.update(T,n,1)}function u(H,T,q){q!==0&&(e.drawArraysInstanced(n,H,T,q),t.update(T,n,q))}function g(H,T,q){if(q===0)return;i.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,H,0,T,0,q);let p=0;for(let x=0;x<q;x++)p+=T[x];t.update(p,n,1)}this.setMode=f,this.render=c,this.renderInstances=u,this.renderMultiDraw=g}function zc(e,i,t,n){let f;function c(){if(f!==void 0)return f;if(i.has("EXT_texture_filter_anisotropic")===!0){const D=i.get("EXT_texture_filter_anisotropic");f=e.getParameter(D.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else f=0;return f}function u(D){return!(D!==Nt&&n.convert(D)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT))}function g(D){const s=D===Ot&&(i.has("EXT_color_buffer_half_float")||i.has("EXT_color_buffer_float"));return!(D!==bt&&n.convert(D)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE)&&D!==It&&!s)}function H(D){if(D==="highp"){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return"highp";D="mediump"}return D==="mediump"&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let T=t.precision!==void 0?t.precision:"highp";const q=H(T);q!==T&&(Ge("WebGLRenderer:",T,"not supported, using",q,"instead."),T=q);const G=t.logarithmicDepthBuffer===!0,p=t.reversedDepthBuffer===!0&&i.has("EXT_clip_control");t.reversedDepthBuffer===!0&&p===!1&&Ge("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const x=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),U=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),Y=e.getParameter(e.MAX_TEXTURE_SIZE),l=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),o=e.getParameter(e.MAX_VERTEX_ATTRIBS),N=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),O=e.getParameter(e.MAX_VARYING_VECTORS),m=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),b=e.getParameter(e.MAX_SAMPLES),v=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:H,textureFormatReadable:u,textureTypeReadable:g,precision:T,logarithmicDepthBuffer:G,reversedDepthBuffer:p,maxTextures:x,maxVertexTextures:U,maxTextureSize:Y,maxCubemapSize:l,maxAttributes:o,maxVertexUniforms:N,maxVaryings:O,maxFragmentUniforms:m,maxSamples:b,samples:v}}function Xc(e){const i=this;let t=null,n=0,f=!1,c=!1;const u=new Fa,g=new Ie,H={value:null,needsUpdate:!1};this.uniform=H,this.numPlanes=0,this.numIntersection=0,this.init=function(G,p){const x=G.length!==0||p||n!==0||f;return f=p,n=G.length,x},this.beginShadows=function(){c=!0,q(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(G,p){t=q(G,p,0)},this.setState=function(G,p,x){const U=G.clippingPlanes,Y=G.clipIntersection,l=G.clipShadows,o=e.get(G);if(!f||U===null||U.length===0||c&&!l)c?q(null):T();else{const N=c?0:n,O=N*4;let m=o.clippingState||null;H.value=m,m=q(U,p,O,x);for(let b=0;b!==O;++b)m[b]=t[b];o.clippingState=m,this.numIntersection=Y?this.numPlanes:0,this.numPlanes+=N}};function T(){H.value!==t&&(H.value=t,H.needsUpdate=n>0),i.numPlanes=n,i.numIntersection=0}function q(G,p,x,U){const Y=G!==null?G.length:0;let l=null;if(Y!==0){if(l=H.value,U!==!0||l===null){const o=x+Y*4,N=p.matrixWorldInverse;g.getNormalMatrix(N),(l===null||l.length<o)&&(l=new Float32Array(o));for(let O=0,m=x;O!==Y;++O,m+=4)u.copy(G[O]).applyMatrix4(N,g),u.normal.toArray(l,m),l[m+3]=u.constant}H.value=l,H.needsUpdate=!0}return i.numPlanes=Y,i.numIntersection=0,l}}class Ta extends Pt{constructor(i=1,t={}){super(i,i,t),this.isWebGLCubeRenderTarget=!0;const n={width:i,height:i,depth:1},f=[n,n,n,n,n,n];this.texture=new na(f),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(i,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},f=new jn(5,5,5),c=new ei({name:"CubemapFromEquirect",uniforms:Pi(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:St,blending:jt});c.uniforms.tEquirect.value=t;const u=new zt(f,c),g=t.minFilter;return t.minFilter===Wt&&(t.minFilter=Et),new Oa(1,10,this).update(i,u),t.minFilter=g,u.geometry.dispose(),u.material.dispose(),this}clear(i,t=!0,n=!0,f=!0){const c=i.getRenderTarget();for(let u=0;u<6;u++)i.setRenderTarget(this,u),i.clear(t,n,f);i.setRenderTarget(c)}}function Yc(e){let i=new WeakMap,t=new WeakMap,n=null;function f(p,x=!1){return p==null?null:x?u(p):c(p)}function c(p){if(p&&p.isTexture){const x=p.mapping;if(x===gi||x===vi)if(i.has(p)){const U=i.get(p).texture;return g(U,p.mapping)}else{const U=p.image;if(U&&U.height>0){const Y=new Ta(U.height);return Y.fromEquirectangularTexture(e,p),i.set(p,Y),p.addEventListener("dispose",T),g(Y.texture,p.mapping)}else return null}}return p}function u(p){if(p&&p.isTexture){const x=p.mapping,U=x===gi||x===vi,Y=x===Li||x===ui;if(U||Y){let l=t.get(p);const o=l!==void 0?l.texture.pmremVersion:0;if(p.isRenderTargetTexture&&p.pmremVersion!==o)return n===null&&(n=new Ki(e)),l=U?n.fromEquirectangular(p,l):n.fromCubemap(p,l),l.texture.pmremVersion=p.pmremVersion,t.set(p,l),l.texture;if(l!==void 0)return l.texture;{const N=p.image;return U&&N&&N.height>0||Y&&N&&H(N)?(n===null&&(n=new Ki(e)),l=U?n.fromEquirectangular(p):n.fromCubemap(p),l.texture.pmremVersion=p.pmremVersion,t.set(p,l),p.addEventListener("dispose",q),l.texture):null}}}return p}function g(p,x){return x===gi?p.mapping=Li:x===vi&&(p.mapping=ui),p}function H(p){let x=0;const U=6;for(let Y=0;Y<U;Y++)p[Y]!==void 0&&x++;return x===U}function T(p){const x=p.target;x.removeEventListener("dispose",T);const U=i.get(x);U!==void 0&&(i.delete(x),U.dispose())}function q(p){const x=p.target;x.removeEventListener("dispose",q);const U=t.get(x);U!==void 0&&(t.delete(x),U.dispose())}function G(){i=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:f,dispose:G}}function Kc(e){const i={};function t(n){if(i[n]!==void 0)return i[n];const f=e.getExtension(n);return i[n]=f,f}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const f=t(n);return f===null&&Ba("WebGLRenderer: "+n+" extension not supported."),f}}}function qc(e,i,t,n){const f={},c=new WeakMap;function u(G){const p=G.target;p.index!==null&&i.remove(p.index);for(const U in p.attributes)i.remove(p.attributes[U]);p.removeEventListener("dispose",u),delete f[p.id];const x=c.get(p);x&&(i.remove(x),c.delete(p)),n.releaseStatesOfGeometry(p),p.isInstancedBufferGeometry===!0&&delete p._maxInstanceCount,t.memory.geometries--}function g(G,p){return f[p.id]===!0||(p.addEventListener("dispose",u),f[p.id]=!0,t.memory.geometries++),p}function H(G){const p=G.attributes;for(const x in p)i.update(p[x],e.ARRAY_BUFFER)}function T(G){const p=[],x=G.index,U=G.attributes.position;let Y=0;if(U===void 0)return;if(x!==null){const N=x.array;Y=x.version;for(let O=0,m=N.length;O<m;O+=3){const b=N[O+0],v=N[O+1],D=N[O+2];p.push(b,v,v,D,D,b)}}else{const N=U.array;Y=U.version;for(let O=0,m=N.length/3-1;O<m;O+=3){const b=O+0,v=O+1,D=O+2;p.push(b,v,v,D,D,b)}}const l=new(U.count>=65535?Ga:Ha)(p,1);l.version=Y;const o=c.get(G);o&&i.remove(o),c.set(G,l)}function q(G){const p=c.get(G);if(p){const x=G.index;x!==null&&p.version<x.version&&T(G)}else T(G);return c.get(G)}return{get:g,update:H,getWireframeAttribute:q}}function Zc(e,i,t){let n;function f(G){n=G}let c,u;function g(G){c=G.type,u=G.bytesPerElement}function H(G,p){e.drawElements(n,p,c,G*u),t.update(p,n,1)}function T(G,p,x){x!==0&&(e.drawElementsInstanced(n,p,c,G*u,x),t.update(p,n,x))}function q(G,p,x){if(x===0)return;i.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,p,0,c,G,0,x);let Y=0;for(let l=0;l<x;l++)Y+=p[l];t.update(Y,n,1)}this.setMode=f,this.setIndex=g,this.render=H,this.renderInstances=T,this.renderMultiDraw=q}function $c(e){const i={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(c,u,g){switch(t.calls++,u){case e.TRIANGLES:t.triangles+=g*(c/3);break;case e.LINES:t.lines+=g*(c/2);break;case e.LINE_STRIP:t.lines+=g*(c-1);break;case e.LINE_LOOP:t.lines+=g*c;break;case e.POINTS:t.points+=g*c;break;default:Ze("WebGLInfo: Unknown draw mode:",u);break}}function f(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:i,render:t,programs:null,autoReset:!0,reset:f,update:n}}function Qc(e,i,t){const n=new WeakMap,f=new mt;function c(u,g,H){const T=u.morphTargetInfluences,q=g.morphAttributes.position||g.morphAttributes.normal||g.morphAttributes.color,G=q!==void 0?q.length:0;let p=n.get(g);if(p===void 0||p.count!==G){let h=function(){D.dispose(),n.delete(g),g.removeEventListener("dispose",h)};p!==void 0&&p.texture.dispose();const x=g.morphAttributes.position!==void 0,U=g.morphAttributes.normal!==void 0,Y=g.morphAttributes.color!==void 0,l=g.morphAttributes.position||[],o=g.morphAttributes.normal||[],N=g.morphAttributes.color||[];let O=0;x===!0&&(O=1),U===!0&&(O=2),Y===!0&&(O=3);let m=g.attributes.position.count*O,b=1;m>i.maxTextureSize&&(b=Math.ceil(m/i.maxTextureSize),m=i.maxTextureSize);const v=new Float32Array(m*b*4*G),D=new aa(v,m,b,G);D.type=It,D.needsUpdate=!0;const s=O*4;for(let L=0;L<G;L++){const A=l[L],I=o[L],Q=N[L],Z=m*b*4*L;for(let V=0;V<A.count;V++){const z=V*s;x===!0&&(f.fromBufferAttribute(A,V),v[Z+z+0]=f.x,v[Z+z+1]=f.y,v[Z+z+2]=f.z,v[Z+z+3]=0),U===!0&&(f.fromBufferAttribute(I,V),v[Z+z+4]=f.x,v[Z+z+5]=f.y,v[Z+z+6]=f.z,v[Z+z+7]=0),Y===!0&&(f.fromBufferAttribute(Q,V),v[Z+z+8]=f.x,v[Z+z+9]=f.y,v[Z+z+10]=f.z,v[Z+z+11]=Q.itemSize===4?f.w:1)}}p={count:G,texture:D,size:new _t(m,b)},n.set(g,p),g.addEventListener("dispose",h)}if(u.isInstancedMesh===!0&&u.morphTexture!==null)H.getUniforms().setValue(e,"morphTexture",u.morphTexture,t);else{let x=0;for(let Y=0;Y<T.length;Y++)x+=T[Y];const U=g.morphTargetsRelative?1:1-x;H.getUniforms().setValue(e,"morphTargetBaseInfluence",U),H.getUniforms().setValue(e,"morphTargetInfluences",T)}H.getUniforms().setValue(e,"morphTargetsTexture",p.texture,t),H.getUniforms().setValue(e,"morphTargetsTextureSize",p.size)}return{update:c}}function Jc(e,i,t,n,f){let c=new WeakMap;function u(T){const q=f.render.frame,G=T.geometry,p=i.get(T,G);if(c.get(p)!==q&&(i.update(p),c.set(p,q)),T.isInstancedMesh&&(T.hasEventListener("dispose",H)===!1&&T.addEventListener("dispose",H),c.get(T)!==q&&(t.update(T.instanceMatrix,e.ARRAY_BUFFER),T.instanceColor!==null&&t.update(T.instanceColor,e.ARRAY_BUFFER),c.set(T,q))),T.isSkinnedMesh){const x=T.skeleton;c.get(x)!==q&&(x.update(),c.set(x,q))}return p}function g(){c=new WeakMap}function H(T){const q=T.target;q.removeEventListener("dispose",H),n.releaseStatesOfObject(q),t.remove(q.instanceMatrix),q.instanceColor!==null&&t.remove(q.instanceColor)}return{update:u,dispose:g}}const jc={[ua]:"LINEAR_TONE_MAPPING",[da]:"REINHARD_TONE_MAPPING",[fa]:"CINEON_TONE_MAPPING",[la]:"ACES_FILMIC_TONE_MAPPING",[ca]:"AGX_TONE_MAPPING",[sa]:"NEUTRAL_TONE_MAPPING",[oa]:"CUSTOM_TONE_MAPPING"};function el(e,i,t,n,f,c){const u=new Pt(i,t,{type:e,depthBuffer:f,stencilBuffer:c,samples:n?4:0,depthTexture:f?new ii(i,t):void 0}),g=new Pt(i,t,{type:Ot,depthBuffer:!1,stencilBuffer:!1}),H=new ra;H.setAttribute("position",new qi([-1,3,0,-1,-1,0,3,-1,0],3)),H.setAttribute("uv",new qi([0,2,0,0,2,0],2));const T=new Va({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),q=new zt(H,T),G=new Wa(-1,1,1,-1,0,1);let p=null,x=null,U=!1,Y,l=null,o=[],N=!1;this.setSize=function(O,m){u.setSize(O,m),g.setSize(O,m);for(let b=0;b<o.length;b++){const v=o[b];v.setSize&&v.setSize(O,m)}},this.setEffects=function(O){o=O,N=o.length>0&&o[0].isRenderPass===!0;const m=u.width,b=u.height;for(let v=0;v<o.length;v++){const D=o[v];D.setSize&&D.setSize(m,b)}},this.begin=function(O,m){if(U||O.toneMapping===Lt&&o.length===0)return!1;if(l=m,m!==null){const b=m.width,v=m.height;(u.width!==b||u.height!==v)&&this.setSize(b,v)}return N===!1&&O.setRenderTarget(u),Y=O.toneMapping,O.toneMapping=Lt,!0},this.hasRenderPass=function(){return N},this.end=function(O,m){O.toneMapping=Y,U=!0;let b=u,v=g;for(let D=0;D<o.length;D++){const s=o[D];if(s.enabled!==!1&&(s.render(O,v,b,m),s.needsSwap!==!1)){const h=b;b=v,v=h}}if(p!==O.outputColorSpace||x!==O.toneMapping){p=O.outputColorSpace,x=O.toneMapping,T.defines={},$e.getTransfer(p)===qe&&(T.defines.SRGB_TRANSFER="");const D=jc[x];D&&(T.defines[D]=""),T.needsUpdate=!0}T.uniforms.tDiffuse.value=b.texture,O.setRenderTarget(l),O.render(q,G),l=null,U=!1},this.isCompositing=function(){return U},this.dispose=function(){u.depthTexture&&u.depthTexture.dispose(),u.dispose(),g.dispose(),H.dispose(),T.dispose()}}const Aa=new za,Ii=new ii(1,1),Ra=new aa,ba=new ka,Ca=new na,Fn=[],On=[],Bn=new Float32Array(16),Gn=new Float32Array(9),Hn=new Float32Array(4);function qt(e,i,t){const n=e[0];if(n<=0||n>0)return e;const f=i*t;let c=Fn[f];if(c===void 0&&(c=new Float32Array(f),Fn[f]=c),i!==0){n.toArray(c,0);for(let u=1,g=0;u!==i;++u)g+=t,e[u].toArray(c,g)}return c}function ct(e,i){if(e.length!==i.length)return!1;for(let t=0,n=e.length;t<n;t++)if(e[t]!==i[t])return!1;return!0}function lt(e,i){for(let t=0,n=i.length;t<n;t++)e[t]=i[t]}function hi(e,i){let t=On[i];t===void 0&&(t=new Int32Array(i),On[i]=t);for(let n=0;n!==i;++n)t[n]=e.allocateTextureUnit();return t}function tl(e,i){const t=this.cache;t[0]!==i&&(e.uniform1f(this.addr,i),t[0]=i)}function il(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y)&&(e.uniform2f(this.addr,i.x,i.y),t[0]=i.x,t[1]=i.y);else{if(ct(t,i))return;e.uniform2fv(this.addr,i),lt(t,i)}}function nl(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y||t[2]!==i.z)&&(e.uniform3f(this.addr,i.x,i.y,i.z),t[0]=i.x,t[1]=i.y,t[2]=i.z);else if(i.r!==void 0)(t[0]!==i.r||t[1]!==i.g||t[2]!==i.b)&&(e.uniform3f(this.addr,i.r,i.g,i.b),t[0]=i.r,t[1]=i.g,t[2]=i.b);else{if(ct(t,i))return;e.uniform3fv(this.addr,i),lt(t,i)}}function al(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y||t[2]!==i.z||t[3]!==i.w)&&(e.uniform4f(this.addr,i.x,i.y,i.z,i.w),t[0]=i.x,t[1]=i.y,t[2]=i.z,t[3]=i.w);else{if(ct(t,i))return;e.uniform4fv(this.addr,i),lt(t,i)}}function rl(e,i){const t=this.cache,n=i.elements;if(n===void 0){if(ct(t,i))return;e.uniformMatrix2fv(this.addr,!1,i),lt(t,i)}else{if(ct(t,n))return;Hn.set(n),e.uniformMatrix2fv(this.addr,!1,Hn),lt(t,n)}}function ol(e,i){const t=this.cache,n=i.elements;if(n===void 0){if(ct(t,i))return;e.uniformMatrix3fv(this.addr,!1,i),lt(t,i)}else{if(ct(t,n))return;Gn.set(n),e.uniformMatrix3fv(this.addr,!1,Gn),lt(t,n)}}function sl(e,i){const t=this.cache,n=i.elements;if(n===void 0){if(ct(t,i))return;e.uniformMatrix4fv(this.addr,!1,i),lt(t,i)}else{if(ct(t,n))return;Bn.set(n),e.uniformMatrix4fv(this.addr,!1,Bn),lt(t,n)}}function cl(e,i){const t=this.cache;t[0]!==i&&(e.uniform1i(this.addr,i),t[0]=i)}function ll(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y)&&(e.uniform2i(this.addr,i.x,i.y),t[0]=i.x,t[1]=i.y);else{if(ct(t,i))return;e.uniform2iv(this.addr,i),lt(t,i)}}function fl(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y||t[2]!==i.z)&&(e.uniform3i(this.addr,i.x,i.y,i.z),t[0]=i.x,t[1]=i.y,t[2]=i.z);else{if(ct(t,i))return;e.uniform3iv(this.addr,i),lt(t,i)}}function dl(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y||t[2]!==i.z||t[3]!==i.w)&&(e.uniform4i(this.addr,i.x,i.y,i.z,i.w),t[0]=i.x,t[1]=i.y,t[2]=i.z,t[3]=i.w);else{if(ct(t,i))return;e.uniform4iv(this.addr,i),lt(t,i)}}function ul(e,i){const t=this.cache;t[0]!==i&&(e.uniform1ui(this.addr,i),t[0]=i)}function pl(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y)&&(e.uniform2ui(this.addr,i.x,i.y),t[0]=i.x,t[1]=i.y);else{if(ct(t,i))return;e.uniform2uiv(this.addr,i),lt(t,i)}}function hl(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y||t[2]!==i.z)&&(e.uniform3ui(this.addr,i.x,i.y,i.z),t[0]=i.x,t[1]=i.y,t[2]=i.z);else{if(ct(t,i))return;e.uniform3uiv(this.addr,i),lt(t,i)}}function ml(e,i){const t=this.cache;if(i.x!==void 0)(t[0]!==i.x||t[1]!==i.y||t[2]!==i.z||t[3]!==i.w)&&(e.uniform4ui(this.addr,i.x,i.y,i.z,i.w),t[0]=i.x,t[1]=i.y,t[2]=i.z,t[3]=i.w);else{if(ct(t,i))return;e.uniform4uiv(this.addr,i),lt(t,i)}}function _l(e,i,t){const n=this.cache,f=t.allocateTextureUnit();n[0]!==f&&(e.uniform1i(this.addr,f),n[0]=f);let c;this.type===e.SAMPLER_2D_SHADOW?(Ii.compareFunction=t.isReversedDepthBuffer()?Fi:Oi,c=Ii):c=Aa,t.setTexture2D(i||c,f)}function gl(e,i,t){const n=this.cache,f=t.allocateTextureUnit();n[0]!==f&&(e.uniform1i(this.addr,f),n[0]=f),t.setTexture3D(i||ba,f)}function vl(e,i,t){const n=this.cache,f=t.allocateTextureUnit();n[0]!==f&&(e.uniform1i(this.addr,f),n[0]=f),t.setTextureCube(i||Ca,f)}function Sl(e,i,t){const n=this.cache,f=t.allocateTextureUnit();n[0]!==f&&(e.uniform1i(this.addr,f),n[0]=f),t.setTexture2DArray(i||Ra,f)}function El(e){switch(e){case 5126:return tl;case 35664:return il;case 35665:return nl;case 35666:return al;case 35674:return rl;case 35675:return ol;case 35676:return sl;case 5124:case 35670:return cl;case 35667:case 35671:return ll;case 35668:case 35672:return fl;case 35669:case 35673:return dl;case 5125:return ul;case 36294:return pl;case 36295:return hl;case 36296:return ml;case 35678:case 36198:case 36298:case 36306:case 35682:return _l;case 35679:case 36299:case 36307:return gl;case 35680:case 36300:case 36308:case 36293:return vl;case 36289:case 36303:case 36311:case 36292:return Sl}}function xl(e,i){e.uniform1fv(this.addr,i)}function Ml(e,i){const t=qt(i,this.size,2);e.uniform2fv(this.addr,t)}function Tl(e,i){const t=qt(i,this.size,3);e.uniform3fv(this.addr,t)}function Al(e,i){const t=qt(i,this.size,4);e.uniform4fv(this.addr,t)}function Rl(e,i){const t=qt(i,this.size,4);e.uniformMatrix2fv(this.addr,!1,t)}function bl(e,i){const t=qt(i,this.size,9);e.uniformMatrix3fv(this.addr,!1,t)}function Cl(e,i){const t=qt(i,this.size,16);e.uniformMatrix4fv(this.addr,!1,t)}function Pl(e,i){e.uniform1iv(this.addr,i)}function Ll(e,i){e.uniform2iv(this.addr,i)}function wl(e,i){e.uniform3iv(this.addr,i)}function Ul(e,i){e.uniform4iv(this.addr,i)}function Dl(e,i){e.uniform1uiv(this.addr,i)}function Il(e,i){e.uniform2uiv(this.addr,i)}function Nl(e,i){e.uniform3uiv(this.addr,i)}function yl(e,i){e.uniform4uiv(this.addr,i)}function Fl(e,i,t){const n=this.cache,f=i.length,c=hi(t,f);ct(n,c)||(e.uniform1iv(this.addr,c),lt(n,c));let u;this.type===e.SAMPLER_2D_SHADOW?u=Ii:u=Aa;for(let g=0;g!==f;++g)t.setTexture2D(i[g]||u,c[g])}function Ol(e,i,t){const n=this.cache,f=i.length,c=hi(t,f);ct(n,c)||(e.uniform1iv(this.addr,c),lt(n,c));for(let u=0;u!==f;++u)t.setTexture3D(i[u]||ba,c[u])}function Bl(e,i,t){const n=this.cache,f=i.length,c=hi(t,f);ct(n,c)||(e.uniform1iv(this.addr,c),lt(n,c));for(let u=0;u!==f;++u)t.setTextureCube(i[u]||Ca,c[u])}function Gl(e,i,t){const n=this.cache,f=i.length,c=hi(t,f);ct(n,c)||(e.uniform1iv(this.addr,c),lt(n,c));for(let u=0;u!==f;++u)t.setTexture2DArray(i[u]||Ra,c[u])}function Hl(e){switch(e){case 5126:return xl;case 35664:return Ml;case 35665:return Tl;case 35666:return Al;case 35674:return Rl;case 35675:return bl;case 35676:return Cl;case 5124:case 35670:return Pl;case 35667:case 35671:return Ll;case 35668:case 35672:return wl;case 35669:case 35673:return Ul;case 5125:return Dl;case 36294:return Il;case 36295:return Nl;case 36296:return yl;case 35678:case 36198:case 36298:case 36306:case 35682:return Fl;case 35679:case 36299:case 36307:return Ol;case 35680:case 36300:case 36308:case 36293:return Bl;case 36289:case 36303:case 36311:case 36292:return Gl}}class Vl{constructor(i,t,n){this.id=i,this.addr=n,this.cache=[],this.type=t.type,this.setValue=El(t.type)}}class Wl{constructor(i,t,n){this.id=i,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Hl(t.type)}}class kl{constructor(i){this.id=i,this.seq=[],this.map={}}setValue(i,t,n){const f=this.seq;for(let c=0,u=f.length;c!==u;++c){const g=f[c];g.setValue(i,t[g.id],n)}}}const bi=/(\w+)(\])?(\[|\.)?/g;function Vn(e,i){e.seq.push(i),e.map[i.id]=i}function zl(e,i,t){const n=e.name,f=n.length;for(bi.lastIndex=0;;){const c=bi.exec(n),u=bi.lastIndex;let g=c[1];const H=c[2]==="]",T=c[3];if(H&&(g=g|0),T===void 0||T==="["&&u+2===f){Vn(t,T===void 0?new Vl(g,e,i):new Wl(g,e,i));break}else{let G=t.map[g];G===void 0&&(G=new kl(g),Vn(t,G)),t=G}}}class di{constructor(i,t){this.seq=[],this.map={};const n=i.getProgramParameter(t,i.ACTIVE_UNIFORMS);for(let u=0;u<n;++u){const g=i.getActiveUniform(t,u),H=i.getUniformLocation(t,g.name);zl(g,H,this)}const f=[],c=[];for(const u of this.seq)u.type===i.SAMPLER_2D_SHADOW||u.type===i.SAMPLER_CUBE_SHADOW||u.type===i.SAMPLER_2D_ARRAY_SHADOW?f.push(u):c.push(u);f.length>0&&(this.seq=f.concat(c))}setValue(i,t,n,f){const c=this.map[t];c!==void 0&&c.setValue(i,n,f)}setOptional(i,t,n){const f=t[n];f!==void 0&&this.setValue(i,n,f)}static upload(i,t,n,f){for(let c=0,u=t.length;c!==u;++c){const g=t[c],H=n[g.id];H.needsUpdate!==!1&&g.setValue(i,H.value,f)}}static seqWithValue(i,t){const n=[];for(let f=0,c=i.length;f!==c;++f){const u=i[f];u.id in t&&n.push(u)}return n}}function Wn(e,i,t){const n=e.createShader(i);return e.shaderSource(n,t),e.compileShader(n),n}const Xl=37297;let Yl=0;function Kl(e,i){const t=e.split(`
`),n=[],f=Math.max(i-6,0),c=Math.min(i+6,t.length);for(let u=f;u<c;u++){const g=u+1;n.push(`${g===i?">":" "} ${g}: ${t[u]}`)}return n.join(`
`)}const kn=new Ie;function ql(e){$e._getMatrix(kn,$e.workingColorSpace,e);const i=`mat3( ${kn.elements.map(t=>t.toFixed(4))} )`;switch($e.getTransfer(e)){case pa:return[i,"LinearTransferOETF"];case qe:return[i,"sRGBTransferOETF"];default:return Ge("WebGLProgram: Unsupported color space: ",e),[i,"LinearTransferOETF"]}}function zn(e,i,t){const n=e.getShaderParameter(i,e.COMPILE_STATUS),c=(e.getShaderInfoLog(i)||"").trim();if(n&&c==="")return"";const u=/ERROR: 0:(\d+)/.exec(c);if(u){const g=parseInt(u[1]);return t.toUpperCase()+`

`+c+`

`+Kl(e.getShaderSource(i),g)}else return c}function Zl(e,i){const t=ql(i);return[`vec4 ${e}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const $l={[ua]:"Linear",[da]:"Reinhard",[fa]:"Cineon",[la]:"ACESFilmic",[ca]:"AgX",[sa]:"Neutral",[oa]:"Custom"};function Ql(e,i){const t=$l[i];return t===void 0?(Ge("WebGLProgram: Unsupported toneMapping:",i),"vec3 "+e+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+e+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const ci=new Fe;function Jl(){$e.getLuminanceCoefficients(ci);const e=ci.x.toFixed(4),i=ci.y.toFixed(4),t=ci.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${e}, ${i}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function jl(e){return[e.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",e.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Jt).join(`
`)}function ef(e){const i=[];for(const t in e){const n=e[t];n!==!1&&i.push("#define "+t+" "+n)}return i.join(`
`)}function tf(e,i){const t={},n=e.getProgramParameter(i,e.ACTIVE_ATTRIBUTES);for(let f=0;f<n;f++){const c=e.getActiveAttrib(i,f),u=c.name;let g=1;c.type===e.FLOAT_MAT2&&(g=2),c.type===e.FLOAT_MAT3&&(g=3),c.type===e.FLOAT_MAT4&&(g=4),t[u]={type:c.type,location:e.getAttribLocation(i,u),locationSize:g}}return t}function Jt(e){return e!==""}function Xn(e,i){const t=i.numSpotLightShadows+i.numSpotLightMaps-i.numSpotLightShadowsWithMaps;return e.replace(/NUM_DIR_LIGHTS/g,i.numDirLights).replace(/NUM_SPOT_LIGHTS/g,i.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,i.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,i.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,i.numPointLights).replace(/NUM_HEMI_LIGHTS/g,i.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,i.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,i.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,i.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,i.numPointLightShadows)}function Yn(e,i){return e.replace(/NUM_CLIPPING_PLANES/g,i.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,i.numClippingPlanes-i.numClipIntersection)}const nf=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ni(e){return e.replace(nf,rf)}const af=new Map;function rf(e,i){let t=we[i];if(t===void 0){const n=af.get(i);if(n!==void 0)t=we[n],Ge('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',i,n);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+i+">")}return Ni(t)}const of=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Kn(e){return e.replace(of,sf)}function sf(e,i,t,n){let f="";for(let c=parseInt(i);c<parseInt(t);c++)f+=n.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return f}function qn(e){let i=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision==="highp"?i+=`
#define HIGH_PRECISION`:e.precision==="mediump"?i+=`
#define MEDIUM_PRECISION`:e.precision==="lowp"&&(i+=`
#define LOW_PRECISION`),i}const cf={[li]:"SHADOWMAP_TYPE_PCF",[Qt]:"SHADOWMAP_TYPE_VSM"};function lf(e){return cf[e.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const ff={[Li]:"ENVMAP_TYPE_CUBE",[ui]:"ENVMAP_TYPE_CUBE",[yi]:"ENVMAP_TYPE_CUBE_UV"};function df(e){return e.envMap===!1?"ENVMAP_TYPE_CUBE":ff[e.envMapMode]||"ENVMAP_TYPE_CUBE"}const uf={[ui]:"ENVMAP_MODE_REFRACTION"};function pf(e){return e.envMap===!1?"ENVMAP_MODE_REFLECTION":uf[e.envMapMode]||"ENVMAP_MODE_REFLECTION"}const hf={[Ka]:"ENVMAP_BLENDING_MULTIPLY",[Ya]:"ENVMAP_BLENDING_MIX",[Xa]:"ENVMAP_BLENDING_ADD"};function mf(e){return e.envMap===!1?"ENVMAP_BLENDING_NONE":hf[e.combine]||"ENVMAP_BLENDING_NONE"}function _f(e){const i=e.envMapCubeUVHeight;if(i===null)return null;const t=Math.log2(i)-2,n=1/i;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function gf(e,i,t,n){const f=e.getContext(),c=t.defines;let u=t.vertexShader,g=t.fragmentShader;const H=lf(t),T=df(t),q=pf(t),G=mf(t),p=_f(t),x=jl(t),U=ef(c),Y=f.createProgram();let l,o,N=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(l=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,U].filter(Jt).join(`
`),l.length>0&&(l+=`
`),o=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,U].filter(Jt).join(`
`),o.length>0&&(o+=`
`)):(l=[qn(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,U,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+q:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+H:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Jt).join(`
`),o=[qn(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,U,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+T:"",t.envMap?"#define "+q:"",t.envMap?"#define "+G:"",p?"#define CUBEUV_TEXEL_WIDTH "+p.texelWidth:"",p?"#define CUBEUV_TEXEL_HEIGHT "+p.texelHeight:"",p?"#define CUBEUV_MAX_MIP "+p.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+H:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Lt?"#define TONE_MAPPING":"",t.toneMapping!==Lt?we.tonemapping_pars_fragment:"",t.toneMapping!==Lt?Ql("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",we.colorspace_pars_fragment,Zl("linearToOutputTexel",t.outputColorSpace),Jl(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Jt).join(`
`)),u=Ni(u),u=Xn(u,t),u=Yn(u,t),g=Ni(g),g=Xn(g,t),g=Yn(g,t),u=Kn(u),g=Kn(g),t.isRawShaderMaterial!==!0&&(N=`#version 300 es
`,l=[x,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+l,o=["#define varying in",t.glslVersion===Zi?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Zi?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+o);const O=N+l+u,m=N+o+g,b=Wn(f,f.VERTEX_SHADER,O),v=Wn(f,f.FRAGMENT_SHADER,m);f.attachShader(Y,b),f.attachShader(Y,v),t.index0AttributeName!==void 0?f.bindAttribLocation(Y,0,t.index0AttributeName):t.hasPositionAttribute===!0&&f.bindAttribLocation(Y,0,"position"),f.linkProgram(Y);function D(A){if(e.debug.checkShaderErrors){const I=f.getProgramInfoLog(Y)||"",Q=f.getShaderInfoLog(b)||"",Z=f.getShaderInfoLog(v)||"",V=I.trim(),z=Q.trim(),B=Z.trim();let $=!0,le=!0;if(f.getProgramParameter(Y,f.LINK_STATUS)===!1)if($=!1,typeof e.debug.onShaderError=="function")e.debug.onShaderError(f,Y,b,v);else{const ge=zn(f,b,"vertex"),ve=zn(f,v,"fragment");Ze("WebGLProgram: Shader Error "+f.getError()+" - VALIDATE_STATUS "+f.getProgramParameter(Y,f.VALIDATE_STATUS)+`

Material Name: `+A.name+`
Material Type: `+A.type+`

Program Info Log: `+V+`
`+ge+`
`+ve)}else V!==""?Ge("WebGLProgram: Program Info Log:",V):(z===""||B==="")&&(le=!1);le&&(A.diagnostics={runnable:$,programLog:V,vertexShader:{log:z,prefix:l},fragmentShader:{log:B,prefix:o}})}f.deleteShader(b),f.deleteShader(v),s=new di(f,Y),h=tf(f,Y)}let s;this.getUniforms=function(){return s===void 0&&D(this),s};let h;this.getAttributes=function(){return h===void 0&&D(this),h};let L=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return L===!1&&(L=f.getProgramParameter(Y,Xl)),L},this.destroy=function(){n.releaseStatesOfProgram(this),f.deleteProgram(Y),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Yl++,this.cacheKey=i,this.usedTimes=1,this.program=Y,this.vertexShader=b,this.fragmentShader=v,this}let vf=0;class Sf{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(i,t,n){const f=this._getShaderCacheForMaterial(i);return f.has(t)===!1&&(f.add(t),t.usedTimes++),f.has(n)===!1&&(f.add(n),n.usedTimes++),this}remove(i){const t=this.materialCache.get(i);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(i),this}getVertexShaderStage(i){return this._getShaderStage(i.vertexShader)}getFragmentShaderStage(i){return this._getShaderStage(i.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(i){const t=this.materialCache;let n=t.get(i);return n===void 0&&(n=new Set,t.set(i,n)),n}_getShaderStage(i){const t=this.shaderCache;let n=t.get(i);return n===void 0&&(n=new Ef(i),t.set(i,n)),n}}class Ef{constructor(i){this.id=vf++,this.code=i,this.usedTimes=0}}function xf(e){return e===Yt||e===wi||e===Ui}function Mf(e,i,t,n,f,c){const u=new $a,g=new Sf,H=new Set,T=[],q=new Map,G=n.logarithmicDepthBuffer;let p=n.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function U(s){return H.add(s),s===0?"uv":`uv${s}`}function Y(s,h,L,A,I,Q){const Z=A.fog,V=I.geometry,z=s.isMeshStandardMaterial||s.isMeshLambertMaterial||s.isMeshPhongMaterial?A.environment:null,B=s.isMeshStandardMaterial||s.isMeshLambertMaterial&&!s.envMap||s.isMeshPhongMaterial&&!s.envMap,$=i.get(s.envMap||z,B),le=$&&$.mapping===yi?$.image.height:null,ge=x[s.type];s.precision!==null&&(p=n.getMaxPrecision(s.precision),p!==s.precision&&Ge("WebGLProgram.getParameters:",s.precision,"not supported, using",p,"instead."));const ve=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,xe=ve!==void 0?ve.length:0;let Xe=0;V.morphAttributes.position!==void 0&&(Xe=1),V.morphAttributes.normal!==void 0&&(Xe=2),V.morphAttributes.color!==void 0&&(Xe=3);let at,He,X,te;if(ge){const he=Rt[ge];at=he.vertexShader,He=he.fragmentShader}else{at=s.vertexShader,He=s.fragmentShader;const he=g.getVertexShaderStage(s),je=g.getFragmentShaderStage(s);g.update(s,he,je),X=he.id,te=je.id}const J=e.getRenderTarget(),be=e.state.buffers.depth.getReversed(),Ce=I.isInstancedMesh===!0,Ae=I.isBatchedMesh===!0,tt=!!s.map,De=!!s.matcap,We=!!$,Oe=!!s.aoMap,Ne=!!s.lightMap,rt=!!s.bumpMap&&s.wireframe===!1,st=!!s.normalMap,ft=!!s.displacementMap,dt=!!s.emissiveMap,Je=!!s.metalnessMap,ot=!!s.roughnessMap,S=s.anisotropy>0,pt=s.clearcoat>0,Be=s.dispersion>0,d=s.iridescence>0,a=s.sheen>0,M=s.transmission>0,P=S&&!!s.anisotropyMap,y=pt&&!!s.clearcoatMap,j=pt&&!!s.clearcoatNormalMap,ie=pt&&!!s.clearcoatRoughnessMap,F=d&&!!s.iridescenceMap,k=d&&!!s.iridescenceThicknessMap,ne=a&&!!s.sheenColorMap,Se=a&&!!s.sheenRoughnessMap,oe=!!s.specularMap,ae=!!s.specularColorMap,Te=!!s.specularIntensityMap,Re=M&&!!s.transmissionMap,Pe=M&&!!s.thicknessMap,_=!!s.gradientMap,ee=!!s.alphaMap,W=s.alphaTest>0,re=!!s.alphaHash,de=!!s.extensions;let K=Lt;s.toneMapped&&(J===null||J.isXRRenderTarget===!0)&&(K=e.toneMapping);const _e={shaderID:ge,shaderType:s.type,shaderName:s.name,vertexShader:at,fragmentShader:He,defines:s.defines,customVertexShaderID:X,customFragmentShaderID:te,isRawShaderMaterial:s.isRawShaderMaterial===!0,glslVersion:s.glslVersion,precision:p,batching:Ae,batchingColor:Ae&&I._colorsTexture!==null,instancing:Ce,instancingColor:Ce&&I.instanceColor!==null,instancingMorph:Ce&&I.morphTexture!==null,outputColorSpace:J===null?e.outputColorSpace:J.isXRRenderTarget===!0?J.texture.colorSpace:$e.workingColorSpace,alphaToCoverage:!!s.alphaToCoverage,map:tt,matcap:De,envMap:We,envMapMode:We&&$.mapping,envMapCubeUVHeight:le,aoMap:Oe,lightMap:Ne,bumpMap:rt,normalMap:st,displacementMap:ft,emissiveMap:dt,normalMapObjectSpace:st&&s.normalMapType===Za,normalMapTangentSpace:st&&s.normalMapType===$i,packedNormalMap:st&&s.normalMapType===$i&&xf(s.normalMap.format),metalnessMap:Je,roughnessMap:ot,anisotropy:S,anisotropyMap:P,clearcoat:pt,clearcoatMap:y,clearcoatNormalMap:j,clearcoatRoughnessMap:ie,dispersion:Be,iridescence:d,iridescenceMap:F,iridescenceThicknessMap:k,sheen:a,sheenColorMap:ne,sheenRoughnessMap:Se,specularMap:oe,specularColorMap:ae,specularIntensityMap:Te,transmission:M,transmissionMap:Re,thicknessMap:Pe,gradientMap:_,opaque:s.transparent===!1&&s.blending===fi&&s.alphaToCoverage===!1,alphaMap:ee,alphaTest:W,alphaHash:re,combine:s.combine,mapUv:tt&&U(s.map.channel),aoMapUv:Oe&&U(s.aoMap.channel),lightMapUv:Ne&&U(s.lightMap.channel),bumpMapUv:rt&&U(s.bumpMap.channel),normalMapUv:st&&U(s.normalMap.channel),displacementMapUv:ft&&U(s.displacementMap.channel),emissiveMapUv:dt&&U(s.emissiveMap.channel),metalnessMapUv:Je&&U(s.metalnessMap.channel),roughnessMapUv:ot&&U(s.roughnessMap.channel),anisotropyMapUv:P&&U(s.anisotropyMap.channel),clearcoatMapUv:y&&U(s.clearcoatMap.channel),clearcoatNormalMapUv:j&&U(s.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ie&&U(s.clearcoatRoughnessMap.channel),iridescenceMapUv:F&&U(s.iridescenceMap.channel),iridescenceThicknessMapUv:k&&U(s.iridescenceThicknessMap.channel),sheenColorMapUv:ne&&U(s.sheenColorMap.channel),sheenRoughnessMapUv:Se&&U(s.sheenRoughnessMap.channel),specularMapUv:oe&&U(s.specularMap.channel),specularColorMapUv:ae&&U(s.specularColorMap.channel),specularIntensityMapUv:Te&&U(s.specularIntensityMap.channel),transmissionMapUv:Re&&U(s.transmissionMap.channel),thicknessMapUv:Pe&&U(s.thicknessMap.channel),alphaMapUv:ee&&U(s.alphaMap.channel),vertexTangents:!!V.attributes.tangent&&(st||S),vertexNormals:!!V.attributes.normal,vertexColors:s.vertexColors,vertexAlphas:s.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,pointsUvs:I.isPoints===!0&&!!V.attributes.uv&&(tt||ee),fog:!!Z,useFog:s.fog===!0,fogExp2:!!Z&&Z.isFogExp2,flatShading:s.wireframe===!1&&(s.flatShading===!0||V.attributes.normal===void 0&&st===!1&&(s.isMeshLambertMaterial||s.isMeshPhongMaterial||s.isMeshStandardMaterial||s.isMeshPhysicalMaterial)),sizeAttenuation:s.sizeAttenuation===!0,logarithmicDepthBuffer:G,reversedDepthBuffer:be,skinning:I.isSkinnedMesh===!0,hasPositionAttribute:V.attributes.position!==void 0,morphTargets:V.morphAttributes.position!==void 0,morphNormals:V.morphAttributes.normal!==void 0,morphColors:V.morphAttributes.color!==void 0,morphTargetsCount:xe,morphTextureStride:Xe,numDirLights:h.directional.length,numPointLights:h.point.length,numSpotLights:h.spot.length,numSpotLightMaps:h.spotLightMap.length,numRectAreaLights:h.rectArea.length,numHemiLights:h.hemi.length,numDirLightShadows:h.directionalShadowMap.length,numPointLightShadows:h.pointShadowMap.length,numSpotLightShadows:h.spotShadowMap.length,numSpotLightShadowsWithMaps:h.numSpotLightShadowsWithMaps,numLightProbes:h.numLightProbes,numLightProbeGrids:Q.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:s.dithering,shadowMapEnabled:e.shadowMap.enabled&&L.length>0,shadowMapType:e.shadowMap.type,toneMapping:K,decodeVideoTexture:tt&&s.map.isVideoTexture===!0&&$e.getTransfer(s.map.colorSpace)===qe,decodeVideoTextureEmissive:dt&&s.emissiveMap.isVideoTexture===!0&&$e.getTransfer(s.emissiveMap.colorSpace)===qe,premultipliedAlpha:s.premultipliedAlpha,doubleSided:s.side===Ct,flipSided:s.side===St,useDepthPacking:s.depthPacking>=0,depthPacking:s.depthPacking||0,index0AttributeName:s.index0AttributeName,extensionClipCullDistance:de&&s.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(de&&s.extensions.multiDraw===!0||Ae)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:s.customProgramCacheKey()};return _e.vertexUv1s=H.has(1),_e.vertexUv2s=H.has(2),_e.vertexUv3s=H.has(3),H.clear(),_e}function l(s){const h=[];if(s.shaderID?h.push(s.shaderID):(h.push(s.customVertexShaderID),h.push(s.customFragmentShaderID)),s.defines!==void 0)for(const L in s.defines)h.push(L),h.push(s.defines[L]);return s.isRawShaderMaterial===!1&&(o(h,s),N(h,s),h.push(e.outputColorSpace)),h.push(s.customProgramCacheKey),h.join()}function o(s,h){s.push(h.precision),s.push(h.outputColorSpace),s.push(h.envMapMode),s.push(h.envMapCubeUVHeight),s.push(h.mapUv),s.push(h.alphaMapUv),s.push(h.lightMapUv),s.push(h.aoMapUv),s.push(h.bumpMapUv),s.push(h.normalMapUv),s.push(h.displacementMapUv),s.push(h.emissiveMapUv),s.push(h.metalnessMapUv),s.push(h.roughnessMapUv),s.push(h.anisotropyMapUv),s.push(h.clearcoatMapUv),s.push(h.clearcoatNormalMapUv),s.push(h.clearcoatRoughnessMapUv),s.push(h.iridescenceMapUv),s.push(h.iridescenceThicknessMapUv),s.push(h.sheenColorMapUv),s.push(h.sheenRoughnessMapUv),s.push(h.specularMapUv),s.push(h.specularColorMapUv),s.push(h.specularIntensityMapUv),s.push(h.transmissionMapUv),s.push(h.thicknessMapUv),s.push(h.combine),s.push(h.fogExp2),s.push(h.sizeAttenuation),s.push(h.morphTargetsCount),s.push(h.morphAttributeCount),s.push(h.numDirLights),s.push(h.numPointLights),s.push(h.numSpotLights),s.push(h.numSpotLightMaps),s.push(h.numHemiLights),s.push(h.numRectAreaLights),s.push(h.numDirLightShadows),s.push(h.numPointLightShadows),s.push(h.numSpotLightShadows),s.push(h.numSpotLightShadowsWithMaps),s.push(h.numLightProbes),s.push(h.shadowMapType),s.push(h.toneMapping),s.push(h.numClippingPlanes),s.push(h.numClipIntersection),s.push(h.depthPacking)}function N(s,h){u.disableAll(),h.instancing&&u.enable(0),h.instancingColor&&u.enable(1),h.instancingMorph&&u.enable(2),h.matcap&&u.enable(3),h.envMap&&u.enable(4),h.normalMapObjectSpace&&u.enable(5),h.normalMapTangentSpace&&u.enable(6),h.clearcoat&&u.enable(7),h.iridescence&&u.enable(8),h.alphaTest&&u.enable(9),h.vertexColors&&u.enable(10),h.vertexAlphas&&u.enable(11),h.vertexUv1s&&u.enable(12),h.vertexUv2s&&u.enable(13),h.vertexUv3s&&u.enable(14),h.vertexTangents&&u.enable(15),h.anisotropy&&u.enable(16),h.alphaHash&&u.enable(17),h.batching&&u.enable(18),h.dispersion&&u.enable(19),h.batchingColor&&u.enable(20),h.gradientMap&&u.enable(21),h.packedNormalMap&&u.enable(22),h.vertexNormals&&u.enable(23),s.push(u.mask),u.disableAll(),h.fog&&u.enable(0),h.useFog&&u.enable(1),h.flatShading&&u.enable(2),h.logarithmicDepthBuffer&&u.enable(3),h.reversedDepthBuffer&&u.enable(4),h.skinning&&u.enable(5),h.morphTargets&&u.enable(6),h.morphNormals&&u.enable(7),h.morphColors&&u.enable(8),h.premultipliedAlpha&&u.enable(9),h.shadowMapEnabled&&u.enable(10),h.doubleSided&&u.enable(11),h.flipSided&&u.enable(12),h.useDepthPacking&&u.enable(13),h.dithering&&u.enable(14),h.transmission&&u.enable(15),h.sheen&&u.enable(16),h.opaque&&u.enable(17),h.pointsUvs&&u.enable(18),h.decodeVideoTexture&&u.enable(19),h.decodeVideoTextureEmissive&&u.enable(20),h.alphaToCoverage&&u.enable(21),h.numLightProbeGrids>0&&u.enable(22),h.hasPositionAttribute&&u.enable(23),s.push(u.mask)}function O(s){const h=x[s.type];let L;if(h){const A=Rt[h];L=qa.clone(A.uniforms)}else L=s.uniforms;return L}function m(s,h){let L=q.get(h);return L!==void 0?++L.usedTimes:(L=new gf(e,h,s,f),T.push(L),q.set(h,L)),L}function b(s){if(--s.usedTimes===0){const h=T.indexOf(s);T[h]=T[T.length-1],T.pop(),q.delete(s.cacheKey),s.destroy()}}function v(s){g.remove(s)}function D(){g.dispose()}return{getParameters:Y,getProgramCacheKey:l,getUniforms:O,acquireProgram:m,releaseProgram:b,releaseShaderCache:v,programs:T,dispose:D}}function Tf(){let e=new WeakMap;function i(u){return e.has(u)}function t(u){let g=e.get(u);return g===void 0&&(g={},e.set(u,g)),g}function n(u){e.delete(u)}function f(u,g,H){e.get(u)[g]=H}function c(){e=new WeakMap}return{has:i,get:t,remove:n,update:f,dispose:c}}function Af(e,i){return e.groupOrder!==i.groupOrder?e.groupOrder-i.groupOrder:e.renderOrder!==i.renderOrder?e.renderOrder-i.renderOrder:e.material.id!==i.material.id?e.material.id-i.material.id:e.materialVariant!==i.materialVariant?e.materialVariant-i.materialVariant:e.z!==i.z?e.z-i.z:e.id-i.id}function Zn(e,i){return e.groupOrder!==i.groupOrder?e.groupOrder-i.groupOrder:e.renderOrder!==i.renderOrder?e.renderOrder-i.renderOrder:e.z!==i.z?i.z-e.z:e.id-i.id}function $n(){const e=[];let i=0;const t=[],n=[],f=[];function c(){i=0,t.length=0,n.length=0,f.length=0}function u(p){let x=0;return p.isInstancedMesh&&(x+=2),p.isSkinnedMesh&&(x+=1),x}function g(p,x,U,Y,l,o){let N=e[i];return N===void 0?(N={id:p.id,object:p,geometry:x,material:U,materialVariant:u(p),groupOrder:Y,renderOrder:p.renderOrder,z:l,group:o},e[i]=N):(N.id=p.id,N.object=p,N.geometry=x,N.material=U,N.materialVariant=u(p),N.groupOrder=Y,N.renderOrder=p.renderOrder,N.z=l,N.group=o),i++,N}function H(p,x,U,Y,l,o){const N=g(p,x,U,Y,l,o);U.transmission>0?n.push(N):U.transparent===!0?f.push(N):t.push(N)}function T(p,x,U,Y,l,o){const N=g(p,x,U,Y,l,o);U.transmission>0?n.unshift(N):U.transparent===!0?f.unshift(N):t.unshift(N)}function q(p,x,U){t.length>1&&t.sort(p||Af),n.length>1&&n.sort(x||Zn),f.length>1&&f.sort(x||Zn),U&&(t.reverse(),n.reverse(),f.reverse())}function G(){for(let p=i,x=e.length;p<x;p++){const U=e[p];if(U.id===null)break;U.id=null,U.object=null,U.geometry=null,U.material=null,U.group=null}}return{opaque:t,transmissive:n,transparent:f,init:c,push:H,unshift:T,finish:G,sort:q}}function Rf(){let e=new WeakMap;function i(n,f){const c=e.get(n);let u;return c===void 0?(u=new $n,e.set(n,[u])):f>=c.length?(u=new $n,c.push(u)):u=c[f],u}function t(){e=new WeakMap}return{get:i,dispose:t}}function bf(){const e={};return{get:function(i){if(e[i.id]!==void 0)return e[i.id];let t;switch(i.type){case"DirectionalLight":t={direction:new Fe,color:new Qe};break;case"SpotLight":t={position:new Fe,direction:new Fe,color:new Qe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new Fe,color:new Qe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new Fe,skyColor:new Qe,groundColor:new Qe};break;case"RectAreaLight":t={color:new Qe,position:new Fe,halfWidth:new Fe,halfHeight:new Fe};break}return e[i.id]=t,t}}}function Cf(){const e={};return{get:function(i){if(e[i.id]!==void 0)return e[i.id];let t;switch(i.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _t};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _t};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _t,shadowCameraNear:1,shadowCameraFar:1e3};break}return e[i.id]=t,t}}}let Pf=0;function Lf(e,i){return(i.castShadow?2:0)-(e.castShadow?2:0)+(i.map?1:0)-(e.map?1:0)}function wf(e){const i=new bf,t=Cf(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let T=0;T<9;T++)n.probe.push(new Fe);const f=new Fe,c=new Xt,u=new Xt;function g(T){let q=0,G=0,p=0;for(let h=0;h<9;h++)n.probe[h].set(0,0,0);let x=0,U=0,Y=0,l=0,o=0,N=0,O=0,m=0,b=0,v=0,D=0;T.sort(Lf);for(let h=0,L=T.length;h<L;h++){const A=T[h],I=A.color,Q=A.intensity,Z=A.distance;let V=null;if(A.shadow&&A.shadow.map&&(A.shadow.map.texture.format===Yt?V=A.shadow.map.texture:V=A.shadow.map.depthTexture||A.shadow.map.texture),A.isAmbientLight)q+=I.r*Q,G+=I.g*Q,p+=I.b*Q;else if(A.isLightProbe){for(let z=0;z<9;z++)n.probe[z].addScaledVector(A.sh.coefficients[z],Q);D++}else if(A.isDirectionalLight){const z=i.get(A);if(z.color.copy(A.color).multiplyScalar(A.intensity),A.castShadow){const B=A.shadow,$=t.get(A);$.shadowIntensity=B.intensity,$.shadowBias=B.bias,$.shadowNormalBias=B.normalBias,$.shadowRadius=B.radius,$.shadowMapSize=B.mapSize,n.directionalShadow[x]=$,n.directionalShadowMap[x]=V,n.directionalShadowMatrix[x]=A.shadow.matrix,N++}n.directional[x]=z,x++}else if(A.isSpotLight){const z=i.get(A);z.position.setFromMatrixPosition(A.matrixWorld),z.color.copy(I).multiplyScalar(Q),z.distance=Z,z.coneCos=Math.cos(A.angle),z.penumbraCos=Math.cos(A.angle*(1-A.penumbra)),z.decay=A.decay,n.spot[Y]=z;const B=A.shadow;if(A.map&&(n.spotLightMap[b]=A.map,b++,B.updateMatrices(A),A.castShadow&&v++),n.spotLightMatrix[Y]=B.matrix,A.castShadow){const $=t.get(A);$.shadowIntensity=B.intensity,$.shadowBias=B.bias,$.shadowNormalBias=B.normalBias,$.shadowRadius=B.radius,$.shadowMapSize=B.mapSize,n.spotShadow[Y]=$,n.spotShadowMap[Y]=V,m++}Y++}else if(A.isRectAreaLight){const z=i.get(A);z.color.copy(I).multiplyScalar(Q),z.halfWidth.set(A.width*.5,0,0),z.halfHeight.set(0,A.height*.5,0),n.rectArea[l]=z,l++}else if(A.isPointLight){const z=i.get(A);if(z.color.copy(A.color).multiplyScalar(A.intensity),z.distance=A.distance,z.decay=A.decay,A.castShadow){const B=A.shadow,$=t.get(A);$.shadowIntensity=B.intensity,$.shadowBias=B.bias,$.shadowNormalBias=B.normalBias,$.shadowRadius=B.radius,$.shadowMapSize=B.mapSize,$.shadowCameraNear=B.camera.near,$.shadowCameraFar=B.camera.far,n.pointShadow[U]=$,n.pointShadowMap[U]=V,n.pointShadowMatrix[U]=A.shadow.matrix,O++}n.point[U]=z,U++}else if(A.isHemisphereLight){const z=i.get(A);z.skyColor.copy(A.color).multiplyScalar(Q),z.groundColor.copy(A.groundColor).multiplyScalar(Q),n.hemi[o]=z,o++}}l>0&&(e.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=se.LTC_FLOAT_1,n.rectAreaLTC2=se.LTC_FLOAT_2):(n.rectAreaLTC1=se.LTC_HALF_1,n.rectAreaLTC2=se.LTC_HALF_2)),n.ambient[0]=q,n.ambient[1]=G,n.ambient[2]=p;const s=n.hash;(s.directionalLength!==x||s.pointLength!==U||s.spotLength!==Y||s.rectAreaLength!==l||s.hemiLength!==o||s.numDirectionalShadows!==N||s.numPointShadows!==O||s.numSpotShadows!==m||s.numSpotMaps!==b||s.numLightProbes!==D)&&(n.directional.length=x,n.spot.length=Y,n.rectArea.length=l,n.point.length=U,n.hemi.length=o,n.directionalShadow.length=N,n.directionalShadowMap.length=N,n.pointShadow.length=O,n.pointShadowMap.length=O,n.spotShadow.length=m,n.spotShadowMap.length=m,n.directionalShadowMatrix.length=N,n.pointShadowMatrix.length=O,n.spotLightMatrix.length=m+b-v,n.spotLightMap.length=b,n.numSpotLightShadowsWithMaps=v,n.numLightProbes=D,s.directionalLength=x,s.pointLength=U,s.spotLength=Y,s.rectAreaLength=l,s.hemiLength=o,s.numDirectionalShadows=N,s.numPointShadows=O,s.numSpotShadows=m,s.numSpotMaps=b,s.numLightProbes=D,n.version=Pf++)}function H(T,q){let G=0,p=0,x=0,U=0,Y=0;const l=q.matrixWorldInverse;for(let o=0,N=T.length;o<N;o++){const O=T[o];if(O.isDirectionalLight){const m=n.directional[G];m.direction.setFromMatrixPosition(O.matrixWorld),f.setFromMatrixPosition(O.target.matrixWorld),m.direction.sub(f),m.direction.transformDirection(l),G++}else if(O.isSpotLight){const m=n.spot[x];m.position.setFromMatrixPosition(O.matrixWorld),m.position.applyMatrix4(l),m.direction.setFromMatrixPosition(O.matrixWorld),f.setFromMatrixPosition(O.target.matrixWorld),m.direction.sub(f),m.direction.transformDirection(l),x++}else if(O.isRectAreaLight){const m=n.rectArea[U];m.position.setFromMatrixPosition(O.matrixWorld),m.position.applyMatrix4(l),u.identity(),c.copy(O.matrixWorld),c.premultiply(l),u.extractRotation(c),m.halfWidth.set(O.width*.5,0,0),m.halfHeight.set(0,O.height*.5,0),m.halfWidth.applyMatrix4(u),m.halfHeight.applyMatrix4(u),U++}else if(O.isPointLight){const m=n.point[p];m.position.setFromMatrixPosition(O.matrixWorld),m.position.applyMatrix4(l),p++}else if(O.isHemisphereLight){const m=n.hemi[Y];m.direction.setFromMatrixPosition(O.matrixWorld),m.direction.transformDirection(l),Y++}}}return{setup:g,setupView:H,state:n}}function Qn(e){const i=new wf(e),t=[],n=[],f=[];function c(p){G.camera=p,t.length=0,n.length=0,f.length=0}function u(p){t.push(p)}function g(p){n.push(p)}function H(p){f.push(p)}function T(){i.setup(t)}function q(p){i.setupView(t,p)}const G={lightsArray:t,shadowsArray:n,lightProbeGridArray:f,camera:null,lights:i,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:G,setupLights:T,setupLightsView:q,pushLight:u,pushShadow:g,pushLightProbeGrid:H}}function Uf(e){let i=new WeakMap;function t(f,c=0){const u=i.get(f);let g;return u===void 0?(g=new Qn(e),i.set(f,[g])):c>=u.length?(g=new Qn(e),u.push(g)):g=u[c],g}function n(){i=new WeakMap}return{get:t,dispose:n}}const Df=`
void main() {

	gl_Position = vec4( position, 1.0 );

}
`,If=`
uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;

void main() {

	const float samples = float( VSM_SAMPLES );

	float mean = 0.0;
	float squared_mean = 0.0;

	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {

		float uvOffset = uvStart + i * uvStride;

		#ifdef HORIZONTAL_PASS

			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;

		#else

			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;

		#endif

	}

	mean = mean / samples;
	squared_mean = squared_mean / samples;

	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );

	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );

}
`,Nf=[new Fe(1,0,0),new Fe(-1,0,0),new Fe(0,1,0),new Fe(0,-1,0),new Fe(0,0,1),new Fe(0,0,-1)],yf=[new Fe(0,-1,0),new Fe(0,-1,0),new Fe(0,0,1),new Fe(0,0,-1),new Fe(0,-1,0),new Fe(0,-1,0)],Jn=new Xt,$t=new Fe,Ci=new Fe;function Ff(e,i,t){let n=new ha;const f=new _t,c=new _t,u=new mt,g=new Qa,H=new Ja,T={},q=t.maxTextureSize,G={[ti]:St,[St]:ti,[Ct]:Ct},p=new ei({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new _t},radius:{value:4}},vertexShader:Df,fragmentShader:If}),x=p.clone();x.defines.HORIZONTAL_PASS=1;const U=new ra;U.setAttribute("position",new ja(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const Y=new zt(U,p),l=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=li;let o=this.type;this.render=function(v,D,s){if(l.enabled===!1||l.autoUpdate===!1&&l.needsUpdate===!1||v.length===0)return;this.type===er&&(Ge("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=li);const h=e.getRenderTarget(),L=e.getActiveCubeFace(),A=e.getActiveMipmapLevel(),I=e.state;I.setBlending(jt),I.buffers.depth.getReversed()===!0?I.buffers.color.setClear(0,0,0,0):I.buffers.color.setClear(1,1,1,1),I.buffers.depth.setTest(!0),I.setScissorTest(!1);const Q=o!==this.type;Q&&D.traverse(function(Z){Z.material&&(Array.isArray(Z.material)?Z.material.forEach(V=>V.needsUpdate=!0):Z.material.needsUpdate=!0)});for(let Z=0,V=v.length;Z<V;Z++){const z=v[Z],B=z.shadow;if(B===void 0){Ge("WebGLShadowMap:",z,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;f.copy(B.mapSize);const $=B.getFrameExtents();f.multiply($),c.copy(B.mapSize),(f.x>q||f.y>q)&&(f.x>q&&(c.x=Math.floor(q/$.x),f.x=c.x*$.x,B.mapSize.x=c.x),f.y>q&&(c.y=Math.floor(q/$.y),f.y=c.y*$.y,B.mapSize.y=c.y));const le=e.state.buffers.depth.getReversed();if(B.camera._reversedDepth=le,B.map===null||Q===!0){if(B.map!==null&&(B.map.depthTexture!==null&&(B.map.depthTexture.dispose(),B.map.depthTexture=null),B.map.dispose()),this.type===Qt){if(z.isPointLight){Ge("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}B.map=new Pt(f.x,f.y,{format:Yt,type:Ot,minFilter:Et,magFilter:Et,generateMipmaps:!1}),B.map.texture.name=z.name+".shadowMap",B.map.depthTexture=new ii(f.x,f.y,It),B.map.depthTexture.name=z.name+".shadowMapDepth",B.map.depthTexture.format=Kt,B.map.depthTexture.compareFunction=null,B.map.depthTexture.minFilter=Ft,B.map.depthTexture.magFilter=Ft}else z.isPointLight?(B.map=new Ta(f.x),B.map.depthTexture=new tr(f.x,Bt)):(B.map=new Pt(f.x,f.y),B.map.depthTexture=new ii(f.x,f.y,Bt)),B.map.depthTexture.name=z.name+".shadowMap",B.map.depthTexture.format=Kt,this.type===li?(B.map.depthTexture.compareFunction=le?Fi:Oi,B.map.depthTexture.minFilter=Et,B.map.depthTexture.magFilter=Et):(B.map.depthTexture.compareFunction=null,B.map.depthTexture.minFilter=Ft,B.map.depthTexture.magFilter=Ft);B.camera.updateProjectionMatrix()}const ge=B.map.isWebGLCubeRenderTarget?6:1;for(let ve=0;ve<ge;ve++){if(B.map.isWebGLCubeRenderTarget)e.setRenderTarget(B.map,ve),e.clear();else{ve===0&&(e.setRenderTarget(B.map),e.clear());const xe=B.getViewport(ve);u.set(c.x*xe.x,c.y*xe.y,c.x*xe.z,c.y*xe.w),I.viewport(u)}if(z.isPointLight){const xe=B.camera,Xe=B.matrix,at=z.distance||xe.far;at!==xe.far&&(xe.far=at,xe.updateProjectionMatrix()),$t.setFromMatrixPosition(z.matrixWorld),xe.position.copy($t),Ci.copy(xe.position),Ci.add(Nf[ve]),xe.up.copy(yf[ve]),xe.lookAt(Ci),xe.updateMatrixWorld(),Xe.makeTranslation(-$t.x,-$t.y,-$t.z),Jn.multiplyMatrices(xe.projectionMatrix,xe.matrixWorldInverse),B._frustum.setFromProjectionMatrix(Jn,xe.coordinateSystem,xe.reversedDepth)}else B.updateMatrices(z);n=B.getFrustum(),m(D,s,B.camera,z,this.type)}B.isPointLightShadow!==!0&&this.type===Qt&&N(B,s),B.needsUpdate=!1}o=this.type,l.needsUpdate=!1,e.setRenderTarget(h,L,A)};function N(v,D){const s=i.update(Y);p.defines.VSM_SAMPLES!==v.blurSamples&&(p.defines.VSM_SAMPLES=v.blurSamples,x.defines.VSM_SAMPLES=v.blurSamples,p.needsUpdate=!0,x.needsUpdate=!0),v.mapPass===null&&(v.mapPass=new Pt(f.x,f.y,{format:Yt,type:Ot})),p.uniforms.shadow_pass.value=v.map.depthTexture,p.uniforms.resolution.value=v.mapSize,p.uniforms.radius.value=v.radius,e.setRenderTarget(v.mapPass),e.clear(),e.renderBufferDirect(D,null,s,p,Y,null),x.uniforms.shadow_pass.value=v.mapPass.texture,x.uniforms.resolution.value=v.mapSize,x.uniforms.radius.value=v.radius,e.setRenderTarget(v.map),e.clear(),e.renderBufferDirect(D,null,s,x,Y,null)}function O(v,D,s,h){let L=null;const A=s.isPointLight===!0?v.customDistanceMaterial:v.customDepthMaterial;if(A!==void 0)L=A;else if(L=s.isPointLight===!0?H:g,e.localClippingEnabled&&D.clipShadows===!0&&Array.isArray(D.clippingPlanes)&&D.clippingPlanes.length!==0||D.displacementMap&&D.displacementScale!==0||D.alphaMap&&D.alphaTest>0||D.map&&D.alphaTest>0||D.alphaToCoverage===!0){const I=L.uuid,Q=D.uuid;let Z=T[I];Z===void 0&&(Z={},T[I]=Z);let V=Z[Q];V===void 0&&(V=L.clone(),Z[Q]=V,D.addEventListener("dispose",b)),L=V}if(L.visible=D.visible,L.wireframe=D.wireframe,h===Qt?L.side=D.shadowSide!==null?D.shadowSide:D.side:L.side=D.shadowSide!==null?D.shadowSide:G[D.side],L.alphaMap=D.alphaMap,L.alphaTest=D.alphaToCoverage===!0?.5:D.alphaTest,L.map=D.map,L.clipShadows=D.clipShadows,L.clippingPlanes=D.clippingPlanes,L.clipIntersection=D.clipIntersection,L.displacementMap=D.displacementMap,L.displacementScale=D.displacementScale,L.displacementBias=D.displacementBias,L.wireframeLinewidth=D.wireframeLinewidth,L.linewidth=D.linewidth,s.isPointLight===!0&&L.isMeshDistanceMaterial===!0){const I=e.properties.get(L);I.light=s}return L}function m(v,D,s,h,L){if(v.visible===!1)return;if(v.layers.test(D.layers)&&(v.isMesh||v.isLine||v.isPoints)&&(v.castShadow||v.receiveShadow&&L===Qt)&&(!v.frustumCulled||n.intersectsObject(v))){v.modelViewMatrix.multiplyMatrices(s.matrixWorldInverse,v.matrixWorld);const Q=i.update(v),Z=v.material;if(Array.isArray(Z)){const V=Q.groups;for(let z=0,B=V.length;z<B;z++){const $=V[z],le=Z[$.materialIndex];if(le&&le.visible){const ge=O(v,le,h,L);v.onBeforeShadow(e,v,D,s,Q,ge,$),e.renderBufferDirect(s,null,Q,ge,v,$),v.onAfterShadow(e,v,D,s,Q,ge,$)}}}else if(Z.visible){const V=O(v,Z,h,L);v.onBeforeShadow(e,v,D,s,Q,V,null),e.renderBufferDirect(s,null,Q,V,v,null),v.onAfterShadow(e,v,D,s,Q,V,null)}}const I=v.children;for(let Q=0,Z=I.length;Q<Z;Q++)m(I[Q],D,s,h,L)}function b(v){v.target.removeEventListener("dispose",b);for(const s in T){const h=T[s],L=v.target.uuid;L in h&&(h[L].dispose(),delete h[L])}}}function Of(e,i){function t(){let _=!1;const ee=new mt;let W=null;const re=new mt(0,0,0,0);return{setMask:function(de){W!==de&&!_&&(e.colorMask(de,de,de,de),W=de)},setLocked:function(de){_=de},setClear:function(de,K,_e,he,je){je===!0&&(de*=he,K*=he,_e*=he),ee.set(de,K,_e,he),re.equals(ee)===!1&&(e.clearColor(de,K,_e,he),re.copy(ee))},reset:function(){_=!1,W=null,re.set(-1,0,0,0)}}}function n(){let _=!1,ee=!1,W=null,re=null,de=null;return{setReversed:function(K){if(ee!==K){const _e=i.get("EXT_clip_control");K?_e.clipControlEXT(_e.LOWER_LEFT_EXT,_e.ZERO_TO_ONE_EXT):_e.clipControlEXT(_e.LOWER_LEFT_EXT,_e.NEGATIVE_ONE_TO_ONE_EXT),ee=K;const he=de;de=null,this.setClear(he)}},getReversed:function(){return ee},setTest:function(K){K?J(e.DEPTH_TEST):be(e.DEPTH_TEST)},setMask:function(K){W!==K&&!_&&(e.depthMask(K),W=K)},setFunc:function(K){if(ee&&(K=Lr[K]),re!==K){switch(K){case Rr:e.depthFunc(e.NEVER);break;case Ar:e.depthFunc(e.ALWAYS);break;case Tr:e.depthFunc(e.LESS);break;case Qi:e.depthFunc(e.LEQUAL);break;case Mr:e.depthFunc(e.EQUAL);break;case xr:e.depthFunc(e.GEQUAL);break;case Er:e.depthFunc(e.GREATER);break;case Sr:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}re=K}},setLocked:function(K){_=K},setClear:function(K){de!==K&&(de=K,ee&&(K=1-K),e.clearDepth(K))},reset:function(){_=!1,W=null,re=null,de=null,ee=!1}}}function f(){let _=!1,ee=null,W=null,re=null,de=null,K=null,_e=null,he=null,je=null;return{setTest:function(Ye){_||(Ye?J(e.STENCIL_TEST):be(e.STENCIL_TEST))},setMask:function(Ye){ee!==Ye&&!_&&(e.stencilMask(Ye),ee=Ye)},setFunc:function(Ye,xt,Mt){(W!==Ye||re!==xt||de!==Mt)&&(e.stencilFunc(Ye,xt,Mt),W=Ye,re=xt,de=Mt)},setOp:function(Ye,xt,Mt){(K!==Ye||_e!==xt||he!==Mt)&&(e.stencilOp(Ye,xt,Mt),K=Ye,_e=xt,he=Mt)},setLocked:function(Ye){_=Ye},setClear:function(Ye){je!==Ye&&(e.clearStencil(Ye),je=Ye)},reset:function(){_=!1,ee=null,W=null,re=null,de=null,K=null,_e=null,he=null,je=null}}}const c=new t,u=new n,g=new f,H=new WeakMap,T=new WeakMap;let q={},G={},p={},x=new WeakMap,U=[],Y=null,l=!1,o=null,N=null,O=null,m=null,b=null,v=null,D=null,s=new Qe(0,0,0),h=0,L=!1,A=null,I=null,Q=null,Z=null,V=null;const z=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let B=!1,$=0;const le=e.getParameter(e.VERSION);le.indexOf("WebGL")!==-1?($=parseFloat(/^WebGL (\d)/.exec(le)[1]),B=$>=1):le.indexOf("OpenGL ES")!==-1&&($=parseFloat(/^OpenGL ES (\d)/.exec(le)[1]),B=$>=2);let ge=null,ve={};const xe=e.getParameter(e.SCISSOR_BOX),Xe=e.getParameter(e.VIEWPORT),at=new mt().fromArray(xe),He=new mt().fromArray(Xe);function X(_,ee,W,re){const de=new Uint8Array(4),K=e.createTexture();e.bindTexture(_,K),e.texParameteri(_,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(_,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let _e=0;_e<W;_e++)_===e.TEXTURE_3D||_===e.TEXTURE_2D_ARRAY?e.texImage3D(ee,0,e.RGBA,1,1,re,0,e.RGBA,e.UNSIGNED_BYTE,de):e.texImage2D(ee+_e,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,de);return K}const te={};te[e.TEXTURE_2D]=X(e.TEXTURE_2D,e.TEXTURE_2D,1),te[e.TEXTURE_CUBE_MAP]=X(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),te[e.TEXTURE_2D_ARRAY]=X(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),te[e.TEXTURE_3D]=X(e.TEXTURE_3D,e.TEXTURE_3D,1,1),c.setClear(0,0,0,1),u.setClear(1),g.setClear(0),J(e.DEPTH_TEST),u.setFunc(Qi),rt(!1),st(Ji),J(e.CULL_FACE),Oe(jt);function J(_){q[_]!==!0&&(e.enable(_),q[_]=!0)}function be(_){q[_]!==!1&&(e.disable(_),q[_]=!1)}function Ce(_,ee){return p[_]!==ee?(e.bindFramebuffer(_,ee),p[_]=ee,_===e.DRAW_FRAMEBUFFER&&(p[e.FRAMEBUFFER]=ee),_===e.FRAMEBUFFER&&(p[e.DRAW_FRAMEBUFFER]=ee),!0):!1}function Ae(_,ee){let W=U,re=!1;if(_){W=x.get(ee),W===void 0&&(W=[],x.set(ee,W));const de=_.textures;if(W.length!==de.length||W[0]!==e.COLOR_ATTACHMENT0){for(let K=0,_e=de.length;K<_e;K++)W[K]=e.COLOR_ATTACHMENT0+K;W.length=de.length,re=!0}}else W[0]!==e.BACK&&(W[0]=e.BACK,re=!0);re&&e.drawBuffers(W)}function tt(_){return Y!==_?(e.useProgram(_),Y=_,!0):!1}const De={[Zt]:e.FUNC_ADD,[nr]:e.FUNC_SUBTRACT,[ir]:e.FUNC_REVERSE_SUBTRACT};De[wr]=e.MIN,De[Ur]=e.MAX;const We={[vr]:e.ZERO,[gr]:e.ONE,[_r]:e.SRC_COLOR,[mr]:e.SRC_ALPHA,[hr]:e.SRC_ALPHA_SATURATE,[pr]:e.DST_COLOR,[ur]:e.DST_ALPHA,[dr]:e.ONE_MINUS_SRC_COLOR,[fr]:e.ONE_MINUS_SRC_ALPHA,[lr]:e.ONE_MINUS_DST_COLOR,[cr]:e.ONE_MINUS_DST_ALPHA,[sr]:e.CONSTANT_COLOR,[or]:e.ONE_MINUS_CONSTANT_COLOR,[rr]:e.CONSTANT_ALPHA,[ar]:e.ONE_MINUS_CONSTANT_ALPHA};function Oe(_,ee,W,re,de,K,_e,he,je,Ye){if(_===jt){l===!0&&(be(e.BLEND),l=!1);return}if(l===!1&&(J(e.BLEND),l=!0),_!==Pr){if(_!==o||Ye!==L){if((N!==Zt||b!==Zt)&&(e.blendEquation(e.FUNC_ADD),N=Zt,b=Zt),Ye)switch(_){case fi:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case tn:e.blendFunc(e.ONE,e.ONE);break;case en:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case ji:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:Ze("WebGLState: Invalid blending: ",_);break}else switch(_){case fi:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case tn:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case en:Ze("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case ji:Ze("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ze("WebGLState: Invalid blending: ",_);break}O=null,m=null,v=null,D=null,s.set(0,0,0),h=0,o=_,L=Ye}return}de=de||ee,K=K||W,_e=_e||re,(ee!==N||de!==b)&&(e.blendEquationSeparate(De[ee],De[de]),N=ee,b=de),(W!==O||re!==m||K!==v||_e!==D)&&(e.blendFuncSeparate(We[W],We[re],We[K],We[_e]),O=W,m=re,v=K,D=_e),(he.equals(s)===!1||je!==h)&&(e.blendColor(he.r,he.g,he.b,je),s.copy(he),h=je),o=_,L=!1}function Ne(_,ee){_.side===Ct?be(e.CULL_FACE):J(e.CULL_FACE);let W=_.side===St;ee&&(W=!W),rt(W),_.blending===fi&&_.transparent===!1?Oe(jt):Oe(_.blending,_.blendEquation,_.blendSrc,_.blendDst,_.blendEquationAlpha,_.blendSrcAlpha,_.blendDstAlpha,_.blendColor,_.blendAlpha,_.premultipliedAlpha),u.setFunc(_.depthFunc),u.setTest(_.depthTest),u.setMask(_.depthWrite),c.setMask(_.colorWrite);const re=_.stencilWrite;g.setTest(re),re&&(g.setMask(_.stencilWriteMask),g.setFunc(_.stencilFunc,_.stencilRef,_.stencilFuncMask),g.setOp(_.stencilFail,_.stencilZFail,_.stencilZPass)),dt(_.polygonOffset,_.polygonOffsetFactor,_.polygonOffsetUnits),_.alphaToCoverage===!0?J(e.SAMPLE_ALPHA_TO_COVERAGE):be(e.SAMPLE_ALPHA_TO_COVERAGE)}function rt(_){A!==_&&(_?e.frontFace(e.CW):e.frontFace(e.CCW),A=_)}function st(_){_!==br?(J(e.CULL_FACE),_!==I&&(_===Ji?e.cullFace(e.BACK):_===Cr?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))):be(e.CULL_FACE),I=_}function ft(_){_!==Q&&(B&&e.lineWidth(_),Q=_)}function dt(_,ee,W){_?(J(e.POLYGON_OFFSET_FILL),(Z!==ee||V!==W)&&(Z=ee,V=W,u.getReversed()&&(ee=-ee),e.polygonOffset(ee,W))):be(e.POLYGON_OFFSET_FILL)}function Je(_){_?J(e.SCISSOR_TEST):be(e.SCISSOR_TEST)}function ot(_){_===void 0&&(_=e.TEXTURE0+z-1),ge!==_&&(e.activeTexture(_),ge=_)}function S(_,ee,W){W===void 0&&(ge===null?W=e.TEXTURE0+z-1:W=ge);let re=ve[W];re===void 0&&(re={type:void 0,texture:void 0},ve[W]=re),(re.type!==_||re.texture!==ee)&&(ge!==W&&(e.activeTexture(W),ge=W),e.bindTexture(_,ee||te[_]),re.type=_,re.texture=ee)}function pt(){const _=ve[ge];_!==void 0&&_.type!==void 0&&(e.bindTexture(_.type,null),_.type=void 0,_.texture=void 0)}function Be(){try{e.compressedTexImage2D(...arguments)}catch(_){Ze("WebGLState:",_)}}function d(){try{e.compressedTexImage3D(...arguments)}catch(_){Ze("WebGLState:",_)}}function a(){try{e.texSubImage2D(...arguments)}catch(_){Ze("WebGLState:",_)}}function M(){try{e.texSubImage3D(...arguments)}catch(_){Ze("WebGLState:",_)}}function P(){try{e.compressedTexSubImage2D(...arguments)}catch(_){Ze("WebGLState:",_)}}function y(){try{e.compressedTexSubImage3D(...arguments)}catch(_){Ze("WebGLState:",_)}}function j(){try{e.texStorage2D(...arguments)}catch(_){Ze("WebGLState:",_)}}function ie(){try{e.texStorage3D(...arguments)}catch(_){Ze("WebGLState:",_)}}function F(){try{e.texImage2D(...arguments)}catch(_){Ze("WebGLState:",_)}}function k(){try{e.texImage3D(...arguments)}catch(_){Ze("WebGLState:",_)}}function ne(_){return G[_]!==void 0?G[_]:e.getParameter(_)}function Se(_,ee){G[_]!==ee&&(e.pixelStorei(_,ee),G[_]=ee)}function oe(_){at.equals(_)===!1&&(e.scissor(_.x,_.y,_.z,_.w),at.copy(_))}function ae(_){He.equals(_)===!1&&(e.viewport(_.x,_.y,_.z,_.w),He.copy(_))}function Te(_,ee){let W=T.get(ee);W===void 0&&(W=new WeakMap,T.set(ee,W));let re=W.get(_);re===void 0&&(re=e.getUniformBlockIndex(ee,_.name),W.set(_,re))}function Re(_,ee){const re=T.get(ee).get(_);H.get(ee)!==re&&(e.uniformBlockBinding(ee,re,_.__bindingPointIndex),H.set(ee,re))}function Pe(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),u.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),q={},G={},ge=null,ve={},p={},x=new WeakMap,U=[],Y=null,l=!1,o=null,N=null,O=null,m=null,b=null,v=null,D=null,s=new Qe(0,0,0),h=0,L=!1,A=null,I=null,Q=null,Z=null,V=null,at.set(0,0,e.canvas.width,e.canvas.height),He.set(0,0,e.canvas.width,e.canvas.height),c.reset(),u.reset(),g.reset()}return{buffers:{color:c,depth:u,stencil:g},enable:J,disable:be,bindFramebuffer:Ce,drawBuffers:Ae,useProgram:tt,setBlending:Oe,setMaterial:Ne,setFlipSided:rt,setCullFace:st,setLineWidth:ft,setPolygonOffset:dt,setScissorTest:Je,activeTexture:ot,bindTexture:S,unbindTexture:pt,compressedTexImage2D:Be,compressedTexImage3D:d,texImage2D:F,texImage3D:k,pixelStorei:Se,getParameter:ne,updateUBOMapping:Te,uniformBlockBinding:Re,texStorage2D:j,texStorage3D:ie,texSubImage2D:a,texSubImage3D:M,compressedTexSubImage2D:P,compressedTexSubImage3D:y,scissor:oe,viewport:ae,reset:Pe}}function Bf(e,i,t,n,f,c,u){const g=i.has("WEBGL_multisampled_render_to_texture")?i.get("WEBGL_multisampled_render_to_texture"):null,H=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),T=new _t,q=new WeakMap,G=new Set;let p;const x=new WeakMap;let U=!1;try{U=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function Y(d,a){return U?new OffscreenCanvas(d,a):Wr("canvas")}function l(d,a,M){let P=1;const y=Be(d);if((y.width>M||y.height>M)&&(P=M/Math.max(y.width,y.height)),P<1)if(typeof HTMLImageElement<"u"&&d instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&d instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&d instanceof ImageBitmap||typeof VideoFrame<"u"&&d instanceof VideoFrame){const j=Math.floor(P*y.width),ie=Math.floor(P*y.height);p===void 0&&(p=Y(j,ie));const F=a?Y(j,ie):p;return F.width=j,F.height=ie,F.getContext("2d").drawImage(d,0,0,j,ie),Ge("WebGLRenderer: Texture has been resized from ("+y.width+"x"+y.height+") to ("+j+"x"+ie+")."),F}else return"data"in d&&Ge("WebGLRenderer: Image in DataTexture is too big ("+y.width+"x"+y.height+")."),d;return d}function o(d){return d.generateMipmaps}function N(d){e.generateMipmap(d)}function O(d){return d.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:d.isWebGL3DRenderTarget?e.TEXTURE_3D:d.isWebGLArrayRenderTarget||d.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function m(d,a,M,P,y,j=!1){if(d!==null){if(e[d]!==void 0)return e[d];Ge("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+d+"'")}let ie;P&&(ie=i.get("EXT_texture_norm16"),ie||Ge("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let F=a;if(a===e.RED&&(M===e.FLOAT&&(F=e.R32F),M===e.HALF_FLOAT&&(F=e.R16F),M===e.UNSIGNED_BYTE&&(F=e.R8),M===e.UNSIGNED_SHORT&&ie&&(F=ie.R16_EXT),M===e.SHORT&&ie&&(F=ie.R16_SNORM_EXT)),a===e.RED_INTEGER&&(M===e.UNSIGNED_BYTE&&(F=e.R8UI),M===e.UNSIGNED_SHORT&&(F=e.R16UI),M===e.UNSIGNED_INT&&(F=e.R32UI),M===e.BYTE&&(F=e.R8I),M===e.SHORT&&(F=e.R16I),M===e.INT&&(F=e.R32I)),a===e.RG&&(M===e.FLOAT&&(F=e.RG32F),M===e.HALF_FLOAT&&(F=e.RG16F),M===e.UNSIGNED_BYTE&&(F=e.RG8),M===e.UNSIGNED_SHORT&&ie&&(F=ie.RG16_EXT),M===e.SHORT&&ie&&(F=ie.RG16_SNORM_EXT)),a===e.RG_INTEGER&&(M===e.UNSIGNED_BYTE&&(F=e.RG8UI),M===e.UNSIGNED_SHORT&&(F=e.RG16UI),M===e.UNSIGNED_INT&&(F=e.RG32UI),M===e.BYTE&&(F=e.RG8I),M===e.SHORT&&(F=e.RG16I),M===e.INT&&(F=e.RG32I)),a===e.RGB_INTEGER&&(M===e.UNSIGNED_BYTE&&(F=e.RGB8UI),M===e.UNSIGNED_SHORT&&(F=e.RGB16UI),M===e.UNSIGNED_INT&&(F=e.RGB32UI),M===e.BYTE&&(F=e.RGB8I),M===e.SHORT&&(F=e.RGB16I),M===e.INT&&(F=e.RGB32I)),a===e.RGBA_INTEGER&&(M===e.UNSIGNED_BYTE&&(F=e.RGBA8UI),M===e.UNSIGNED_SHORT&&(F=e.RGBA16UI),M===e.UNSIGNED_INT&&(F=e.RGBA32UI),M===e.BYTE&&(F=e.RGBA8I),M===e.SHORT&&(F=e.RGBA16I),M===e.INT&&(F=e.RGBA32I)),a===e.RGB&&(M===e.UNSIGNED_SHORT&&ie&&(F=ie.RGB16_EXT),M===e.SHORT&&ie&&(F=ie.RGB16_SNORM_EXT),M===e.UNSIGNED_INT_5_9_9_9_REV&&(F=e.RGB9_E5),M===e.UNSIGNED_INT_10F_11F_11F_REV&&(F=e.R11F_G11F_B10F)),a===e.RGBA){const k=j?pa:$e.getTransfer(y);M===e.FLOAT&&(F=e.RGBA32F),M===e.HALF_FLOAT&&(F=e.RGBA16F),M===e.UNSIGNED_BYTE&&(F=k===qe?e.SRGB8_ALPHA8:e.RGBA8),M===e.UNSIGNED_SHORT&&ie&&(F=ie.RGBA16_EXT),M===e.SHORT&&ie&&(F=ie.RGBA16_SNORM_EXT),M===e.UNSIGNED_SHORT_4_4_4_4&&(F=e.RGBA4),M===e.UNSIGNED_SHORT_5_5_5_1&&(F=e.RGB5_A1)}return(F===e.R16F||F===e.R32F||F===e.RG16F||F===e.RG32F||F===e.RGBA16F||F===e.RGBA32F)&&i.get("EXT_color_buffer_float"),F}function b(d,a){let M;return d?a===null||a===Bt||a===ni?M=e.DEPTH24_STENCIL8:a===It?M=e.DEPTH32F_STENCIL8:a===pi&&(M=e.DEPTH24_STENCIL8,Ge("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):a===null||a===Bt||a===ni?M=e.DEPTH_COMPONENT24:a===It?M=e.DEPTH_COMPONENT32F:a===pi&&(M=e.DEPTH_COMPONENT16),M}function v(d,a){return o(d)===!0||d.isFramebufferTexture&&d.minFilter!==Ft&&d.minFilter!==Et?Math.log2(Math.max(a.width,a.height))+1:d.mipmaps!==void 0&&d.mipmaps.length>0?d.mipmaps.length:d.isCompressedTexture&&Array.isArray(d.image)?a.mipmaps.length:1}function D(d){const a=d.target;a.removeEventListener("dispose",D),h(a),a.isVideoTexture&&q.delete(a),a.isHTMLTexture&&G.delete(a)}function s(d){const a=d.target;a.removeEventListener("dispose",s),A(a)}function h(d){const a=n.get(d);if(a.__webglInit===void 0)return;const M=d.source,P=x.get(M);if(P){const y=P[a.__cacheKey];y.usedTimes--,y.usedTimes===0&&L(d),Object.keys(P).length===0&&x.delete(M)}n.remove(d)}function L(d){const a=n.get(d);e.deleteTexture(a.__webglTexture);const M=d.source,P=x.get(M);delete P[a.__cacheKey],u.memory.textures--}function A(d){const a=n.get(d);if(d.depthTexture&&(d.depthTexture.dispose(),n.remove(d.depthTexture)),d.isWebGLCubeRenderTarget)for(let P=0;P<6;P++){if(Array.isArray(a.__webglFramebuffer[P]))for(let y=0;y<a.__webglFramebuffer[P].length;y++)e.deleteFramebuffer(a.__webglFramebuffer[P][y]);else e.deleteFramebuffer(a.__webglFramebuffer[P]);a.__webglDepthbuffer&&e.deleteRenderbuffer(a.__webglDepthbuffer[P])}else{if(Array.isArray(a.__webglFramebuffer))for(let P=0;P<a.__webglFramebuffer.length;P++)e.deleteFramebuffer(a.__webglFramebuffer[P]);else e.deleteFramebuffer(a.__webglFramebuffer);if(a.__webglDepthbuffer&&e.deleteRenderbuffer(a.__webglDepthbuffer),a.__webglMultisampledFramebuffer&&e.deleteFramebuffer(a.__webglMultisampledFramebuffer),a.__webglColorRenderbuffer)for(let P=0;P<a.__webglColorRenderbuffer.length;P++)a.__webglColorRenderbuffer[P]&&e.deleteRenderbuffer(a.__webglColorRenderbuffer[P]);a.__webglDepthRenderbuffer&&e.deleteRenderbuffer(a.__webglDepthRenderbuffer)}const M=d.textures;for(let P=0,y=M.length;P<y;P++){const j=n.get(M[P]);j.__webglTexture&&(e.deleteTexture(j.__webglTexture),u.memory.textures--),n.remove(M[P])}n.remove(d)}let I=0;function Q(){I=0}function Z(){return I}function V(d){I=d}function z(){const d=I;return d>=f.maxTextures&&Ge("WebGLTextures: Trying to use "+d+" texture units while this GPU supports only "+f.maxTextures),I+=1,d}function B(d){const a=[];return a.push(d.wrapS),a.push(d.wrapT),a.push(d.wrapR||0),a.push(d.magFilter),a.push(d.minFilter),a.push(d.anisotropy),a.push(d.internalFormat),a.push(d.format),a.push(d.type),a.push(d.generateMipmaps),a.push(d.premultiplyAlpha),a.push(d.flipY),a.push(d.unpackAlignment),a.push(d.colorSpace),a.join()}function $(d,a){const M=n.get(d);if(d.isVideoTexture&&S(d),d.isRenderTargetTexture===!1&&d.isExternalTexture!==!0&&d.version>0&&M.__version!==d.version){const P=d.image;if(P===null)Ge("WebGLRenderer: Texture marked for update but no image data found.");else if(P.complete===!1)Ge("WebGLRenderer: Texture marked for update but image is incomplete");else{be(M,d,a);return}}else d.isExternalTexture&&(M.__webglTexture=d.sourceTexture?d.sourceTexture:null);t.bindTexture(e.TEXTURE_2D,M.__webglTexture,e.TEXTURE0+a)}function le(d,a){const M=n.get(d);if(d.isRenderTargetTexture===!1&&d.version>0&&M.__version!==d.version){be(M,d,a);return}else d.isExternalTexture&&(M.__webglTexture=d.sourceTexture?d.sourceTexture:null);t.bindTexture(e.TEXTURE_2D_ARRAY,M.__webglTexture,e.TEXTURE0+a)}function ge(d,a){const M=n.get(d);if(d.isRenderTargetTexture===!1&&d.version>0&&M.__version!==d.version){be(M,d,a);return}t.bindTexture(e.TEXTURE_3D,M.__webglTexture,e.TEXTURE0+a)}function ve(d,a){const M=n.get(d);if(d.isCubeDepthTexture!==!0&&d.version>0&&M.__version!==d.version){Ce(M,d,a);return}t.bindTexture(e.TEXTURE_CUBE_MAP,M.__webglTexture,e.TEXTURE0+a)}const xe={[Ir]:e.REPEAT,[Di]:e.CLAMP_TO_EDGE,[Dr]:e.MIRRORED_REPEAT},Xe={[Ft]:e.NEAREST,[Nr]:e.NEAREST_MIPMAP_NEAREST,[oi]:e.NEAREST_MIPMAP_LINEAR,[Et]:e.LINEAR,[Si]:e.LINEAR_MIPMAP_NEAREST,[Wt]:e.LINEAR_MIPMAP_LINEAR},at={[Hr]:e.NEVER,[Gr]:e.ALWAYS,[Br]:e.LESS,[Oi]:e.LEQUAL,[Or]:e.EQUAL,[Fi]:e.GEQUAL,[Fr]:e.GREATER,[yr]:e.NOTEQUAL};function He(d,a){if(a.type===It&&i.has("OES_texture_float_linear")===!1&&(a.magFilter===Et||a.magFilter===Si||a.magFilter===oi||a.magFilter===Wt||a.minFilter===Et||a.minFilter===Si||a.minFilter===oi||a.minFilter===Wt)&&Ge("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),e.texParameteri(d,e.TEXTURE_WRAP_S,xe[a.wrapS]),e.texParameteri(d,e.TEXTURE_WRAP_T,xe[a.wrapT]),(d===e.TEXTURE_3D||d===e.TEXTURE_2D_ARRAY)&&e.texParameteri(d,e.TEXTURE_WRAP_R,xe[a.wrapR]),e.texParameteri(d,e.TEXTURE_MAG_FILTER,Xe[a.magFilter]),e.texParameteri(d,e.TEXTURE_MIN_FILTER,Xe[a.minFilter]),a.compareFunction&&(e.texParameteri(d,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(d,e.TEXTURE_COMPARE_FUNC,at[a.compareFunction])),i.has("EXT_texture_filter_anisotropic")===!0){if(a.magFilter===Ft||a.minFilter!==oi&&a.minFilter!==Wt||a.type===It&&i.has("OES_texture_float_linear")===!1)return;if(a.anisotropy>1||n.get(a).__currentAnisotropy){const M=i.get("EXT_texture_filter_anisotropic");e.texParameterf(d,M.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(a.anisotropy,f.getMaxAnisotropy())),n.get(a).__currentAnisotropy=a.anisotropy}}}function X(d,a){let M=!1;d.__webglInit===void 0&&(d.__webglInit=!0,a.addEventListener("dispose",D));const P=a.source;let y=x.get(P);y===void 0&&(y={},x.set(P,y));const j=B(a);if(j!==d.__cacheKey){y[j]===void 0&&(y[j]={texture:e.createTexture(),usedTimes:0},u.memory.textures++,M=!0),y[j].usedTimes++;const ie=y[d.__cacheKey];ie!==void 0&&(y[d.__cacheKey].usedTimes--,ie.usedTimes===0&&L(a)),d.__cacheKey=j,d.__webglTexture=y[j].texture}return M}function te(d,a,M){return Math.floor(Math.floor(d/M)/a)}function J(d,a,M,P){const j=d.updateRanges;if(j.length===0)t.texSubImage2D(e.TEXTURE_2D,0,0,0,a.width,a.height,M,P,a.data);else{j.sort((Se,oe)=>Se.start-oe.start);let ie=0;for(let Se=1;Se<j.length;Se++){const oe=j[ie],ae=j[Se],Te=oe.start+oe.count,Re=te(ae.start,a.width,4),Pe=te(oe.start,a.width,4);ae.start<=Te+1&&Re===Pe&&te(ae.start+ae.count-1,a.width,4)===Re?oe.count=Math.max(oe.count,ae.start+ae.count-oe.start):(++ie,j[ie]=ae)}j.length=ie+1;const F=t.getParameter(e.UNPACK_ROW_LENGTH),k=t.getParameter(e.UNPACK_SKIP_PIXELS),ne=t.getParameter(e.UNPACK_SKIP_ROWS);t.pixelStorei(e.UNPACK_ROW_LENGTH,a.width);for(let Se=0,oe=j.length;Se<oe;Se++){const ae=j[Se],Te=Math.floor(ae.start/4),Re=Math.ceil(ae.count/4),Pe=Te%a.width,_=Math.floor(Te/a.width),ee=Re,W=1;t.pixelStorei(e.UNPACK_SKIP_PIXELS,Pe),t.pixelStorei(e.UNPACK_SKIP_ROWS,_),t.texSubImage2D(e.TEXTURE_2D,0,Pe,_,ee,W,M,P,a.data)}d.clearUpdateRanges(),t.pixelStorei(e.UNPACK_ROW_LENGTH,F),t.pixelStorei(e.UNPACK_SKIP_PIXELS,k),t.pixelStorei(e.UNPACK_SKIP_ROWS,ne)}}function be(d,a,M){let P=e.TEXTURE_2D;(a.isDataArrayTexture||a.isCompressedArrayTexture)&&(P=e.TEXTURE_2D_ARRAY),a.isData3DTexture&&(P=e.TEXTURE_3D);const y=X(d,a),j=a.source;t.bindTexture(P,d.__webglTexture,e.TEXTURE0+M);const ie=n.get(j);if(j.version!==ie.__version||y===!0){if(t.activeTexture(e.TEXTURE0+M),(typeof ImageBitmap<"u"&&a.image instanceof ImageBitmap)===!1){const W=$e.getPrimaries($e.workingColorSpace),re=a.colorSpace===Vt?null:$e.getPrimaries(a.colorSpace),de=a.colorSpace===Vt||W===re?e.NONE:e.BROWSER_DEFAULT_WEBGL;t.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,a.flipY),t.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,a.premultiplyAlpha),t.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,de)}t.pixelStorei(e.UNPACK_ALIGNMENT,a.unpackAlignment);let k=l(a.image,!1,f.maxTextureSize);k=pt(a,k);const ne=c.convert(a.format,a.colorSpace),Se=c.convert(a.type);let oe=m(a.internalFormat,ne,Se,a.normalized,a.colorSpace,a.isVideoTexture);He(P,a);let ae;const Te=a.mipmaps,Re=a.isVideoTexture!==!0,Pe=ie.__version===void 0||y===!0,_=j.dataReady,ee=v(a,k);if(a.isDepthTexture)oe=b(a.format===kt,a.type),Pe&&(Re?t.texStorage2D(e.TEXTURE_2D,1,oe,k.width,k.height):t.texImage2D(e.TEXTURE_2D,0,oe,k.width,k.height,0,ne,Se,null));else if(a.isDataTexture)if(Te.length>0){Re&&Pe&&t.texStorage2D(e.TEXTURE_2D,ee,oe,Te[0].width,Te[0].height);for(let W=0,re=Te.length;W<re;W++)ae=Te[W],Re?_&&t.texSubImage2D(e.TEXTURE_2D,W,0,0,ae.width,ae.height,ne,Se,ae.data):t.texImage2D(e.TEXTURE_2D,W,oe,ae.width,ae.height,0,ne,Se,ae.data);a.generateMipmaps=!1}else Re?(Pe&&t.texStorage2D(e.TEXTURE_2D,ee,oe,k.width,k.height),_&&J(a,k,ne,Se)):t.texImage2D(e.TEXTURE_2D,0,oe,k.width,k.height,0,ne,Se,k.data);else if(a.isCompressedTexture)if(a.isCompressedArrayTexture){Re&&Pe&&t.texStorage3D(e.TEXTURE_2D_ARRAY,ee,oe,Te[0].width,Te[0].height,k.depth);for(let W=0,re=Te.length;W<re;W++)if(ae=Te[W],a.format!==Nt)if(ne!==null)if(Re){if(_)if(a.layerUpdates.size>0){const de=nn(ae.width,ae.height,a.format,a.type);for(const K of a.layerUpdates){const _e=ae.data.subarray(K*de/ae.data.BYTES_PER_ELEMENT,(K+1)*de/ae.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,W,0,0,K,ae.width,ae.height,1,ne,_e)}a.clearLayerUpdates()}else t.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,W,0,0,0,ae.width,ae.height,k.depth,ne,ae.data)}else t.compressedTexImage3D(e.TEXTURE_2D_ARRAY,W,oe,ae.width,ae.height,k.depth,0,ae.data,0,0);else Ge("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Re?_&&t.texSubImage3D(e.TEXTURE_2D_ARRAY,W,0,0,0,ae.width,ae.height,k.depth,ne,Se,ae.data):t.texImage3D(e.TEXTURE_2D_ARRAY,W,oe,ae.width,ae.height,k.depth,0,ne,Se,ae.data)}else{Re&&Pe&&t.texStorage2D(e.TEXTURE_2D,ee,oe,Te[0].width,Te[0].height);for(let W=0,re=Te.length;W<re;W++)ae=Te[W],a.format!==Nt?ne!==null?Re?_&&t.compressedTexSubImage2D(e.TEXTURE_2D,W,0,0,ae.width,ae.height,ne,ae.data):t.compressedTexImage2D(e.TEXTURE_2D,W,oe,ae.width,ae.height,0,ae.data):Ge("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Re?_&&t.texSubImage2D(e.TEXTURE_2D,W,0,0,ae.width,ae.height,ne,Se,ae.data):t.texImage2D(e.TEXTURE_2D,W,oe,ae.width,ae.height,0,ne,Se,ae.data)}else if(a.isDataArrayTexture)if(Re){if(Pe&&t.texStorage3D(e.TEXTURE_2D_ARRAY,ee,oe,k.width,k.height,k.depth),_)if(a.layerUpdates.size>0){const W=nn(k.width,k.height,a.format,a.type);for(const re of a.layerUpdates){const de=k.data.subarray(re*W/k.data.BYTES_PER_ELEMENT,(re+1)*W/k.data.BYTES_PER_ELEMENT);t.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,re,k.width,k.height,1,ne,Se,de)}a.clearLayerUpdates()}else t.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,k.width,k.height,k.depth,ne,Se,k.data)}else t.texImage3D(e.TEXTURE_2D_ARRAY,0,oe,k.width,k.height,k.depth,0,ne,Se,k.data);else if(a.isData3DTexture)Re?(Pe&&t.texStorage3D(e.TEXTURE_3D,ee,oe,k.width,k.height,k.depth),_&&t.texSubImage3D(e.TEXTURE_3D,0,0,0,0,k.width,k.height,k.depth,ne,Se,k.data)):t.texImage3D(e.TEXTURE_3D,0,oe,k.width,k.height,k.depth,0,ne,Se,k.data);else if(a.isFramebufferTexture){if(Pe)if(Re)t.texStorage2D(e.TEXTURE_2D,ee,oe,k.width,k.height);else{let W=k.width,re=k.height;for(let de=0;de<ee;de++)t.texImage2D(e.TEXTURE_2D,de,oe,W,re,0,ne,Se,null),W>>=1,re>>=1}}else if(a.isHTMLTexture){if("texElementImage2D"in e){const W=e.canvas;if(W.hasAttribute("layoutsubtree")||W.setAttribute("layoutsubtree","true"),k.parentNode!==W){W.appendChild(k),G.add(a),W.onpaint=re=>{const de=re.changedElements;for(const K of G)de.includes(K.image)&&(K.needsUpdate=!0)},W.requestPaint();return}if(e.texElementImage2D.length===3)e.texElementImage2D(e.TEXTURE_2D,e.RGBA8,k);else{const de=e.RGBA,K=e.RGBA,_e=e.UNSIGNED_BYTE;e.texElementImage2D(e.TEXTURE_2D,0,de,K,_e,k)}e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)}}else if(Te.length>0){if(Re&&Pe){const W=Be(Te[0]);t.texStorage2D(e.TEXTURE_2D,ee,oe,W.width,W.height)}for(let W=0,re=Te.length;W<re;W++)ae=Te[W],Re?_&&t.texSubImage2D(e.TEXTURE_2D,W,0,0,ne,Se,ae):t.texImage2D(e.TEXTURE_2D,W,oe,ne,Se,ae);a.generateMipmaps=!1}else if(Re){if(Pe){const W=Be(k);t.texStorage2D(e.TEXTURE_2D,ee,oe,W.width,W.height)}_&&t.texSubImage2D(e.TEXTURE_2D,0,0,0,ne,Se,k)}else t.texImage2D(e.TEXTURE_2D,0,oe,ne,Se,k);o(a)&&N(P),ie.__version=j.version,a.onUpdate&&a.onUpdate(a)}d.__version=a.version}function Ce(d,a,M){if(a.image.length!==6)return;const P=X(d,a),y=a.source;t.bindTexture(e.TEXTURE_CUBE_MAP,d.__webglTexture,e.TEXTURE0+M);const j=n.get(y);if(y.version!==j.__version||P===!0){t.activeTexture(e.TEXTURE0+M);const ie=$e.getPrimaries($e.workingColorSpace),F=a.colorSpace===Vt?null:$e.getPrimaries(a.colorSpace),k=a.colorSpace===Vt||ie===F?e.NONE:e.BROWSER_DEFAULT_WEBGL;t.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,a.flipY),t.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,a.premultiplyAlpha),t.pixelStorei(e.UNPACK_ALIGNMENT,a.unpackAlignment),t.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,k);const ne=a.isCompressedTexture||a.image[0].isCompressedTexture,Se=a.image[0]&&a.image[0].isDataTexture,oe=[];for(let K=0;K<6;K++)!ne&&!Se?oe[K]=l(a.image[K],!0,f.maxCubemapSize):oe[K]=Se?a.image[K].image:a.image[K],oe[K]=pt(a,oe[K]);const ae=oe[0],Te=c.convert(a.format,a.colorSpace),Re=c.convert(a.type),Pe=m(a.internalFormat,Te,Re,a.normalized,a.colorSpace),_=a.isVideoTexture!==!0,ee=j.__version===void 0||P===!0,W=y.dataReady;let re=v(a,ae);He(e.TEXTURE_CUBE_MAP,a);let de;if(ne){_&&ee&&t.texStorage2D(e.TEXTURE_CUBE_MAP,re,Pe,ae.width,ae.height);for(let K=0;K<6;K++){de=oe[K].mipmaps;for(let _e=0;_e<de.length;_e++){const he=de[_e];a.format!==Nt?Te!==null?_?W&&t.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e,0,0,he.width,he.height,Te,he.data):t.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e,Pe,he.width,he.height,0,he.data):Ge("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):_?W&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e,0,0,he.width,he.height,Te,Re,he.data):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e,Pe,he.width,he.height,0,Te,Re,he.data)}}}else{if(de=a.mipmaps,_&&ee){de.length>0&&re++;const K=Be(oe[0]);t.texStorage2D(e.TEXTURE_CUBE_MAP,re,Pe,K.width,K.height)}for(let K=0;K<6;K++)if(Se){_?W&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,0,0,oe[K].width,oe[K].height,Te,Re,oe[K].data):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,Pe,oe[K].width,oe[K].height,0,Te,Re,oe[K].data);for(let _e=0;_e<de.length;_e++){const je=de[_e].image[K].image;_?W&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e+1,0,0,je.width,je.height,Te,Re,je.data):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e+1,Pe,je.width,je.height,0,Te,Re,je.data)}}else{_?W&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,0,0,Te,Re,oe[K]):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,Pe,Te,Re,oe[K]);for(let _e=0;_e<de.length;_e++){const he=de[_e];_?W&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e+1,0,0,Te,Re,he.image[K]):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+K,_e+1,Pe,Te,Re,he.image[K])}}}o(a)&&N(e.TEXTURE_CUBE_MAP),j.__version=y.version,a.onUpdate&&a.onUpdate(a)}d.__version=a.version}function Ae(d,a,M,P,y,j){const ie=c.convert(M.format,M.colorSpace),F=c.convert(M.type),k=m(M.internalFormat,ie,F,M.normalized,M.colorSpace),ne=n.get(a),Se=n.get(M);if(Se.__renderTarget=a,!ne.__hasExternalTextures){const oe=Math.max(1,a.width>>j),ae=Math.max(1,a.height>>j);y===e.TEXTURE_3D||y===e.TEXTURE_2D_ARRAY?t.texImage3D(y,j,k,oe,ae,a.depth,0,ie,F,null):t.texImage2D(y,j,k,oe,ae,0,ie,F,null)}t.bindFramebuffer(e.FRAMEBUFFER,d),ot(a)?g.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,P,y,Se.__webglTexture,0,Je(a)):(y===e.TEXTURE_2D||y>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&y<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,P,y,Se.__webglTexture,j),t.bindFramebuffer(e.FRAMEBUFFER,null)}function tt(d,a,M){if(e.bindRenderbuffer(e.RENDERBUFFER,d),a.depthBuffer){const P=a.depthTexture,y=P&&P.isDepthTexture?P.type:null,j=b(a.stencilBuffer,y),ie=a.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;ot(a)?g.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,Je(a),j,a.width,a.height):M?e.renderbufferStorageMultisample(e.RENDERBUFFER,Je(a),j,a.width,a.height):e.renderbufferStorage(e.RENDERBUFFER,j,a.width,a.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,ie,e.RENDERBUFFER,d)}else{const P=a.textures;for(let y=0;y<P.length;y++){const j=P[y],ie=c.convert(j.format,j.colorSpace),F=c.convert(j.type),k=m(j.internalFormat,ie,F,j.normalized,j.colorSpace);ot(a)?g.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,Je(a),k,a.width,a.height):M?e.renderbufferStorageMultisample(e.RENDERBUFFER,Je(a),k,a.width,a.height):e.renderbufferStorage(e.RENDERBUFFER,k,a.width,a.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function De(d,a,M){const P=a.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(e.FRAMEBUFFER,d),!(a.depthTexture&&a.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const y=n.get(a.depthTexture);if(y.__renderTarget=a,(!y.__webglTexture||a.depthTexture.image.width!==a.width||a.depthTexture.image.height!==a.height)&&(a.depthTexture.image.width=a.width,a.depthTexture.image.height=a.height,a.depthTexture.needsUpdate=!0),P){if(y.__webglInit===void 0&&(y.__webglInit=!0,a.depthTexture.addEventListener("dispose",D)),y.__webglTexture===void 0){y.__webglTexture=e.createTexture(),t.bindTexture(e.TEXTURE_CUBE_MAP,y.__webglTexture),He(e.TEXTURE_CUBE_MAP,a.depthTexture);const ne=c.convert(a.depthTexture.format),Se=c.convert(a.depthTexture.type);let oe;a.depthTexture.format===Kt?oe=e.DEPTH_COMPONENT24:a.depthTexture.format===kt&&(oe=e.DEPTH24_STENCIL8);for(let ae=0;ae<6;ae++)e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+ae,0,oe,a.width,a.height,0,ne,Se,null)}}else $(a.depthTexture,0);const j=y.__webglTexture,ie=Je(a),F=P?e.TEXTURE_CUBE_MAP_POSITIVE_X+M:e.TEXTURE_2D,k=a.depthTexture.format===kt?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(a.depthTexture.format===Kt)ot(a)?g.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,k,F,j,0,ie):e.framebufferTexture2D(e.FRAMEBUFFER,k,F,j,0);else if(a.depthTexture.format===kt)ot(a)?g.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,k,F,j,0,ie):e.framebufferTexture2D(e.FRAMEBUFFER,k,F,j,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function We(d){const a=n.get(d),M=d.isWebGLCubeRenderTarget===!0;if(a.__boundDepthTexture!==d.depthTexture){const P=d.depthTexture;if(a.__depthDisposeCallback&&a.__depthDisposeCallback(),P){const y=()=>{delete a.__boundDepthTexture,delete a.__depthDisposeCallback,P.removeEventListener("dispose",y)};P.addEventListener("dispose",y),a.__depthDisposeCallback=y}a.__boundDepthTexture=P}if(d.depthTexture&&!a.__autoAllocateDepthBuffer)if(M)for(let P=0;P<6;P++)De(a.__webglFramebuffer[P],d,P);else{const P=d.texture.mipmaps;P&&P.length>0?De(a.__webglFramebuffer[0],d,0):De(a.__webglFramebuffer,d,0)}else if(M){a.__webglDepthbuffer=[];for(let P=0;P<6;P++)if(t.bindFramebuffer(e.FRAMEBUFFER,a.__webglFramebuffer[P]),a.__webglDepthbuffer[P]===void 0)a.__webglDepthbuffer[P]=e.createRenderbuffer(),tt(a.__webglDepthbuffer[P],d,!1);else{const y=d.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,j=a.__webglDepthbuffer[P];e.bindRenderbuffer(e.RENDERBUFFER,j),e.framebufferRenderbuffer(e.FRAMEBUFFER,y,e.RENDERBUFFER,j)}}else{const P=d.texture.mipmaps;if(P&&P.length>0?t.bindFramebuffer(e.FRAMEBUFFER,a.__webglFramebuffer[0]):t.bindFramebuffer(e.FRAMEBUFFER,a.__webglFramebuffer),a.__webglDepthbuffer===void 0)a.__webglDepthbuffer=e.createRenderbuffer(),tt(a.__webglDepthbuffer,d,!1);else{const y=d.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,j=a.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,j),e.framebufferRenderbuffer(e.FRAMEBUFFER,y,e.RENDERBUFFER,j)}}t.bindFramebuffer(e.FRAMEBUFFER,null)}function Oe(d,a,M){const P=n.get(d);a!==void 0&&Ae(P.__webglFramebuffer,d,d.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),M!==void 0&&We(d)}function Ne(d){const a=d.texture,M=n.get(d),P=n.get(a);d.addEventListener("dispose",s);const y=d.textures,j=d.isWebGLCubeRenderTarget===!0,ie=y.length>1;if(ie||(P.__webglTexture===void 0&&(P.__webglTexture=e.createTexture()),P.__version=a.version,u.memory.textures++),j){M.__webglFramebuffer=[];for(let F=0;F<6;F++)if(a.mipmaps&&a.mipmaps.length>0){M.__webglFramebuffer[F]=[];for(let k=0;k<a.mipmaps.length;k++)M.__webglFramebuffer[F][k]=e.createFramebuffer()}else M.__webglFramebuffer[F]=e.createFramebuffer()}else{if(a.mipmaps&&a.mipmaps.length>0){M.__webglFramebuffer=[];for(let F=0;F<a.mipmaps.length;F++)M.__webglFramebuffer[F]=e.createFramebuffer()}else M.__webglFramebuffer=e.createFramebuffer();if(ie)for(let F=0,k=y.length;F<k;F++){const ne=n.get(y[F]);ne.__webglTexture===void 0&&(ne.__webglTexture=e.createTexture(),u.memory.textures++)}if(d.samples>0&&ot(d)===!1){M.__webglMultisampledFramebuffer=e.createFramebuffer(),M.__webglColorRenderbuffer=[],t.bindFramebuffer(e.FRAMEBUFFER,M.__webglMultisampledFramebuffer);for(let F=0;F<y.length;F++){const k=y[F];M.__webglColorRenderbuffer[F]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,M.__webglColorRenderbuffer[F]);const ne=c.convert(k.format,k.colorSpace),Se=c.convert(k.type),oe=m(k.internalFormat,ne,Se,k.normalized,k.colorSpace,d.isXRRenderTarget===!0),ae=Je(d);e.renderbufferStorageMultisample(e.RENDERBUFFER,ae,oe,d.width,d.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+F,e.RENDERBUFFER,M.__webglColorRenderbuffer[F])}e.bindRenderbuffer(e.RENDERBUFFER,null),d.depthBuffer&&(M.__webglDepthRenderbuffer=e.createRenderbuffer(),tt(M.__webglDepthRenderbuffer,d,!0)),t.bindFramebuffer(e.FRAMEBUFFER,null)}}if(j){t.bindTexture(e.TEXTURE_CUBE_MAP,P.__webglTexture),He(e.TEXTURE_CUBE_MAP,a);for(let F=0;F<6;F++)if(a.mipmaps&&a.mipmaps.length>0)for(let k=0;k<a.mipmaps.length;k++)Ae(M.__webglFramebuffer[F][k],d,a,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+F,k);else Ae(M.__webglFramebuffer[F],d,a,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+F,0);o(a)&&N(e.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ie){for(let F=0,k=y.length;F<k;F++){const ne=y[F],Se=n.get(ne);let oe=e.TEXTURE_2D;(d.isWebGL3DRenderTarget||d.isWebGLArrayRenderTarget)&&(oe=d.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),t.bindTexture(oe,Se.__webglTexture),He(oe,ne),Ae(M.__webglFramebuffer,d,ne,e.COLOR_ATTACHMENT0+F,oe,0),o(ne)&&N(oe)}t.unbindTexture()}else{let F=e.TEXTURE_2D;if((d.isWebGL3DRenderTarget||d.isWebGLArrayRenderTarget)&&(F=d.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),t.bindTexture(F,P.__webglTexture),He(F,a),a.mipmaps&&a.mipmaps.length>0)for(let k=0;k<a.mipmaps.length;k++)Ae(M.__webglFramebuffer[k],d,a,e.COLOR_ATTACHMENT0,F,k);else Ae(M.__webglFramebuffer,d,a,e.COLOR_ATTACHMENT0,F,0);o(a)&&N(F),t.unbindTexture()}d.depthBuffer&&We(d)}function rt(d){const a=d.textures;for(let M=0,P=a.length;M<P;M++){const y=a[M];if(o(y)){const j=O(d),ie=n.get(y).__webglTexture;t.bindTexture(j,ie),N(j),t.unbindTexture()}}}const st=[],ft=[];function dt(d){if(d.samples>0){if(ot(d)===!1){const a=d.textures,M=d.width,P=d.height;let y=e.COLOR_BUFFER_BIT;const j=d.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,ie=n.get(d),F=a.length>1;if(F)for(let ne=0;ne<a.length;ne++)t.bindFramebuffer(e.FRAMEBUFFER,ie.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+ne,e.RENDERBUFFER,null),t.bindFramebuffer(e.FRAMEBUFFER,ie.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+ne,e.TEXTURE_2D,null,0);t.bindFramebuffer(e.READ_FRAMEBUFFER,ie.__webglMultisampledFramebuffer);const k=d.texture.mipmaps;k&&k.length>0?t.bindFramebuffer(e.DRAW_FRAMEBUFFER,ie.__webglFramebuffer[0]):t.bindFramebuffer(e.DRAW_FRAMEBUFFER,ie.__webglFramebuffer);for(let ne=0;ne<a.length;ne++){if(d.resolveDepthBuffer&&(d.depthBuffer&&(y|=e.DEPTH_BUFFER_BIT),d.stencilBuffer&&d.resolveStencilBuffer&&(y|=e.STENCIL_BUFFER_BIT)),F){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,ie.__webglColorRenderbuffer[ne]);const Se=n.get(a[ne]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,Se,0)}e.blitFramebuffer(0,0,M,P,0,0,M,P,y,e.NEAREST),H===!0&&(st.length=0,ft.length=0,st.push(e.COLOR_ATTACHMENT0+ne),d.depthBuffer&&d.resolveDepthBuffer===!1&&(st.push(j),ft.push(j),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,ft)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,st))}if(t.bindFramebuffer(e.READ_FRAMEBUFFER,null),t.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),F)for(let ne=0;ne<a.length;ne++){t.bindFramebuffer(e.FRAMEBUFFER,ie.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+ne,e.RENDERBUFFER,ie.__webglColorRenderbuffer[ne]);const Se=n.get(a[ne]).__webglTexture;t.bindFramebuffer(e.FRAMEBUFFER,ie.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+ne,e.TEXTURE_2D,Se,0)}t.bindFramebuffer(e.DRAW_FRAMEBUFFER,ie.__webglMultisampledFramebuffer)}else if(d.depthBuffer&&d.resolveDepthBuffer===!1&&H){const a=d.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[a])}}}function Je(d){return Math.min(f.maxSamples,d.samples)}function ot(d){const a=n.get(d);return d.samples>0&&i.has("WEBGL_multisampled_render_to_texture")===!0&&a.__useRenderToTexture!==!1}function S(d){const a=u.render.frame;q.get(d)!==a&&(q.set(d,a),d.update())}function pt(d,a){const M=d.colorSpace,P=d.format,y=d.type;return d.isCompressedTexture===!0||d.isVideoTexture===!0||M!==Vr&&M!==Vt&&($e.getTransfer(M)===qe?(P!==Nt||y!==bt)&&Ge("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ze("WebGLTextures: Unsupported texture color space:",M)),a}function Be(d){return typeof HTMLImageElement<"u"&&d instanceof HTMLImageElement?(T.width=d.naturalWidth||d.width,T.height=d.naturalHeight||d.height):typeof VideoFrame<"u"&&d instanceof VideoFrame?(T.width=d.displayWidth,T.height=d.displayHeight):(T.width=d.width,T.height=d.height),T}this.allocateTextureUnit=z,this.resetTextureUnits=Q,this.getTextureUnits=Z,this.setTextureUnits=V,this.setTexture2D=$,this.setTexture2DArray=le,this.setTexture3D=ge,this.setTextureCube=ve,this.rebindTextures=Oe,this.setupRenderTarget=Ne,this.updateRenderTargetMipmap=rt,this.updateMultisampleRenderTarget=dt,this.setupDepthRenderbuffer=We,this.setupFrameBufferTexture=Ae,this.useMultisampledRTT=ot,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function Gf(e,i){function t(n,f=Vt){let c;const u=$e.getTransfer(f);if(n===bt)return e.UNSIGNED_BYTE;if(n===ma)return e.UNSIGNED_SHORT_4_4_4_4;if(n===_a)return e.UNSIGNED_SHORT_5_5_5_1;if(n===kr)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===zr)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===Xr)return e.BYTE;if(n===Yr)return e.SHORT;if(n===pi)return e.UNSIGNED_SHORT;if(n===ia)return e.INT;if(n===Bt)return e.UNSIGNED_INT;if(n===It)return e.FLOAT;if(n===Ot)return e.HALF_FLOAT;if(n===Kr)return e.ALPHA;if(n===qr)return e.RGB;if(n===Nt)return e.RGBA;if(n===Kt)return e.DEPTH_COMPONENT;if(n===kt)return e.DEPTH_STENCIL;if(n===Zr)return e.RED;if(n===ga)return e.RED_INTEGER;if(n===Yt)return e.RG;if(n===va)return e.RG_INTEGER;if(n===Sa)return e.RGBA_INTEGER;if(n===Ei||n===xi||n===Mi||n===Ti)if(u===qe)if(c=i.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(n===Ei)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===xi)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Mi)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Ti)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=i.get("WEBGL_compressed_texture_s3tc"),c!==null){if(n===Ei)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===xi)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Mi)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Ti)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===an||n===rn||n===on||n===sn)if(c=i.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(n===an)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===rn)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===on)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===sn)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===cn||n===ln||n===fn||n===dn||n===un||n===wi||n===pn)if(c=i.get("WEBGL_compressed_texture_etc"),c!==null){if(n===cn||n===ln)return u===qe?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(n===fn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(n===dn)return c.COMPRESSED_R11_EAC;if(n===un)return c.COMPRESSED_SIGNED_R11_EAC;if(n===wi)return c.COMPRESSED_RG11_EAC;if(n===pn)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===hn||n===mn||n===_n||n===gn||n===vn||n===Sn||n===En||n===xn||n===Mn||n===Tn||n===An||n===Rn||n===bn||n===Cn)if(c=i.get("WEBGL_compressed_texture_astc"),c!==null){if(n===hn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===mn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===_n)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===gn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===vn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Sn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===En)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===xn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Mn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Tn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===An)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Rn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===bn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Cn)return u===qe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Pn||n===Ln||n===wn)if(c=i.get("EXT_texture_compression_bptc"),c!==null){if(n===Pn)return u===qe?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Ln)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===wn)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Un||n===Dn||n===Ui||n===In)if(c=i.get("EXT_texture_compression_rgtc"),c!==null){if(n===Un)return c.COMPRESSED_RED_RGTC1_EXT;if(n===Dn)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Ui)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===In)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===ni?e.UNSIGNED_INT_24_8:e[n]!==void 0?e[n]:null}return{convert:t}}const Hf=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Vf=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Wf{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(i,t){if(this.texture===null){const n=new Ea(i.texture);(i.depthNear!==t.depthNear||i.depthFar!==t.depthFar)&&(this.depthNear=i.depthNear,this.depthFar=i.depthFar),this.texture=n}}getMesh(i){if(this.texture!==null&&this.mesh===null){const t=i.cameras[0].viewport,n=new ei({vertexShader:Hf,fragmentShader:Vf,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new zt(new ea(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class kf extends $r{constructor(i,t){super();const n=this;let f=null,c=1,u=null,g="local-floor",H=1,T=null,q=null,G=null,p=null,x=null,U=null;const Y=typeof XRWebGLBinding<"u",l=new Wf,o={},N=t.getContextAttributes();let O=null,m=null;const b=[],v=[],D=new _t;let s=null;const h=new Ai;h.viewport=new mt;const L=new Ai;L.viewport=new mt;const A=[h,L],I=new Qr;let Q=null,Z=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(X){let te=b[X];return te===void 0&&(te=new Ri,b[X]=te),te.getTargetRaySpace()},this.getControllerGrip=function(X){let te=b[X];return te===void 0&&(te=new Ri,b[X]=te),te.getGripSpace()},this.getHand=function(X){let te=b[X];return te===void 0&&(te=new Ri,b[X]=te),te.getHandSpace()};function V(X){const te=v.indexOf(X.inputSource);if(te===-1)return;const J=b[te];J!==void 0&&(J.update(X.inputSource,X.frame,T||u),J.dispatchEvent({type:X.type,data:X.inputSource}))}function z(){f.removeEventListener("select",V),f.removeEventListener("selectstart",V),f.removeEventListener("selectend",V),f.removeEventListener("squeeze",V),f.removeEventListener("squeezestart",V),f.removeEventListener("squeezeend",V),f.removeEventListener("end",z),f.removeEventListener("inputsourceschange",B);for(let X=0;X<b.length;X++){const te=v[X];te!==null&&(v[X]=null,b[X].disconnect(te))}Q=null,Z=null,l.reset();for(const X in o)delete o[X];i.setRenderTarget(O),x=null,p=null,G=null,f=null,m=null,He.stop(),n.isPresenting=!1,i.setPixelRatio(s),i.setSize(D.width,D.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(X){c=X,n.isPresenting===!0&&Ge("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(X){g=X,n.isPresenting===!0&&Ge("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return T||u},this.setReferenceSpace=function(X){T=X},this.getBaseLayer=function(){return p!==null?p:x},this.getBinding=function(){return G===null&&Y&&(G=new XRWebGLBinding(f,t)),G},this.getFrame=function(){return U},this.getSession=function(){return f},this.setSession=async function(X){if(f=X,f!==null){if(O=i.getRenderTarget(),f.addEventListener("select",V),f.addEventListener("selectstart",V),f.addEventListener("selectend",V),f.addEventListener("squeeze",V),f.addEventListener("squeezestart",V),f.addEventListener("squeezeend",V),f.addEventListener("end",z),f.addEventListener("inputsourceschange",B),N.xrCompatible!==!0&&await t.makeXRCompatible(),s=i.getPixelRatio(),i.getSize(D),Y&&"createProjectionLayer"in XRWebGLBinding.prototype){let J=null,be=null,Ce=null;N.depth&&(Ce=N.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,J=N.stencil?kt:Kt,be=N.stencil?ni:Bt);const Ae={colorFormat:t.RGBA8,depthFormat:Ce,scaleFactor:c};G=this.getBinding(),p=G.createProjectionLayer(Ae),f.updateRenderState({layers:[p]}),i.setPixelRatio(1),i.setSize(p.textureWidth,p.textureHeight,!1),m=new Pt(p.textureWidth,p.textureHeight,{format:Nt,type:bt,depthTexture:new ii(p.textureWidth,p.textureHeight,be,void 0,void 0,void 0,void 0,void 0,void 0,J),stencilBuffer:N.stencil,colorSpace:i.outputColorSpace,samples:N.antialias?4:0,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}else{const J={antialias:N.antialias,alpha:!0,depth:N.depth,stencil:N.stencil,framebufferScaleFactor:c};x=new XRWebGLLayer(f,t,J),f.updateRenderState({baseLayer:x}),i.setPixelRatio(1),i.setSize(x.framebufferWidth,x.framebufferHeight,!1),m=new Pt(x.framebufferWidth,x.framebufferHeight,{format:Nt,type:bt,colorSpace:i.outputColorSpace,stencilBuffer:N.stencil,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1})}m.isXRRenderTarget=!0,this.setFoveation(H),T=null,u=await f.requestReferenceSpace(g),He.setContext(f),He.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(f!==null)return f.environmentBlendMode},this.getDepthTexture=function(){return l.getDepthTexture()};function B(X){for(let te=0;te<X.removed.length;te++){const J=X.removed[te],be=v.indexOf(J);be>=0&&(v[be]=null,b[be].disconnect(J))}for(let te=0;te<X.added.length;te++){const J=X.added[te];let be=v.indexOf(J);if(be===-1){for(let Ae=0;Ae<b.length;Ae++)if(Ae>=v.length){v.push(J),be=Ae;break}else if(v[Ae]===null){v[Ae]=J,be=Ae;break}if(be===-1)break}const Ce=b[be];Ce&&Ce.connect(J)}}const $=new Fe,le=new Fe;function ge(X,te,J){$.setFromMatrixPosition(te.matrixWorld),le.setFromMatrixPosition(J.matrixWorld);const be=$.distanceTo(le),Ce=te.projectionMatrix.elements,Ae=J.projectionMatrix.elements,tt=Ce[14]/(Ce[10]-1),De=Ce[14]/(Ce[10]+1),We=(Ce[9]+1)/Ce[5],Oe=(Ce[9]-1)/Ce[5],Ne=(Ce[8]-1)/Ce[0],rt=(Ae[8]+1)/Ae[0],st=tt*Ne,ft=tt*rt,dt=be/(-Ne+rt),Je=dt*-Ne;if(te.matrixWorld.decompose(X.position,X.quaternion,X.scale),X.translateX(Je),X.translateZ(dt),X.matrixWorld.compose(X.position,X.quaternion,X.scale),X.matrixWorldInverse.copy(X.matrixWorld).invert(),Ce[10]===-1)X.projectionMatrix.copy(te.projectionMatrix),X.projectionMatrixInverse.copy(te.projectionMatrixInverse);else{const ot=tt+dt,S=De+dt,pt=st-Je,Be=ft+(be-Je),d=We*De/S*ot,a=Oe*De/S*ot;X.projectionMatrix.makePerspective(pt,Be,d,a,ot,S),X.projectionMatrixInverse.copy(X.projectionMatrix).invert()}}function ve(X,te){te===null?X.matrixWorld.copy(X.matrix):X.matrixWorld.multiplyMatrices(te.matrixWorld,X.matrix),X.matrixWorldInverse.copy(X.matrixWorld).invert()}this.updateCamera=function(X){if(f===null)return;let te=X.near,J=X.far;l.texture!==null&&(l.depthNear>0&&(te=l.depthNear),l.depthFar>0&&(J=l.depthFar)),I.near=L.near=h.near=te,I.far=L.far=h.far=J,(Q!==I.near||Z!==I.far)&&(f.updateRenderState({depthNear:I.near,depthFar:I.far}),Q=I.near,Z=I.far),I.layers.mask=X.layers.mask|6,h.layers.mask=I.layers.mask&-5,L.layers.mask=I.layers.mask&-3;const be=X.parent,Ce=I.cameras;ve(I,be);for(let Ae=0;Ae<Ce.length;Ae++)ve(Ce[Ae],be);Ce.length===2?ge(I,h,L):I.projectionMatrix.copy(h.projectionMatrix),xe(X,I,be)};function xe(X,te,J){J===null?X.matrix.copy(te.matrixWorld):(X.matrix.copy(J.matrixWorld),X.matrix.invert(),X.matrix.multiply(te.matrixWorld)),X.matrix.decompose(X.position,X.quaternion,X.scale),X.updateMatrixWorld(!0),X.projectionMatrix.copy(te.projectionMatrix),X.projectionMatrixInverse.copy(te.projectionMatrixInverse),X.isPerspectiveCamera&&(X.fov=Jr*2*Math.atan(1/X.projectionMatrix.elements[5]),X.zoom=1)}this.getCamera=function(){return I},this.getFoveation=function(){if(!(p===null&&x===null))return H},this.setFoveation=function(X){H=X,p!==null&&(p.fixedFoveation=X),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=X)},this.hasDepthSensing=function(){return l.texture!==null},this.getDepthSensingMesh=function(){return l.getMesh(I)},this.getCameraTexture=function(X){return o[X]};let Xe=null;function at(X,te){if(q=te.getViewerPose(T||u),U=te,q!==null){const J=q.views;x!==null&&(i.setRenderTargetFramebuffer(m,x.framebuffer),i.setRenderTarget(m));let be=!1;J.length!==I.cameras.length&&(I.cameras.length=0,be=!0);for(let De=0;De<J.length;De++){const We=J[De];let Oe=null;if(x!==null)Oe=x.getViewport(We);else{const rt=G.getViewSubImage(p,We);Oe=rt.viewport,De===0&&(i.setRenderTargetTextures(m,rt.colorTexture,rt.depthStencilTexture),i.setRenderTarget(m))}let Ne=A[De];Ne===void 0&&(Ne=new Ai,Ne.layers.enable(De),Ne.viewport=new mt,A[De]=Ne),Ne.matrix.fromArray(We.transform.matrix),Ne.matrix.decompose(Ne.position,Ne.quaternion,Ne.scale),Ne.projectionMatrix.fromArray(We.projectionMatrix),Ne.projectionMatrixInverse.copy(Ne.projectionMatrix).invert(),Ne.viewport.set(Oe.x,Oe.y,Oe.width,Oe.height),De===0&&(I.matrix.copy(Ne.matrix),I.matrix.decompose(I.position,I.quaternion,I.scale)),be===!0&&I.cameras.push(Ne)}const Ce=f.enabledFeatures;if(Ce&&Ce.includes("depth-sensing")&&f.depthUsage=="gpu-optimized"&&Y){G=n.getBinding();const De=G.getDepthInformation(J[0]);De&&De.isValid&&De.texture&&l.init(De,f.renderState)}if(Ce&&Ce.includes("camera-access")&&Y){i.state.unbindTexture(),G=n.getBinding();for(let De=0;De<J.length;De++){const We=J[De].camera;if(We){let Oe=o[We];Oe||(Oe=new Ea,o[We]=Oe);const Ne=G.getCameraImage(We);Oe.sourceTexture=Ne}}}}for(let J=0;J<b.length;J++){const be=v[J],Ce=b[J];be!==null&&Ce!==void 0&&Ce.update(be,te,T||u)}Xe&&Xe(X,te),te.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:te}),U=null}const He=new xa;He.setAnimationLoop(at),this.setAnimationLoop=function(X){Xe=X},this.dispose=function(){}}}const zf=new Xt,Pa=new Ie;Pa.set(-1,0,0,0,1,0,0,0,1);function Xf(e,i){function t(l,o){l.matrixAutoUpdate===!0&&l.updateMatrix(),o.value.copy(l.matrix)}function n(l,o){o.color.getRGB(l.fogColor.value,ta(e)),o.isFog?(l.fogNear.value=o.near,l.fogFar.value=o.far):o.isFogExp2&&(l.fogDensity.value=o.density)}function f(l,o,N,O,m){o.isNodeMaterial?o.uniformsNeedUpdate=!1:o.isMeshBasicMaterial?c(l,o):o.isMeshLambertMaterial?(c(l,o),o.envMap&&(l.envMapIntensity.value=o.envMapIntensity)):o.isMeshToonMaterial?(c(l,o),G(l,o)):o.isMeshPhongMaterial?(c(l,o),q(l,o),o.envMap&&(l.envMapIntensity.value=o.envMapIntensity)):o.isMeshStandardMaterial?(c(l,o),p(l,o),o.isMeshPhysicalMaterial&&x(l,o,m)):o.isMeshMatcapMaterial?(c(l,o),U(l,o)):o.isMeshDepthMaterial?c(l,o):o.isMeshDistanceMaterial?(c(l,o),Y(l,o)):o.isMeshNormalMaterial?c(l,o):o.isLineBasicMaterial?(u(l,o),o.isLineDashedMaterial&&g(l,o)):o.isPointsMaterial?H(l,o,N,O):o.isSpriteMaterial?T(l,o):o.isShadowMaterial?(l.color.value.copy(o.color),l.opacity.value=o.opacity):o.isShaderMaterial&&(o.uniformsNeedUpdate=!1)}function c(l,o){l.opacity.value=o.opacity,o.color&&l.diffuse.value.copy(o.color),o.emissive&&l.emissive.value.copy(o.emissive).multiplyScalar(o.emissiveIntensity),o.map&&(l.map.value=o.map,t(o.map,l.mapTransform)),o.alphaMap&&(l.alphaMap.value=o.alphaMap,t(o.alphaMap,l.alphaMapTransform)),o.bumpMap&&(l.bumpMap.value=o.bumpMap,t(o.bumpMap,l.bumpMapTransform),l.bumpScale.value=o.bumpScale,o.side===St&&(l.bumpScale.value*=-1)),o.normalMap&&(l.normalMap.value=o.normalMap,t(o.normalMap,l.normalMapTransform),l.normalScale.value.copy(o.normalScale),o.side===St&&l.normalScale.value.negate()),o.displacementMap&&(l.displacementMap.value=o.displacementMap,t(o.displacementMap,l.displacementMapTransform),l.displacementScale.value=o.displacementScale,l.displacementBias.value=o.displacementBias),o.emissiveMap&&(l.emissiveMap.value=o.emissiveMap,t(o.emissiveMap,l.emissiveMapTransform)),o.specularMap&&(l.specularMap.value=o.specularMap,t(o.specularMap,l.specularMapTransform)),o.alphaTest>0&&(l.alphaTest.value=o.alphaTest);const N=i.get(o),O=N.envMap,m=N.envMapRotation;O&&(l.envMap.value=O,l.envMapRotation.value.setFromMatrix4(zf.makeRotationFromEuler(m)).transpose(),O.isCubeTexture&&O.isRenderTargetTexture===!1&&l.envMapRotation.value.premultiply(Pa),l.reflectivity.value=o.reflectivity,l.ior.value=o.ior,l.refractionRatio.value=o.refractionRatio),o.lightMap&&(l.lightMap.value=o.lightMap,l.lightMapIntensity.value=o.lightMapIntensity,t(o.lightMap,l.lightMapTransform)),o.aoMap&&(l.aoMap.value=o.aoMap,l.aoMapIntensity.value=o.aoMapIntensity,t(o.aoMap,l.aoMapTransform))}function u(l,o){l.diffuse.value.copy(o.color),l.opacity.value=o.opacity,o.map&&(l.map.value=o.map,t(o.map,l.mapTransform))}function g(l,o){l.dashSize.value=o.dashSize,l.totalSize.value=o.dashSize+o.gapSize,l.scale.value=o.scale}function H(l,o,N,O){l.diffuse.value.copy(o.color),l.opacity.value=o.opacity,l.size.value=o.size*N,l.scale.value=O*.5,o.map&&(l.map.value=o.map,t(o.map,l.uvTransform)),o.alphaMap&&(l.alphaMap.value=o.alphaMap,t(o.alphaMap,l.alphaMapTransform)),o.alphaTest>0&&(l.alphaTest.value=o.alphaTest)}function T(l,o){l.diffuse.value.copy(o.color),l.opacity.value=o.opacity,l.rotation.value=o.rotation,o.map&&(l.map.value=o.map,t(o.map,l.mapTransform)),o.alphaMap&&(l.alphaMap.value=o.alphaMap,t(o.alphaMap,l.alphaMapTransform)),o.alphaTest>0&&(l.alphaTest.value=o.alphaTest)}function q(l,o){l.specular.value.copy(o.specular),l.shininess.value=Math.max(o.shininess,1e-4)}function G(l,o){o.gradientMap&&(l.gradientMap.value=o.gradientMap)}function p(l,o){l.metalness.value=o.metalness,o.metalnessMap&&(l.metalnessMap.value=o.metalnessMap,t(o.metalnessMap,l.metalnessMapTransform)),l.roughness.value=o.roughness,o.roughnessMap&&(l.roughnessMap.value=o.roughnessMap,t(o.roughnessMap,l.roughnessMapTransform)),o.envMap&&(l.envMapIntensity.value=o.envMapIntensity)}function x(l,o,N){l.ior.value=o.ior,o.sheen>0&&(l.sheenColor.value.copy(o.sheenColor).multiplyScalar(o.sheen),l.sheenRoughness.value=o.sheenRoughness,o.sheenColorMap&&(l.sheenColorMap.value=o.sheenColorMap,t(o.sheenColorMap,l.sheenColorMapTransform)),o.sheenRoughnessMap&&(l.sheenRoughnessMap.value=o.sheenRoughnessMap,t(o.sheenRoughnessMap,l.sheenRoughnessMapTransform))),o.clearcoat>0&&(l.clearcoat.value=o.clearcoat,l.clearcoatRoughness.value=o.clearcoatRoughness,o.clearcoatMap&&(l.clearcoatMap.value=o.clearcoatMap,t(o.clearcoatMap,l.clearcoatMapTransform)),o.clearcoatRoughnessMap&&(l.clearcoatRoughnessMap.value=o.clearcoatRoughnessMap,t(o.clearcoatRoughnessMap,l.clearcoatRoughnessMapTransform)),o.clearcoatNormalMap&&(l.clearcoatNormalMap.value=o.clearcoatNormalMap,t(o.clearcoatNormalMap,l.clearcoatNormalMapTransform),l.clearcoatNormalScale.value.copy(o.clearcoatNormalScale),o.side===St&&l.clearcoatNormalScale.value.negate())),o.dispersion>0&&(l.dispersion.value=o.dispersion),o.iridescence>0&&(l.iridescence.value=o.iridescence,l.iridescenceIOR.value=o.iridescenceIOR,l.iridescenceThicknessMinimum.value=o.iridescenceThicknessRange[0],l.iridescenceThicknessMaximum.value=o.iridescenceThicknessRange[1],o.iridescenceMap&&(l.iridescenceMap.value=o.iridescenceMap,t(o.iridescenceMap,l.iridescenceMapTransform)),o.iridescenceThicknessMap&&(l.iridescenceThicknessMap.value=o.iridescenceThicknessMap,t(o.iridescenceThicknessMap,l.iridescenceThicknessMapTransform))),o.transmission>0&&(l.transmission.value=o.transmission,l.transmissionSamplerMap.value=N.texture,l.transmissionSamplerSize.value.set(N.width,N.height),o.transmissionMap&&(l.transmissionMap.value=o.transmissionMap,t(o.transmissionMap,l.transmissionMapTransform)),l.thickness.value=o.thickness,o.thicknessMap&&(l.thicknessMap.value=o.thicknessMap,t(o.thicknessMap,l.thicknessMapTransform)),l.attenuationDistance.value=o.attenuationDistance,l.attenuationColor.value.copy(o.attenuationColor)),o.anisotropy>0&&(l.anisotropyVector.value.set(o.anisotropy*Math.cos(o.anisotropyRotation),o.anisotropy*Math.sin(o.anisotropyRotation)),o.anisotropyMap&&(l.anisotropyMap.value=o.anisotropyMap,t(o.anisotropyMap,l.anisotropyMapTransform))),l.specularIntensity.value=o.specularIntensity,l.specularColor.value.copy(o.specularColor),o.specularColorMap&&(l.specularColorMap.value=o.specularColorMap,t(o.specularColorMap,l.specularColorMapTransform)),o.specularIntensityMap&&(l.specularIntensityMap.value=o.specularIntensityMap,t(o.specularIntensityMap,l.specularIntensityMapTransform))}function U(l,o){o.matcap&&(l.matcap.value=o.matcap)}function Y(l,o){const N=i.get(o).light;l.referencePosition.value.setFromMatrixPosition(N.matrixWorld),l.nearDistance.value=N.shadow.camera.near,l.farDistance.value=N.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:f}}function Yf(e,i,t,n){let f={},c={},u=[];const g=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function H(m,b){const v=b.program;n.uniformBlockBinding(m,v)}function T(m,b){let v=f[m.id];v===void 0&&(l(m),v=q(m),f[m.id]=v,m.addEventListener("dispose",N));const D=b.program;n.updateUBOMapping(m,D);const s=i.render.frame;c[m.id]!==s&&(p(m),c[m.id]=s)}function q(m){const b=G();m.__bindingPointIndex=b;const v=e.createBuffer(),D=m.__size,s=m.usage;return e.bindBuffer(e.UNIFORM_BUFFER,v),e.bufferData(e.UNIFORM_BUFFER,D,s),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,b,v),v}function G(){for(let m=0;m<g;m++)if(u.indexOf(m)===-1)return u.push(m),m;return Ze("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function p(m){const b=f[m.id],v=m.uniforms,D=m.__cache;e.bindBuffer(e.UNIFORM_BUFFER,b);for(let s=0,h=v.length;s<h;s++){const L=v[s];if(Array.isArray(L))for(let A=0,I=L.length;A<I;A++)x(L[A],s,A,D);else x(L,s,0,D)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function x(m,b,v,D){if(Y(m,b,v,D)===!0){const s=m.__offset,h=m.value;if(Array.isArray(h)){let L=0;for(let A=0;A<h.length;A++){const I=h[A],Q=o(I);U(I,m.__data,L),typeof I!="number"&&typeof I!="boolean"&&!I.isMatrix3&&!ArrayBuffer.isView(I)&&(L+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}}else U(h,m.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,s,m.__data)}}function U(m,b,v){typeof m=="number"||typeof m=="boolean"?b[0]=m:m.isMatrix3?(b[0]=m.elements[0],b[1]=m.elements[1],b[2]=m.elements[2],b[3]=0,b[4]=m.elements[3],b[5]=m.elements[4],b[6]=m.elements[5],b[7]=0,b[8]=m.elements[6],b[9]=m.elements[7],b[10]=m.elements[8],b[11]=0):ArrayBuffer.isView(m)?b.set(new m.constructor(m.buffer,m.byteOffset,b.length)):m.toArray(b,v)}function Y(m,b,v,D){const s=m.value,h=b+"_"+v;if(D[h]===void 0)return typeof s=="number"||typeof s=="boolean"?D[h]=s:ArrayBuffer.isView(s)?D[h]=s.slice():D[h]=s.clone(),!0;{const L=D[h];if(typeof s=="number"||typeof s=="boolean"){if(L!==s)return D[h]=s,!0}else{if(ArrayBuffer.isView(s))return!0;if(L.equals(s)===!1)return L.copy(s),!0}}return!1}function l(m){const b=m.uniforms;let v=0;const D=16;for(let h=0,L=b.length;h<L;h++){const A=Array.isArray(b[h])?b[h]:[b[h]];for(let I=0,Q=A.length;I<Q;I++){const Z=A[I],V=Array.isArray(Z.value)?Z.value:[Z.value];for(let z=0,B=V.length;z<B;z++){const $=V[z],le=o($),ge=v%D,ve=ge%le.boundary,xe=ge+ve;v+=ve,xe!==0&&D-xe<le.storage&&(v+=D-xe),Z.__data=new Float32Array(le.storage/Float32Array.BYTES_PER_ELEMENT),Z.__offset=v,v+=le.storage}}}const s=v%D;return s>0&&(v+=D-s),m.__size=v,m.__cache={},this}function o(m){const b={boundary:0,storage:0};return typeof m=="number"||typeof m=="boolean"?(b.boundary=4,b.storage=4):m.isVector2?(b.boundary=8,b.storage=8):m.isVector3||m.isColor?(b.boundary=16,b.storage=12):m.isVector4?(b.boundary=16,b.storage=16):m.isMatrix3?(b.boundary=48,b.storage=48):m.isMatrix4?(b.boundary=64,b.storage=64):m.isTexture?Ge("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(m)?(b.boundary=16,b.storage=m.byteLength):Ge("WebGLRenderer: Unsupported uniform value type.",m),b}function N(m){const b=m.target;b.removeEventListener("dispose",N);const v=u.indexOf(b.__bindingPointIndex);u.splice(v,1),e.deleteBuffer(f[b.id]),delete f[b.id],delete c[b.id]}function O(){for(const m in f)e.deleteBuffer(f[m]);u=[],f={},c={}}return{bind:H,update:T,dispose:O}}const Kf=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let At=null;function qf(){return At===null&&(At=new jr(Kf,16,16,Yt,Ot),At.name="DFG_LUT",At.minFilter=Et,At.magFilter=Et,At.wrapS=Di,At.wrapT=Di,At.generateMipmaps=!1,At.needsUpdate=!0),At}class $f{constructor(i={}){const{canvas:t=eo(),context:n=null,depth:f=!0,stencil:c=!1,alpha:u=!1,antialias:g=!1,premultipliedAlpha:H=!0,preserveDrawingBuffer:T=!1,powerPreference:q="default",failIfMajorPerformanceCaveat:G=!1,reversedDepthBuffer:p=!1,outputBufferType:x=bt}=i;this.isWebGLRenderer=!0;let U;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");U=n.getContextAttributes().alpha}else U=u;const Y=x,l=new Set([Sa,va,ga]),o=new Set([bt,Bt,pi,ni,ma,_a]),N=new Uint32Array(4),O=new Int32Array(4),m=new Fe;let b=null,v=null;const D=[],s=[];let h=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Lt,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const L=this;let A=!1,I=null,Q=null,Z=null,V=null;this._outputColorSpace=to;let z=0,B=0,$=null,le=-1,ge=null;const ve=new mt,xe=new mt;let Xe=null;const at=new Qe(0);let He=0,X=t.width,te=t.height,J=1,be=null,Ce=null;const Ae=new mt(0,0,X,te),tt=new mt(0,0,X,te);let De=!1;const We=new ha;let Oe=!1,Ne=!1;const rt=new Xt,st=new Fe,ft=new mt,dt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Je=!1;function ot(){return $===null?J:1}let S=n;function pt(r,E){return t.getContext(r,E)}try{const r={alpha:!0,depth:f,stencil:c,antialias:g,premultipliedAlpha:H,preserveDrawingBuffer:T,powerPreference:q,failIfMajorPerformanceCaveat:G};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${io}`),t.addEventListener("webglcontextlost",je,!1),t.addEventListener("webglcontextrestored",Ye,!1),t.addEventListener("webglcontextcreationerror",xt,!1),S===null){const E="webgl2";if(S=pt(E,r),S===null)throw pt(E)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(r){throw Ze("WebGLRenderer: "+r.message),r}let Be,d,a,M,P,y,j,ie,F,k,ne,Se,oe,ae,Te,Re,Pe,_,ee,W,re,de,K;function _e(){Be=new Kc(S),Be.init(),re=new Gf(S,Be),d=new zc(S,Be,i,re),a=new Of(S,Be),d.reversedDepthBuffer&&p&&a.buffers.depth.setReversed(!0),Q=S.createFramebuffer(),Z=S.createFramebuffer(),V=S.createFramebuffer(),M=new $c(S),P=new Tf,y=new Bf(S,Be,a,P,d,re,M),j=new Yc(L),ie=new ao(S),de=new Wc(S,ie),F=new qc(S,ie,M,de),k=new Jc(S,F,ie,de,M),_=new Qc(S,d,y),Te=new Xc(P),ne=new Mf(L,j,Be,d,de,Te),Se=new Xf(L,P),oe=new Rf,ae=new Uf(Be),Pe=new Vc(L,j,a,k,U,H),Re=new Ff(L,k,d),K=new Yf(S,M,d,a),ee=new kc(S,Be,M),W=new Zc(S,Be,M),M.programs=ne.programs,L.capabilities=d,L.extensions=Be,L.properties=P,L.renderLists=oe,L.shadowMap=Re,L.state=a,L.info=M}_e(),Y!==bt&&(h=new el(Y,t.width,t.height,g,f,c));const he=new kf(L,S);this.xr=he,this.getContext=function(){return S},this.getContextAttributes=function(){return S.getContextAttributes()},this.forceContextLoss=function(){const r=Be.get("WEBGL_lose_context");r&&r.loseContext()},this.forceContextRestore=function(){const r=Be.get("WEBGL_lose_context");r&&r.restoreContext()},this.getPixelRatio=function(){return J},this.setPixelRatio=function(r){r!==void 0&&(J=r,this.setSize(X,te,!1))},this.getSize=function(r){return r.set(X,te)},this.setSize=function(r,E,w=!0){if(he.isPresenting){Ge("WebGLRenderer: Can't change size while VR device is presenting.");return}X=r,te=E,t.width=Math.floor(r*J),t.height=Math.floor(E*J),w===!0&&(t.style.width=r+"px",t.style.height=E+"px"),h!==null&&h.setSize(t.width,t.height),this.setViewport(0,0,r,E)},this.getDrawingBufferSize=function(r){return r.set(X*J,te*J).floor()},this.setDrawingBufferSize=function(r,E,w){X=r,te=E,J=w,t.width=Math.floor(r*w),t.height=Math.floor(E*w),this.setViewport(0,0,r,E)},this.setEffects=function(r){if(Y===bt){Ze("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(r){for(let E=0;E<r.length;E++)if(r[E].isOutputPass===!0){Ge("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}h.setEffects(r||[])},this.getCurrentViewport=function(r){return r.copy(ve)},this.getViewport=function(r){return r.copy(Ae)},this.setViewport=function(r,E,w,R){r.isVector4?Ae.set(r.x,r.y,r.z,r.w):Ae.set(r,E,w,R),a.viewport(ve.copy(Ae).multiplyScalar(J).round())},this.getScissor=function(r){return r.copy(tt)},this.setScissor=function(r,E,w,R){r.isVector4?tt.set(r.x,r.y,r.z,r.w):tt.set(r,E,w,R),a.scissor(xe.copy(tt).multiplyScalar(J).round())},this.getScissorTest=function(){return De},this.setScissorTest=function(r){a.setScissorTest(De=r)},this.setOpaqueSort=function(r){be=r},this.setTransparentSort=function(r){Ce=r},this.getClearColor=function(r){return r.copy(Pe.getClearColor())},this.setClearColor=function(){Pe.setClearColor(...arguments)},this.getClearAlpha=function(){return Pe.getClearAlpha()},this.setClearAlpha=function(){Pe.setClearAlpha(...arguments)},this.clear=function(r=!0,E=!0,w=!0){let R=0;if(r){let C=!1;if($!==null){const fe=$.texture.format;C=l.has(fe)}if(C){const fe=$.texture.type,pe=o.has(fe),ce=Pe.getClearColor(),me=Pe.getClearAlpha(),Ee=ce.r,Le=ce.g,Ue=ce.b;pe?(N[0]=Ee,N[1]=Le,N[2]=Ue,N[3]=me,S.clearBufferuiv(S.COLOR,0,N)):(O[0]=Ee,O[1]=Le,O[2]=Ue,O[3]=me,S.clearBufferiv(S.COLOR,0,O))}else R|=S.COLOR_BUFFER_BIT}E&&(R|=S.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),w&&(R|=S.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),R!==0&&S.clear(R)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(r){r.setRenderer(this),I=r},this.dispose=function(){t.removeEventListener("webglcontextlost",je,!1),t.removeEventListener("webglcontextrestored",Ye,!1),t.removeEventListener("webglcontextcreationerror",xt,!1),Pe.dispose(),oe.dispose(),ae.dispose(),P.dispose(),j.dispose(),k.dispose(),de.dispose(),K.dispose(),ne.dispose(),he.dispose(),he.removeEventListener("sessionstart",Gi),he.removeEventListener("sessionend",Hi),yt.stop()};function je(r){r.preventDefault(),Nn("WebGLRenderer: Context Lost."),A=!0}function Ye(){Nn("WebGLRenderer: Context Restored."),A=!1;const r=M.autoReset,E=Re.enabled,w=Re.autoUpdate,R=Re.needsUpdate,C=Re.type;_e(),M.autoReset=r,Re.enabled=E,Re.autoUpdate=w,Re.needsUpdate=R,Re.type=C}function xt(r){Ze("WebGLRenderer: A WebGL context could not be created. Reason: ",r.statusMessage)}function Mt(r){const E=r.target;E.removeEventListener("dispose",Mt),La(E)}function La(r){wa(r),P.remove(r)}function wa(r){const E=P.get(r).programs;E!==void 0&&(E.forEach(function(w){ne.releaseProgram(w)}),r.isShaderMaterial&&ne.releaseShaderCache(r))}this.renderBufferDirect=function(r,E,w,R,C,fe){E===null&&(E=dt);const pe=C.isMesh&&C.matrixWorld.determinantAffine()<0,ce=Ia(r,E,w,R,C);a.setMaterial(R,pe);let me=w.index,Ee=1;if(R.wireframe===!0){if(me=F.getWireframeAttribute(w),me===void 0)return;Ee=2}const Le=w.drawRange,Ue=w.attributes.position;let Me=Le.start*Ee,Ve=(Le.start+Le.count)*Ee;fe!==null&&(Me=Math.max(Me,fe.start*Ee),Ve=Math.min(Ve,(fe.start+fe.count)*Ee)),me!==null?(Me=Math.max(Me,0),Ve=Math.min(Ve,me.count)):Ue!=null&&(Me=Math.max(Me,0),Ve=Math.min(Ve,Ue.count));const it=Ve-Me;if(it<0||it===1/0)return;de.setup(C,R,ce,w,me);let et,ke=ee;if(me!==null&&(et=ie.get(me),ke=W,ke.setIndex(et)),C.isMesh)R.wireframe===!0?(a.setLineWidth(R.wireframeLinewidth*ot()),ke.setMode(S.LINES)):ke.setMode(S.TRIANGLES);else if(C.isLine){let ut=R.linewidth;ut===void 0&&(ut=1),a.setLineWidth(ut*ot()),C.isLineSegments?ke.setMode(S.LINES):C.isLineLoop?ke.setMode(S.LINE_LOOP):ke.setMode(S.LINE_STRIP)}else C.isPoints?ke.setMode(S.POINTS):C.isSprite&&ke.setMode(S.TRIANGLES);if(C.isBatchedMesh)if(Be.get("WEBGL_multi_draw"))ke.renderMultiDraw(C._multiDrawStarts,C._multiDrawCounts,C._multiDrawCount);else{const ut=C._multiDrawStarts,ue=C._multiDrawCounts,gt=C._multiDrawCount,ye=me?ie.get(me).bytesPerElement:1,vt=P.get(R).currentProgram.getUniforms();for(let Tt=0;Tt<gt;Tt++)vt.setValue(S,"_gl_DrawID",Tt),ke.render(ut[Tt]/ye,ue[Tt])}else if(C.isInstancedMesh)ke.renderInstances(Me,it,C.count);else if(w.isInstancedBufferGeometry){const ut=w._maxInstanceCount!==void 0?w._maxInstanceCount:1/0,ue=Math.min(w.instanceCount,ut);ke.renderInstances(Me,it,ue)}else ke.render(Me,it)};function Bi(r,E,w){r.transparent===!0&&r.side===Ct&&r.forceSinglePass===!1?(r.side=St,r.needsUpdate=!0,ri(r,E,w),r.side=ti,r.needsUpdate=!0,ri(r,E,w),r.side=Ct):ri(r,E,w)}this.compile=function(r,E,w=null){w===null&&(w=r),v=ae.get(w),v.init(E),s.push(v),w.traverseVisible(function(C){C.isLight&&C.layers.test(E.layers)&&(v.pushLight(C),C.castShadow&&v.pushShadow(C))}),r!==w&&r.traverseVisible(function(C){C.isLight&&C.layers.test(E.layers)&&(v.pushLight(C),C.castShadow&&v.pushShadow(C))}),v.setupLights();const R=new Set;return r.traverse(function(C){if(!(C.isMesh||C.isPoints||C.isLine||C.isSprite))return;const fe=C.material;if(fe)if(Array.isArray(fe))for(let pe=0;pe<fe.length;pe++){const ce=fe[pe];Bi(ce,w,C),R.add(ce)}else Bi(fe,w,C),R.add(fe)}),v=s.pop(),R},this.compileAsync=function(r,E,w=null){const R=this.compile(r,E,w);return new Promise(C=>{function fe(){if(R.forEach(function(pe){P.get(pe).currentProgram.isReady()&&R.delete(pe)}),R.size===0){C(r);return}setTimeout(fe,10)}Be.get("KHR_parallel_shader_compile")!==null?fe():setTimeout(fe,10)})};let mi=null;function Ua(r){mi&&mi(r)}function Gi(){yt.stop()}function Hi(){yt.start()}const yt=new xa;yt.setAnimationLoop(Ua),typeof self<"u"&&yt.setContext(self),this.setAnimationLoop=function(r){mi=r,he.setAnimationLoop(r),r===null?yt.stop():yt.start()},he.addEventListener("sessionstart",Gi),he.addEventListener("sessionend",Hi),this.render=function(r,E){if(E!==void 0&&E.isCamera!==!0){Ze("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(A===!0)return;I!==null&&I.renderStart(r,E);const w=he.enabled===!0&&he.isPresenting===!0,R=h!==null&&($===null||w)&&h.begin(L,$);if(r.matrixWorldAutoUpdate===!0&&r.updateMatrixWorld(),E.parent===null&&E.matrixWorldAutoUpdate===!0&&E.updateMatrixWorld(),he.enabled===!0&&he.isPresenting===!0&&(h===null||h.isCompositing()===!1)&&(he.cameraAutoUpdate===!0&&he.updateCamera(E),E=he.getCamera()),r.isScene===!0&&r.onBeforeRender(L,r,E,$),v=ae.get(r,s.length),v.init(E),v.state.textureUnits=y.getTextureUnits(),s.push(v),rt.multiplyMatrices(E.projectionMatrix,E.matrixWorldInverse),We.setFromProjectionMatrix(rt,yn,E.reversedDepth),Ne=this.localClippingEnabled,Oe=Te.init(this.clippingPlanes,Ne),b=oe.get(r,D.length),b.init(),D.push(b),he.enabled===!0&&he.isPresenting===!0){const pe=L.xr.getDepthSensingMesh();pe!==null&&_i(pe,E,-1/0,L.sortObjects)}_i(r,E,0,L.sortObjects),b.finish(),L.sortObjects===!0&&b.sort(be,Ce,E.reversedDepth),Je=he.enabled===!1||he.isPresenting===!1||he.hasDepthSensing()===!1,Je&&Pe.addToRenderList(b,r),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),Oe===!0&&Te.beginShadows();const C=v.state.shadowsArray;if(Re.render(C,r,E),Oe===!0&&Te.endShadows(),(R&&h.hasRenderPass())===!1){const pe=b.opaque,ce=b.transmissive;if(v.setupLights(),E.isArrayCamera){const me=E.cameras;if(ce.length>0)for(let Ee=0,Le=me.length;Ee<Le;Ee++){const Ue=me[Ee];Wi(pe,ce,r,Ue)}Je&&Pe.render(r);for(let Ee=0,Le=me.length;Ee<Le;Ee++){const Ue=me[Ee];Vi(b,r,Ue,Ue.viewport)}}else ce.length>0&&Wi(pe,ce,r,E),Je&&Pe.render(r),Vi(b,r,E)}$!==null&&B===0&&(y.updateMultisampleRenderTarget($),y.updateRenderTargetMipmap($)),R&&h.end(L),r.isScene===!0&&r.onAfterRender(L,r,E),de.resetDefaultState(),le=-1,ge=null,s.pop(),s.length>0?(v=s[s.length-1],y.setTextureUnits(v.state.textureUnits),Oe===!0&&Te.setGlobalState(L.clippingPlanes,v.state.camera)):v=null,D.pop(),D.length>0?b=D[D.length-1]:b=null,I!==null&&I.renderEnd()};function _i(r,E,w,R){if(r.visible===!1)return;if(r.layers.test(E.layers)){if(r.isGroup)w=r.renderOrder;else if(r.isLOD)r.autoUpdate===!0&&r.update(E);else if(r.isLightProbeGrid)v.pushLightProbeGrid(r);else if(r.isLight)v.pushLight(r),r.castShadow&&v.pushShadow(r);else if(r.isSprite){if(!r.frustumCulled||We.intersectsSprite(r)){R&&ft.setFromMatrixPosition(r.matrixWorld).applyMatrix4(rt);const pe=k.update(r),ce=r.material;ce.visible&&b.push(r,pe,ce,w,ft.z,null)}}else if((r.isMesh||r.isLine||r.isPoints)&&(!r.frustumCulled||We.intersectsObject(r))){const pe=k.update(r),ce=r.material;if(R&&(r.boundingSphere!==void 0?(r.boundingSphere===null&&r.computeBoundingSphere(),ft.copy(r.boundingSphere.center)):(pe.boundingSphere===null&&pe.computeBoundingSphere(),ft.copy(pe.boundingSphere.center)),ft.applyMatrix4(r.matrixWorld).applyMatrix4(rt)),Array.isArray(ce)){const me=pe.groups;for(let Ee=0,Le=me.length;Ee<Le;Ee++){const Ue=me[Ee],Me=ce[Ue.materialIndex];Me&&Me.visible&&b.push(r,pe,Me,w,ft.z,Ue)}}else ce.visible&&b.push(r,pe,ce,w,ft.z,null)}}const fe=r.children;for(let pe=0,ce=fe.length;pe<ce;pe++)_i(fe[pe],E,w,R)}function Vi(r,E,w,R){const{opaque:C,transmissive:fe,transparent:pe}=r;v.setupLightsView(w),Oe===!0&&Te.setGlobalState(L.clippingPlanes,w),R&&a.viewport(ve.copy(R)),C.length>0&&ai(C,E,w),fe.length>0&&ai(fe,E,w),pe.length>0&&ai(pe,E,w),a.buffers.depth.setTest(!0),a.buffers.depth.setMask(!0),a.buffers.color.setMask(!0),a.setPolygonOffset(!1)}function Wi(r,E,w,R){if((w.isScene===!0?w.overrideMaterial:null)!==null)return;if(v.state.transmissionRenderTarget[R.id]===void 0){const Me=Be.has("EXT_color_buffer_half_float")||Be.has("EXT_color_buffer_float");v.state.transmissionRenderTarget[R.id]=new Pt(1,1,{generateMipmaps:!0,type:Me?Ot:bt,minFilter:Wt,samples:Math.max(4,d.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:$e.workingColorSpace})}const fe=v.state.transmissionRenderTarget[R.id],pe=R.viewport||ve;fe.setSize(pe.z*L.transmissionResolutionScale,pe.w*L.transmissionResolutionScale);const ce=L.getRenderTarget(),me=L.getActiveCubeFace(),Ee=L.getActiveMipmapLevel();L.setRenderTarget(fe),L.getClearColor(at),He=L.getClearAlpha(),He<1&&L.setClearColor(16777215,.5),L.clear(),Je&&Pe.render(w);const Le=L.toneMapping;L.toneMapping=Lt;const Ue=R.viewport;if(R.viewport!==void 0&&(R.viewport=void 0),v.setupLightsView(R),Oe===!0&&Te.setGlobalState(L.clippingPlanes,R),ai(r,w,R),y.updateMultisampleRenderTarget(fe),y.updateRenderTargetMipmap(fe),Be.has("WEBGL_multisampled_render_to_texture")===!1){let Me=!1;for(let Ve=0,it=E.length;Ve<it;Ve++){const et=E[Ve],{object:ke,geometry:ut,material:ue,group:gt}=et;if(ue.side===Ct&&ke.layers.test(R.layers)){const ye=ue.side;ue.side=St,ue.needsUpdate=!0,ki(ke,w,R,ut,ue,gt),ue.side=ye,ue.needsUpdate=!0,Me=!0}}Me===!0&&(y.updateMultisampleRenderTarget(fe),y.updateRenderTargetMipmap(fe))}L.setRenderTarget(ce,me,Ee),L.setClearColor(at,He),Ue!==void 0&&(R.viewport=Ue),L.toneMapping=Le}function ai(r,E,w){const R=E.isScene===!0?E.overrideMaterial:null;for(let C=0,fe=r.length;C<fe;C++){const pe=r[C],{object:ce,geometry:me,group:Ee}=pe;let Le=pe.material;Le.allowOverride===!0&&R!==null&&(Le=R),ce.layers.test(w.layers)&&ki(ce,E,w,me,Le,Ee)}}function ki(r,E,w,R,C,fe){r.onBeforeRender(L,E,w,R,C,fe),r.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,r.matrixWorld),r.normalMatrix.getNormalMatrix(r.modelViewMatrix),C.onBeforeRender(L,E,w,R,r,fe),C.transparent===!0&&C.side===Ct&&C.forceSinglePass===!1?(C.side=St,C.needsUpdate=!0,L.renderBufferDirect(w,E,R,C,r,fe),C.side=ti,C.needsUpdate=!0,L.renderBufferDirect(w,E,R,C,r,fe),C.side=Ct):L.renderBufferDirect(w,E,R,C,r,fe),r.onAfterRender(L,E,w,R,C,fe)}function ri(r,E,w){E.isScene!==!0&&(E=dt);const R=P.get(r),C=v.state.lights,fe=v.state.shadowsArray,pe=C.state.version,ce=ne.getParameters(r,C.state,fe,E,w,v.state.lightProbeGridArray),me=ne.getProgramCacheKey(ce);let Ee=R.programs;R.environment=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?E.environment:null,R.fog=E.fog;const Le=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap;R.envMap=j.get(r.envMap||R.environment,Le),R.envMapRotation=R.environment!==null&&r.envMap===null?E.environmentRotation:r.envMapRotation,Ee===void 0&&(r.addEventListener("dispose",Mt),Ee=new Map,R.programs=Ee);let Ue=Ee.get(me);if(Ue!==void 0){if(R.currentProgram===Ue&&R.lightsStateVersion===pe)return Xi(r,ce),Ue}else ce.uniforms=ne.getUniforms(r),I!==null&&r.isNodeMaterial&&I.build(r,w,ce),r.onBeforeCompile(ce,L),Ue=ne.acquireProgram(ce,me),Ee.set(me,Ue),R.uniforms=ce.uniforms;const Me=R.uniforms;return(!r.isShaderMaterial&&!r.isRawShaderMaterial||r.clipping===!0)&&(Me.clippingPlanes=Te.uniform),Xi(r,ce),R.needsLights=ya(r),R.lightsStateVersion=pe,R.needsLights&&(Me.ambientLightColor.value=C.state.ambient,Me.lightProbe.value=C.state.probe,Me.directionalLights.value=C.state.directional,Me.directionalLightShadows.value=C.state.directionalShadow,Me.spotLights.value=C.state.spot,Me.spotLightShadows.value=C.state.spotShadow,Me.rectAreaLights.value=C.state.rectArea,Me.ltc_1.value=C.state.rectAreaLTC1,Me.ltc_2.value=C.state.rectAreaLTC2,Me.pointLights.value=C.state.point,Me.pointLightShadows.value=C.state.pointShadow,Me.hemisphereLights.value=C.state.hemi,Me.directionalShadowMatrix.value=C.state.directionalShadowMatrix,Me.spotLightMatrix.value=C.state.spotLightMatrix,Me.spotLightMap.value=C.state.spotLightMap,Me.pointShadowMatrix.value=C.state.pointShadowMatrix),R.lightProbeGrid=v.state.lightProbeGridArray.length>0,R.currentProgram=Ue,R.uniformsList=null,Ue}function zi(r){if(r.uniformsList===null){const E=r.currentProgram.getUniforms();r.uniformsList=di.seqWithValue(E.seq,r.uniforms)}return r.uniformsList}function Xi(r,E){const w=P.get(r);w.outputColorSpace=E.outputColorSpace,w.batching=E.batching,w.batchingColor=E.batchingColor,w.instancing=E.instancing,w.instancingColor=E.instancingColor,w.instancingMorph=E.instancingMorph,w.skinning=E.skinning,w.morphTargets=E.morphTargets,w.morphNormals=E.morphNormals,w.morphColors=E.morphColors,w.morphTargetsCount=E.morphTargetsCount,w.numClippingPlanes=E.numClippingPlanes,w.numIntersection=E.numClipIntersection,w.vertexAlphas=E.vertexAlphas,w.vertexTangents=E.vertexTangents,w.toneMapping=E.toneMapping}function Da(r,E){if(r.length===0)return null;if(r.length===1)return r[0].texture!==null?r[0]:null;m.setFromMatrixPosition(E.matrixWorld);for(let w=0,R=r.length;w<R;w++){const C=r[w];if(C.texture!==null&&C.boundingBox.containsPoint(m))return C}return null}function Ia(r,E,w,R,C){E.isScene!==!0&&(E=dt),y.resetTextureUnits();const fe=E.fog,pe=R.isMeshStandardMaterial||R.isMeshLambertMaterial||R.isMeshPhongMaterial?E.environment:null,ce=$===null?L.outputColorSpace:$.isXRRenderTarget===!0?$.texture.colorSpace:$e.workingColorSpace,me=R.isMeshStandardMaterial||R.isMeshLambertMaterial&&!R.envMap||R.isMeshPhongMaterial&&!R.envMap,Ee=j.get(R.envMap||pe,me),Le=R.vertexColors===!0&&!!w.attributes.color&&w.attributes.color.itemSize===4,Ue=!!w.attributes.tangent&&(!!R.normalMap||R.anisotropy>0),Me=!!w.morphAttributes.position,Ve=!!w.morphAttributes.normal,it=!!w.morphAttributes.color;let et=Lt;R.toneMapped&&($===null||$.isXRRenderTarget===!0)&&(et=L.toneMapping);const ke=w.morphAttributes.position||w.morphAttributes.normal||w.morphAttributes.color,ut=ke!==void 0?ke.length:0,ue=P.get(R),gt=v.state.lights;if(Oe===!0&&(Ne===!0||r!==ge)){const Ke=r===ge&&R.id===le;Te.setState(R,r,Ke)}let ye=!1;R.version===ue.__version?(ue.needsLights&&ue.lightsStateVersion!==gt.state.version||ue.outputColorSpace!==ce||C.isBatchedMesh&&ue.batching===!1||!C.isBatchedMesh&&ue.batching===!0||C.isBatchedMesh&&ue.batchingColor===!0&&C.colorTexture===null||C.isBatchedMesh&&ue.batchingColor===!1&&C.colorTexture!==null||C.isInstancedMesh&&ue.instancing===!1||!C.isInstancedMesh&&ue.instancing===!0||C.isSkinnedMesh&&ue.skinning===!1||!C.isSkinnedMesh&&ue.skinning===!0||C.isInstancedMesh&&ue.instancingColor===!0&&C.instanceColor===null||C.isInstancedMesh&&ue.instancingColor===!1&&C.instanceColor!==null||C.isInstancedMesh&&ue.instancingMorph===!0&&C.morphTexture===null||C.isInstancedMesh&&ue.instancingMorph===!1&&C.morphTexture!==null||ue.envMap!==Ee||R.fog===!0&&ue.fog!==fe||ue.numClippingPlanes!==void 0&&(ue.numClippingPlanes!==Te.numPlanes||ue.numIntersection!==Te.numIntersection)||ue.vertexAlphas!==Le||ue.vertexTangents!==Ue||ue.morphTargets!==Me||ue.morphNormals!==Ve||ue.morphColors!==it||ue.toneMapping!==et||ue.morphTargetsCount!==ut||!!ue.lightProbeGrid!=v.state.lightProbeGridArray.length>0)&&(ye=!0):(ye=!0,ue.__version=R.version);let vt=ue.currentProgram;ye===!0&&(vt=ri(R,E,C),I&&R.isNodeMaterial&&I.onUpdateProgram(R,vt,ue));let Tt=!1,wt=!1,Gt=!1;const ze=vt.getUniforms(),nt=ue.uniforms;if(a.useProgram(vt.program)&&(Tt=!0,wt=!0,Gt=!0),R.id!==le&&(le=R.id,wt=!0),ue.needsLights){const Ke=Da(v.state.lightProbeGridArray,C);ue.lightProbeGrid!==Ke&&(ue.lightProbeGrid=Ke,wt=!0)}if(Tt||ge!==r){a.buffers.depth.getReversed()&&r.reversedDepth!==!0&&(r._reversedDepth=!0,r.updateProjectionMatrix()),ze.setValue(S,"projectionMatrix",r.projectionMatrix),ze.setValue(S,"viewMatrix",r.matrixWorldInverse);const Dt=ze.map.cameraPosition;Dt!==void 0&&Dt.setValue(S,st.setFromMatrixPosition(r.matrixWorld)),d.logarithmicDepthBuffer&&ze.setValue(S,"logDepthBufFC",2/(Math.log(r.far+1)/Math.LN2)),(R.isMeshPhongMaterial||R.isMeshToonMaterial||R.isMeshLambertMaterial||R.isMeshBasicMaterial||R.isMeshStandardMaterial||R.isShaderMaterial)&&ze.setValue(S,"isOrthographic",r.isOrthographicCamera===!0),ge!==r&&(ge=r,wt=!0,Gt=!0)}if(ue.needsLights&&(gt.state.directionalShadowMap.length>0&&ze.setValue(S,"directionalShadowMap",gt.state.directionalShadowMap,y),gt.state.spotShadowMap.length>0&&ze.setValue(S,"spotShadowMap",gt.state.spotShadowMap,y),gt.state.pointShadowMap.length>0&&ze.setValue(S,"pointShadowMap",gt.state.pointShadowMap,y)),C.isSkinnedMesh){ze.setOptional(S,C,"bindMatrix"),ze.setOptional(S,C,"bindMatrixInverse");const Ke=C.skeleton;Ke&&(Ke.boneTexture===null&&Ke.computeBoneTexture(),ze.setValue(S,"boneTexture",Ke.boneTexture,y))}C.isBatchedMesh&&(ze.setOptional(S,C,"batchingTexture"),ze.setValue(S,"batchingTexture",C._matricesTexture,y),ze.setOptional(S,C,"batchingIdTexture"),ze.setValue(S,"batchingIdTexture",C._indirectTexture,y),ze.setOptional(S,C,"batchingColorTexture"),C._colorsTexture!==null&&ze.setValue(S,"batchingColorTexture",C._colorsTexture,y));const Ut=w.morphAttributes;if((Ut.position!==void 0||Ut.normal!==void 0||Ut.color!==void 0)&&_.update(C,w,vt),(wt||ue.receiveShadow!==C.receiveShadow)&&(ue.receiveShadow=C.receiveShadow,ze.setValue(S,"receiveShadow",C.receiveShadow)),(R.isMeshStandardMaterial||R.isMeshLambertMaterial||R.isMeshPhongMaterial)&&R.envMap===null&&E.environment!==null&&(nt.envMapIntensity.value=E.environmentIntensity),nt.dfgLUT!==void 0&&(nt.dfgLUT.value=qf()),wt){if(ze.setValue(S,"toneMappingExposure",L.toneMappingExposure),ue.needsLights&&Na(nt,Gt),fe&&R.fog===!0&&Se.refreshFogUniforms(nt,fe),Se.refreshMaterialUniforms(nt,R,J,te,v.state.transmissionRenderTarget[r.id]),ue.needsLights&&ue.lightProbeGrid){const Ke=ue.lightProbeGrid;nt.probesSH.value=Ke.texture,nt.probesMin.value.copy(Ke.boundingBox.min),nt.probesMax.value.copy(Ke.boundingBox.max),nt.probesResolution.value.copy(Ke.resolution)}di.upload(S,zi(ue),nt,y)}if(R.isShaderMaterial&&R.uniformsNeedUpdate===!0&&(di.upload(S,zi(ue),nt,y),R.uniformsNeedUpdate=!1),R.isSpriteMaterial&&ze.setValue(S,"center",C.center),ze.setValue(S,"modelViewMatrix",C.modelViewMatrix),ze.setValue(S,"normalMatrix",C.normalMatrix),ze.setValue(S,"modelMatrix",C.matrixWorld),R.uniformsGroups!==void 0){const Ke=R.uniformsGroups;for(let Dt=0,Ht=Ke.length;Dt<Ht;Dt++){const Yi=Ke[Dt];K.update(Yi,vt),K.bind(Yi,vt)}}return vt}function Na(r,E){r.ambientLightColor.needsUpdate=E,r.lightProbe.needsUpdate=E,r.directionalLights.needsUpdate=E,r.directionalLightShadows.needsUpdate=E,r.pointLights.needsUpdate=E,r.pointLightShadows.needsUpdate=E,r.spotLights.needsUpdate=E,r.spotLightShadows.needsUpdate=E,r.rectAreaLights.needsUpdate=E,r.hemisphereLights.needsUpdate=E}function ya(r){return r.isMeshLambertMaterial||r.isMeshToonMaterial||r.isMeshPhongMaterial||r.isMeshStandardMaterial||r.isShadowMaterial||r.isShaderMaterial&&r.lights===!0}this.getActiveCubeFace=function(){return z},this.getActiveMipmapLevel=function(){return B},this.getRenderTarget=function(){return $},this.setRenderTargetTextures=function(r,E,w){const R=P.get(r);R.__autoAllocateDepthBuffer=r.resolveDepthBuffer===!1,R.__autoAllocateDepthBuffer===!1&&(R.__useRenderToTexture=!1),P.get(r.texture).__webglTexture=E,P.get(r.depthTexture).__webglTexture=R.__autoAllocateDepthBuffer?void 0:w,R.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(r,E){const w=P.get(r);w.__webglFramebuffer=E,w.__useDefaultFramebuffer=E===void 0},this.setRenderTarget=function(r,E=0,w=0){$=r,z=E,B=w;let R=null,C=!1,fe=!1;if(r){const ce=P.get(r);if(ce.__useDefaultFramebuffer!==void 0){a.bindFramebuffer(S.FRAMEBUFFER,ce.__webglFramebuffer),ve.copy(r.viewport),xe.copy(r.scissor),Xe=r.scissorTest,a.viewport(ve),a.scissor(xe),a.setScissorTest(Xe),le=-1;return}else if(ce.__webglFramebuffer===void 0)y.setupRenderTarget(r);else if(ce.__hasExternalTextures)y.rebindTextures(r,P.get(r.texture).__webglTexture,P.get(r.depthTexture).__webglTexture);else if(r.depthBuffer){const Le=r.depthTexture;if(ce.__boundDepthTexture!==Le){if(Le!==null&&P.has(Le)&&(r.width!==Le.image.width||r.height!==Le.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");y.setupDepthRenderbuffer(r)}}const me=r.texture;(me.isData3DTexture||me.isDataArrayTexture||me.isCompressedArrayTexture)&&(fe=!0);const Ee=P.get(r).__webglFramebuffer;r.isWebGLCubeRenderTarget?(Array.isArray(Ee[E])?R=Ee[E][w]:R=Ee[E],C=!0):r.samples>0&&y.useMultisampledRTT(r)===!1?R=P.get(r).__webglMultisampledFramebuffer:Array.isArray(Ee)?R=Ee[w]:R=Ee,ve.copy(r.viewport),xe.copy(r.scissor),Xe=r.scissorTest}else ve.copy(Ae).multiplyScalar(J).floor(),xe.copy(tt).multiplyScalar(J).floor(),Xe=De;if(w!==0&&(R=Q),a.bindFramebuffer(S.FRAMEBUFFER,R)&&a.drawBuffers(r,R),a.viewport(ve),a.scissor(xe),a.setScissorTest(Xe),C){const ce=P.get(r.texture);S.framebufferTexture2D(S.FRAMEBUFFER,S.COLOR_ATTACHMENT0,S.TEXTURE_CUBE_MAP_POSITIVE_X+E,ce.__webglTexture,w)}else if(fe){const ce=E;for(let me=0;me<r.textures.length;me++){const Ee=P.get(r.textures[me]);S.framebufferTextureLayer(S.FRAMEBUFFER,S.COLOR_ATTACHMENT0+me,Ee.__webglTexture,w,ce)}}else if(r!==null&&w!==0){const ce=P.get(r.texture);S.framebufferTexture2D(S.FRAMEBUFFER,S.COLOR_ATTACHMENT0,S.TEXTURE_2D,ce.__webglTexture,w)}le=-1},this.readRenderTargetPixels=function(r,E,w,R,C,fe,pe,ce=0){if(!(r&&r.isWebGLRenderTarget)){Ze("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let me=P.get(r).__webglFramebuffer;if(r.isWebGLCubeRenderTarget&&pe!==void 0&&(me=me[pe]),me){a.bindFramebuffer(S.FRAMEBUFFER,me);try{const Ee=r.textures[ce],Le=Ee.format,Ue=Ee.type;if(r.textures.length>1&&S.readBuffer(S.COLOR_ATTACHMENT0+ce),!d.textureFormatReadable(Le)){Ze("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!d.textureTypeReadable(Ue)){Ze("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}E>=0&&E<=r.width-R&&w>=0&&w<=r.height-C&&S.readPixels(E,w,R,C,re.convert(Le),re.convert(Ue),fe)}finally{const Ee=$!==null?P.get($).__webglFramebuffer:null;a.bindFramebuffer(S.FRAMEBUFFER,Ee)}}},this.readRenderTargetPixelsAsync=async function(r,E,w,R,C,fe,pe,ce=0){if(!(r&&r.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let me=P.get(r).__webglFramebuffer;if(r.isWebGLCubeRenderTarget&&pe!==void 0&&(me=me[pe]),me)if(E>=0&&E<=r.width-R&&w>=0&&w<=r.height-C){a.bindFramebuffer(S.FRAMEBUFFER,me);const Ee=r.textures[ce],Le=Ee.format,Ue=Ee.type;if(r.textures.length>1&&S.readBuffer(S.COLOR_ATTACHMENT0+ce),!d.textureFormatReadable(Le))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!d.textureTypeReadable(Ue))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Me=S.createBuffer();S.bindBuffer(S.PIXEL_PACK_BUFFER,Me),S.bufferData(S.PIXEL_PACK_BUFFER,fe.byteLength,S.STREAM_READ),S.readPixels(E,w,R,C,re.convert(Le),re.convert(Ue),0);const Ve=$!==null?P.get($).__webglFramebuffer:null;a.bindFramebuffer(S.FRAMEBUFFER,Ve);const it=S.fenceSync(S.SYNC_GPU_COMMANDS_COMPLETE,0);return S.flush(),await no(S,it,4),S.bindBuffer(S.PIXEL_PACK_BUFFER,Me),S.getBufferSubData(S.PIXEL_PACK_BUFFER,0,fe),S.deleteBuffer(Me),S.deleteSync(it),fe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(r,E=null,w=0){const R=Math.pow(2,-w),C=Math.floor(r.image.width*R),fe=Math.floor(r.image.height*R),pe=E!==null?E.x:0,ce=E!==null?E.y:0;y.setTexture2D(r,0),S.copyTexSubImage2D(S.TEXTURE_2D,w,0,0,pe,ce,C,fe),a.unbindTexture()},this.copyTextureToTexture=function(r,E,w=null,R=null,C=0,fe=0){let pe,ce,me,Ee,Le,Ue,Me,Ve,it;const et=r.isCompressedTexture?r.mipmaps[fe]:r.image;if(w!==null)pe=w.max.x-w.min.x,ce=w.max.y-w.min.y,me=w.isBox3?w.max.z-w.min.z:1,Ee=w.min.x,Le=w.min.y,Ue=w.isBox3?w.min.z:0;else{const nt=Math.pow(2,-C);pe=Math.floor(et.width*nt),ce=Math.floor(et.height*nt),r.isDataArrayTexture?me=et.depth:r.isData3DTexture?me=Math.floor(et.depth*nt):me=1,Ee=0,Le=0,Ue=0}R!==null?(Me=R.x,Ve=R.y,it=R.z):(Me=0,Ve=0,it=0);const ke=re.convert(E.format),ut=re.convert(E.type);let ue;E.isData3DTexture?(y.setTexture3D(E,0),ue=S.TEXTURE_3D):E.isDataArrayTexture||E.isCompressedArrayTexture?(y.setTexture2DArray(E,0),ue=S.TEXTURE_2D_ARRAY):(y.setTexture2D(E,0),ue=S.TEXTURE_2D),a.activeTexture(S.TEXTURE0),a.pixelStorei(S.UNPACK_FLIP_Y_WEBGL,E.flipY),a.pixelStorei(S.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),a.pixelStorei(S.UNPACK_ALIGNMENT,E.unpackAlignment);const gt=a.getParameter(S.UNPACK_ROW_LENGTH),ye=a.getParameter(S.UNPACK_IMAGE_HEIGHT),vt=a.getParameter(S.UNPACK_SKIP_PIXELS),Tt=a.getParameter(S.UNPACK_SKIP_ROWS),wt=a.getParameter(S.UNPACK_SKIP_IMAGES);a.pixelStorei(S.UNPACK_ROW_LENGTH,et.width),a.pixelStorei(S.UNPACK_IMAGE_HEIGHT,et.height),a.pixelStorei(S.UNPACK_SKIP_PIXELS,Ee),a.pixelStorei(S.UNPACK_SKIP_ROWS,Le),a.pixelStorei(S.UNPACK_SKIP_IMAGES,Ue);const Gt=r.isDataArrayTexture||r.isData3DTexture,ze=E.isDataArrayTexture||E.isData3DTexture;if(r.isDepthTexture){const nt=P.get(r),Ut=P.get(E),Ke=P.get(nt.__renderTarget),Dt=P.get(Ut.__renderTarget);a.bindFramebuffer(S.READ_FRAMEBUFFER,Ke.__webglFramebuffer),a.bindFramebuffer(S.DRAW_FRAMEBUFFER,Dt.__webglFramebuffer);for(let Ht=0;Ht<me;Ht++)Gt&&(S.framebufferTextureLayer(S.READ_FRAMEBUFFER,S.COLOR_ATTACHMENT0,P.get(r).__webglTexture,C,Ue+Ht),S.framebufferTextureLayer(S.DRAW_FRAMEBUFFER,S.COLOR_ATTACHMENT0,P.get(E).__webglTexture,fe,it+Ht)),S.blitFramebuffer(Ee,Le,pe,ce,Me,Ve,pe,ce,S.DEPTH_BUFFER_BIT,S.NEAREST);a.bindFramebuffer(S.READ_FRAMEBUFFER,null),a.bindFramebuffer(S.DRAW_FRAMEBUFFER,null)}else if(C!==0||r.isRenderTargetTexture||P.has(r)){const nt=P.get(r),Ut=P.get(E);a.bindFramebuffer(S.READ_FRAMEBUFFER,Z),a.bindFramebuffer(S.DRAW_FRAMEBUFFER,V);for(let Ke=0;Ke<me;Ke++)Gt?S.framebufferTextureLayer(S.READ_FRAMEBUFFER,S.COLOR_ATTACHMENT0,nt.__webglTexture,C,Ue+Ke):S.framebufferTexture2D(S.READ_FRAMEBUFFER,S.COLOR_ATTACHMENT0,S.TEXTURE_2D,nt.__webglTexture,C),ze?S.framebufferTextureLayer(S.DRAW_FRAMEBUFFER,S.COLOR_ATTACHMENT0,Ut.__webglTexture,fe,it+Ke):S.framebufferTexture2D(S.DRAW_FRAMEBUFFER,S.COLOR_ATTACHMENT0,S.TEXTURE_2D,Ut.__webglTexture,fe),C!==0?S.blitFramebuffer(Ee,Le,pe,ce,Me,Ve,pe,ce,S.COLOR_BUFFER_BIT,S.NEAREST):ze?S.copyTexSubImage3D(ue,fe,Me,Ve,it+Ke,Ee,Le,pe,ce):S.copyTexSubImage2D(ue,fe,Me,Ve,Ee,Le,pe,ce);a.bindFramebuffer(S.READ_FRAMEBUFFER,null),a.bindFramebuffer(S.DRAW_FRAMEBUFFER,null)}else ze?r.isDataTexture||r.isData3DTexture?S.texSubImage3D(ue,fe,Me,Ve,it,pe,ce,me,ke,ut,et.data):E.isCompressedArrayTexture?S.compressedTexSubImage3D(ue,fe,Me,Ve,it,pe,ce,me,ke,et.data):S.texSubImage3D(ue,fe,Me,Ve,it,pe,ce,me,ke,ut,et):r.isDataTexture?S.texSubImage2D(S.TEXTURE_2D,fe,Me,Ve,pe,ce,ke,ut,et.data):r.isCompressedTexture?S.compressedTexSubImage2D(S.TEXTURE_2D,fe,Me,Ve,et.width,et.height,ke,et.data):S.texSubImage2D(S.TEXTURE_2D,fe,Me,Ve,pe,ce,ke,ut,et);a.pixelStorei(S.UNPACK_ROW_LENGTH,gt),a.pixelStorei(S.UNPACK_IMAGE_HEIGHT,ye),a.pixelStorei(S.UNPACK_SKIP_PIXELS,vt),a.pixelStorei(S.UNPACK_SKIP_ROWS,Tt),a.pixelStorei(S.UNPACK_SKIP_IMAGES,wt),fe===0&&E.generateMipmaps&&S.generateMipmap(ue),a.unbindTexture()},this.initRenderTarget=function(r){P.get(r).__webglFramebuffer===void 0&&y.setupRenderTarget(r)},this.initTexture=function(r){r.isCubeTexture?y.setTextureCube(r,0):r.isData3DTexture?y.setTexture3D(r,0):r.isDataArrayTexture||r.isCompressedArrayTexture?y.setTexture2DArray(r,0):y.setTexture2D(r,0),a.unbindTexture()},this.resetState=function(){z=0,B=0,$=null,a.reset(),de.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return yn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(i){this._outputColorSpace=i;const t=this.getContext();t.drawingBufferColorSpace=$e._getDrawingBufferColorSpace(i),t.unpackColorSpace=$e._getUnpackColorSpace()}}export{$f as W};
//# sourceMappingURL=three-webgl-CAyPJlAQ.js.map
